import React, { Suspense } from 'react'
import ReactDOM from 'react-dom'

import App from './Common/routes/App'
import { SuspenseFallBackLoader } from './Common/components/SuspenseLoading'
import * as serviceWorker from './serviceWorker'
import './Common/i18n'
import './index.css'
import Config from './Common/constants/EnvironmentConstants'

ReactDOM.render(
   <Suspense
      fallback={
         <div className='suspense-loading-view'>
            <SuspenseFallBackLoader />
         </div>
      }
   >
      <App />
   </Suspense>,
   document.getElementById('root')
)

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA

if (JSON.parse(Config.ENABLE_SERVICE_WORKER)) {
   serviceWorker.register()
} else {
   serviceWorker.unregister()
}
