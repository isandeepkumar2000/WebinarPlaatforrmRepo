export const DATE_PICKER_DATE_FORMAT = 'yyyy-MM-dd'

export const SERVER_DATE_FORMAT = 'yyyy-MM-dd HH:mm:ss'

export const IndianTimeZone = 'Asia/Kolkata'
