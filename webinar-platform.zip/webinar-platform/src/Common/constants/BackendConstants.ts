import { WebinarCardFooterStatusType } from '../../ContentManagement/stores/types'

export const webinarStatusConstants = {
   today: 'TODAY',
   completed: 'COMPLETED',
   live: 'LIVE',
   upcoming: 'UPCOMING',
   todayMorning: 'TODAY_MORNING',
   todayAfternoon: 'TODAY_AFTERNOON',
   todayEvening: 'TODAY_EVENING',
   jgc2Day0: 'JGC2_DAY0'
}

export const intrestedInConstants = {
   xpmOnly: 'XPM',
   xpmAndCcbp: 'XPM_AND_CCBP',
   xpmAndOtg: 'XPM_AND_OTG',
   jobInterviewOnly: 'JOB_INTERVIEW_ONLY',
   other: 'OTHER'
}

export const validationTypes = {
   defaultValidation: 'DEFAULT_VALIDATION',
   studentAmbassadorWebinar: 'STUDENT_AMBASSADOR_WEBINAR',
   dynamicDefaultWebinar: 'DYNAMIC_DEFAULT_WEBINAR'
}

export const webinarSectionTitleWithStatusList = [
   {
      webinar_status: webinarStatusConstants.today,
      section_title: 'TODAY',
      should_show_webinars_count: true,
      is_section_expanded_by_default: true
   },
   {
      webinar_status: webinarStatusConstants.completed,
      section_title: 'COMPLETED',
      should_show_webinars_count: true,
      is_section_expanded_by_default: true
   },
   {
      webinar_status: webinarStatusConstants.live,
      section_title: 'AVAILABLE NOW',
      should_show_webinars_count: true,
      is_section_expanded_by_default: true
   },
   {
      webinar_status: webinarStatusConstants.upcoming,
      section_title: 'UPCOMING',
      should_show_webinars_count: true,
      is_section_expanded_by_default: true
   },
   {
      webinar_status: webinarStatusConstants.todayMorning,
      section_title: 'MORNING',
      should_show_webinars_count: true,
      is_section_expanded_by_default: true
   },
   {
      webinar_status: webinarStatusConstants.todayAfternoon,
      section_title: 'AFTERNOON',
      should_show_webinars_count: true,
      is_section_expanded_by_default: true
   },
   {
      webinar_status: webinarStatusConstants.todayEvening,
      section_title: 'EVENING',
      should_show_webinars_count: true,
      is_section_expanded_by_default: true
   },

   {
      webinar_status: webinarStatusConstants.jgc2Day0,
      section_title: 'JGC 2 - Day 0',
      should_show_webinars_count: false,
      is_section_expanded_by_default: true
   }
]

export const ctaDetailsType = {
   internal: 'INTERNAL',
   external: 'EXTERNAL',
   redirect: 'REDIRECT'
}

export const ctaButtonStyleType = {
   filled: 'FILLED',
   outline: 'OUTLINE'
}

export const webinarAttendeeFormId = 'ccbp-academy-webinar-viewer'

export const WEBINAR_REGISTRATION_QUERY_PARAM = 'is_spot_registration=true'

export const NO_ACCESSIBLE_VIEW_REQUEST_LINK = `http://bit.ly/MAY21-WEBINAR-CODE?${WEBINAR_REGISTRATION_QUERY_PARAM}`

export const webinarCardFooterStatuses: Record<
   string,
   WebinarCardFooterStatusType
> = {
   live: 'LIVE',
   dateOnly: 'DATE_ONLY',
   timeOnly: 'TIME_ONLY',
   dateAndTime: 'DATE_AND_TIME'
}

export const attendeeBranchConstants = {
   BTECH_BECSE_IT_AIML_DS_CYBERSECURITY: 'BTECH_BECSE_IT_AIML_DS_CYBERSECURITY',
   BTECH_BEECE_EEE: 'BTECH_BEECE_EEE',
   BTECH_BEMECHANICAL_CIVIL_CHEMICAL: 'BTECH_BEMECHANICAL_CIVIL_CHEMICAL',
   BCOM_BSC_BA: 'BCOM_BSC_BA',
   BBA_BBM: 'BBA_BBM',
   other: 'OTHER'
}
