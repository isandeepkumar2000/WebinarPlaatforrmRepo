export const showReportDialogErrorTypes = {
   mediaSrcNotSupported: 'MEDIA SRC NOT SUPPORTED'
}
