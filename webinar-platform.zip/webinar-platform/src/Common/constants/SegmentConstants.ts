// NOTE: Track Event Names
export const USER_VISITED_WEBINARS_LIST_PAGE = 'User Visited Webinars List Page'
export const WEBINAR_THUMBNAIL_CLICK_EVENT = 'Webinar Thumbnail Clicked'
export const WHO_IS_WATCHING_WEBINAR_EVENT = 'Webinar Attendees'
export const USER_VISITED_WEBINAR_PAGE = 'User Visited Webinar Page'
export const PLAY_BUTTON_CLICK_EVENT = 'Webinar Play Button Clicked'
export const VIDEO_WATCHED_DURATION_EVENT = 'Webinar Watched Duration'
export const WEBINAR_ATTENDEE_BRANCH_EVENT = 'Webinar Attendees branch'

// NOTE: Page Event Names
export const LIST_OF_WEBINARS_PAGE_EVENT_NAME = 'List Of Webinars Page Visit'
export const SINGLE_WEBINAR_PAGE_EVENT_NAME = 'Single Webinar Page Visit'
