export const HEADER_MIN_HEIGHT = 72
