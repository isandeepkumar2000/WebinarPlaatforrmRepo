export const CLOUDINARY_CONFIGURED_PREFIX = `https://res.cloudinary.com/due4dmz2b`
