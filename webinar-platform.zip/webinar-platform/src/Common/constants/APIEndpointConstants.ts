export const apiEndpointEnums = {
   otgFormsAuth: 'OTG_FORMS_AUTH'
}
