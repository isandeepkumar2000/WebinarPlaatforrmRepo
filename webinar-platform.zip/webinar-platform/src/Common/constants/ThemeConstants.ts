export const DARK_THEME = 'dark'
export const LIGHT_THEME = 'light'
