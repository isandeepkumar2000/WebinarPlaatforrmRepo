export const HOME_SCREEN_PATH = '/'

export const NOT_FOUND_PAGE_PATH = '*'

export const NOT_FOUND_PAGE = '404_NOT_FOUND'

export const UTM_SOURCE = 'utm_source'

export const WEBINAR = 'webinar'

export const WEBINAR_PATH = `/${WEBINAR}/:webinar_slug`
