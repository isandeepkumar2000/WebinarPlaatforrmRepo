export const ACTIVE_QUESTION = 'active_question'

export const WEBINARS = 'webinars'

export const WEBINAR_INFO = 'webinar_info'
