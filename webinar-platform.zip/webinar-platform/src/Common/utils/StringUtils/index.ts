export const getNormalSpacedString = (strValue: string): string =>
   strValue.trim().replace(/\s+/g, ' ')
