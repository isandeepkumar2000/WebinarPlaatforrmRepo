import uuid from 'uuid'

export const getUniversalUniqueId = () => uuid.v4()
