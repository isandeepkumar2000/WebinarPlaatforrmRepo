export function isSafariBrowser() {
   try {
      //@ts-ignore
      return window.safari !== undefined
   } catch (e) {
      return false
   }
}

export function isSafariIPhoneOrIPad() {
   return isIPhoneOrIPadDevice() && isSafari()
}

export function isIPhoneOrIPadDevice() {
   const iOS = !!navigator.platform.match(/iPhone|iPad/)
   return iOS
}

export function isSafari() {
   const ua = window.navigator.userAgent
   const webkit = !!ua.match(/WebKit/i)
   const iOSSafari = webkit && !ua.match(/CriOS/i)
   return iOSSafari
}
