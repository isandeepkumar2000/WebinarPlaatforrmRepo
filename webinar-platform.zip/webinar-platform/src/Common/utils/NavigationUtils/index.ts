import { History } from 'history'

import { HOME_SCREEN_PATH } from '../../constants/NavigationConstants'
import { STUDENT_AMBASSADOR_PATH } from '../../../ContentManagement/constants/NavigationConstants'

export function removeParam(key, searchParams) {
   const params = new URLSearchParams(searchParams)

   params.delete(key)

   return params.toString()
}

export function getPathByAttachingQueryParams(path: string): string {
   let pathWithQueryParams = path

   const pathArray = pathWithQueryParams.split('?')

   const urlSearchParamsString = window.location.search

   const updatedSearchParams = removeParam('t', urlSearchParamsString)

   if (pathArray[1] && updatedSearchParams) {
      pathWithQueryParams = `${pathArray[0]}?${pathArray[1]}&${updatedSearchParams}`
   } else if (updatedSearchParams) {
      pathWithQueryParams += `?${updatedSearchParams}`
   }

   return pathWithQueryParams
}

export function navigateWithQueryParams(
   history: History,
   path: string,
   shouldReplace = false
): void {
   const pathWithQueryParams = getPathByAttachingQueryParams(path)

   if (shouldReplace) {
      history.replace(pathWithQueryParams)
   } else {
      history.push(pathWithQueryParams)
   }
}

export function replaceWithHomePage(history: History): void {
   navigateWithQueryParams(history, HOME_SCREEN_PATH, true)
}

export function goToHomePage(history: History, shouldReplace = false): void {
   if (shouldReplace) {
      replaceWithHomePage(history)
   } else {
      navigateWithQueryParams(history, HOME_SCREEN_PATH)
   }
}

export function goToPreviousPage(history: History): void {
   if (history.length <= 2) {
      replaceWithHomePage(history)
   } else {
      history.goBack()
   }
}

export function goToStudentAmbassadorDashboard(history: History): void {
   navigateWithQueryParams(history, STUDENT_AMBASSADOR_PATH)
}

export function navigateToDynamicRouteDashboard(
   history: History,
   path: string
): void {
   navigateWithQueryParams(history, path)
}
