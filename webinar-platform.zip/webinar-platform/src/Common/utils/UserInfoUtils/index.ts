import stores from '../../stores'
import { getUserUUID } from '../LocalStorageUtils'

export function getUserInfoDetails() {
   const { commonUIStore } = stores
   const userDetails = {
      userId: getUserUUID(),
      browserSessionId: commonUIStore.browserSessionId
   }

   return userDetails
}
