import {
   isDesktop,
   deviceType,
   deviceDetect,
   isChrome,
   isTablet,
   isMobileOnly
} from 'react-device-detect'

import { deviceConstants } from '../../constants/ResponsiveConstants'

export const isDeviceRealDesktop = () => isDesktop

export const getDeviceType = () => deviceType

export const getDeviceDetails = () => deviceDetect()

export const checkIsChromeBrowser = (): boolean => isChrome

export const isRealMobileOnly = (): boolean => isMobileOnly // returns true if device type is mobile

export const isRealTabletDevice = (): boolean => isTablet

export const getDeviceTypeAtAnalyticsTracking = (): string => {
   const { mobile, tablet, desktop, other } = deviceConstants
   if (isRealMobileOnly()) {
      return mobile
   } else if (isRealTabletDevice()) {
      return tablet
   } else if (isDeviceRealDesktop()) {
      return desktop
   }
   return other
}
