import uuid from 'uuid'
import { DARK_THEME } from '../../constants/ThemeConstants'

const USER_NAME_LOCAL_STORAGE_KEY = 'user_name'
const MOBILE_NUMBER_LOCAL_STORAGE_KEY = 'mobile_number'
const isSyncedWithBackend = 'is_synced_with_backend'
export const SYNCED_WITH_BACKEND = 'true'
export const NOT_SYNCED_WITH_BACKEND = 'false'

const GA_TRACK_ID = 'ga_track_id'

const USER_UUID = 'user_uuid'

const SELECTED_THEME = 'selectedTheme'

const REMIND_ME_WEBINARS = 'remind_me_webinars'

const INTERESTED_IN = 'interested_in'

const GENDER = 'gender'

const OCCUPATION = 'occupation'

const STATE = 'state'

const WHATSAPP_CONSENT = 'whatsapp_consent'

export const USER_PLAYBACK_DETAILS = 'user_playback_details'

export const getUsername = (): string | null =>
   localStorage.getItem(USER_NAME_LOCAL_STORAGE_KEY)

export const getMobileNumber = (): string | null =>
   localStorage.getItem(MOBILE_NUMBER_LOCAL_STORAGE_KEY)

export const setUserName = (username: string): void => {
   localStorage.setItem(USER_NAME_LOCAL_STORAGE_KEY, username)
}

export const setMobileNumber = (mobileNumber: string): void => {
   localStorage.setItem(MOBILE_NUMBER_LOCAL_STORAGE_KEY, mobileNumber)
}

export const setIsSyncedWithBackend = (value: string): void => {
   localStorage.setItem(isSyncedWithBackend, value)
}

export const getIsSyncedWithBackend = (): string | null =>
   localStorage.getItem(isSyncedWithBackend)

export const setGATrackID = (value: string): void => {
   localStorage.setItem(GA_TRACK_ID, value)
}

export const getGATrackID = (): string | null =>
   localStorage.getItem(GA_TRACK_ID)

export const setUserUUID = (value: string): void => {
   localStorage.setItem(USER_UUID, value)
}

export const getUserUUID = (): string => {
   const userUUID = localStorage.getItem(USER_UUID)
   if (userUUID) {
      return userUUID
   }
   const newUUID = uuid.v4()
   setUserUUID(newUUID)
   return newUUID
}

export const setSelectedTheme = (value: string): void => {
   localStorage.setItem(SELECTED_THEME, value)
}

export const getSelectedTheme = (): string => {
   const theme = localStorage.getItem(SELECTED_THEME)
   if (theme !== null) {
      return theme
   }
   return DARK_THEME
}

export const setRemindMeWebinars = (remindeMeWebinars: Array<string>): void => {
   localStorage.setItem(REMIND_ME_WEBINARS, JSON.stringify(remindeMeWebinars))
}

export const getRemindMeWebinars = (): Array<string> => {
   const stringifiedJson: string | null = localStorage.getItem(
      REMIND_ME_WEBINARS
   )
   let webinarsArray = []
   if (stringifiedJson) {
      webinarsArray = JSON.parse(stringifiedJson)
   }
   return webinarsArray
}

export const getInterestedInFields = (): Array<string> => {
   const stringifiedJson: string | null = localStorage.getItem(INTERESTED_IN)
   let interestedInArray = []
   if (stringifiedJson) {
      interestedInArray = JSON.parse(stringifiedJson)
   }
   return interestedInArray
}

export const getGender = () => localStorage.getItem(GENDER)

export const getOccupation = () => localStorage.getItem(OCCUPATION)

export const getSelectedState = () => localStorage.getItem(STATE)

export const setWhatsAppConsent = (whatsAppConsent: string) => {
   localStorage.setItem(WHATSAPP_CONSENT, whatsAppConsent)
}

export const getWhatsAppConsent = (showWhatsAppConsent = true) => {
   const whatsAppConsent: string | null = localStorage.getItem(WHATSAPP_CONSENT)
   if (whatsAppConsent !== null) {
      return JSON.parse(whatsAppConsent)
   }
   return showWhatsAppConsent
}

export const setLocalPlaybackDetails = playbackDetailsArray => {
   localStorage.setItem(
      USER_PLAYBACK_DETAILS,
      JSON.stringify(playbackDetailsArray)
   )
}

export const getLocalPlaybackDetails = () => {
   const playbackDetailsArrayString = localStorage.getItem(
      USER_PLAYBACK_DETAILS
   )

   let playbackDetailsArray
   if (playbackDetailsArrayString) {
      playbackDetailsArray = JSON.parse(playbackDetailsArrayString)
   }
   return playbackDetailsArray
}
