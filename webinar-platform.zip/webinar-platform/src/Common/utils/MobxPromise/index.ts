import { bindPromiseWithOnSuccess } from '@ib/mobx-promise'

export { bindPromiseWithOnSuccess }
