// @ts-nocheck

import {
   getDeviceDetails,
   getDeviceType
} from '../../utils/ReactDeviceDetectUtils'
import EnvironmentConstants from '../../constants/EnvironmentConstants'

import { getUserInfoDetails } from '../UserInfoUtils'
import { getServerDateFormat } from '../DateUtils'

const isNotDevEnvironment = process.env.NODE_ENV === 'production'

const getTimeStampObject = () => {
   const date = new Date()
   return { device_time: getServerDateFormat(date) }
}

export function initializeLogEntries() {
   try {
      if (isNotDevEnvironment) {
         const { LOG_ENTRIES } = EnvironmentConstants
         R7Insight.init({
            token: LOG_ENTRIES,
            region: 'eu',
            no_format: true
         })
      }
   } catch (error) {
      console.log(error)
   }
}

export function captureLogEntriesExceptionWithScope(
   errorInfo: string,
   error: Record<string, any>,
   logType: string,
   priority: LogEntryPriorityEnum
) {
   const primaryObject = {
      event_name: errorInfo,
      log_type: logType,
      priority,
      ...getUserInfoDetails(),
      ...error,
      ...getTimeStampObject()
   }
   try {
      if (isNotDevEnvironment) {
         R7Insight.log(primaryObject)
      }
   } catch (error) {
      console.log(error)
   }
}

export function sendLogEntriesObjectData(logObject: Record<string, any>) {
   const primaryObject = {
      ...getUserInfoDetails(),
      ...logObject,
      ...getTimeStampObject()
   }
   try {
      if (isNotDevEnvironment) {
         R7Insight.log(primaryObject)
      }
   } catch (error) {
      console.log(error)
   }
}

export const getBaseLogEntriesObject = () => ({
   device_type: getDeviceType(),
   device_details: getDeviceDetails()
})
