import ReactGA from 'react-ga'

import { GA_TRACKER_ID } from '../../../ContentManagement/constants/Aug16WebinarConstants'

import { isProdEnvironment } from '../EnvironmentUtils'
import { setGATrackID, getUserUUID } from '../LocalStorageUtils'
import { sendLogEntriesObjectData } from '../LogEntriesUtils'

export function pushToDataLayer(dataObject): void {
   window.dataLayer = window.dataLayer || []
   window.dataLayer.push(dataObject)
}

export function setGaUserUUIDDimension(userUUID: string) {
   if (!isProdEnvironment()) {
      ReactGA.set({ dimension4: userUUID })
      ReactGA.set({ dimension10: userUUID })
   }
   pushToDataLayer({
      userId: userUUID,
      event: 'user_id_enabled'
   })
}

export function initializeGoogleTracker(): void {
   const userUUID = getUserUUID()
   setGaUserUUIDDimension(userUUID)
   if (!isProdEnvironment()) {
      try {
         ReactGA.initialize(GA_TRACKER_ID, {
            titleCase: false,
            gaOptions: { userId: userUUID, siteSpeedSampleRate: 100 },
            standardImplementation: false
         })
         //@ts-ignore
         if (ga) {
            //@ts-ignore
            ga(() => {
               ReactGA.ga(tracker => {
                  const clientId = tracker.get('clientId')
                  setGATrackID(clientId)
                  const analyticsData = {
                     dimension3: clientId,
                     dimension4: userUUID
                  }
                  sendLogEntriesObjectData(analyticsData)
                  ReactGA.set({ dimension3: clientId })
                  ReactGA.set({ dimension9: clientId })
                  ReactGA.event({
                     category: 'DimensionsTest',
                     action: 'App Start',
                     label: 'Live Webinar'
                  })
               })
            })
         }
      } catch (e) {
         //log exception here
      }
   }
}

export function createPageView(): void {
   if (!isProdEnvironment()) {
      ReactGA.pageview(window.location.pathname + window.location.search)
   }
}

export function createTrackerEvent(
   category: string,
   action: string,
   label: string,
   value: number
): void {
   if (!isProdEnvironment()) {
      ReactGA.event({
         category: category,
         action: action,
         label: label,
         value: value
      })
   }
}

export function videoDataLayer(props) {
   const { event, videoId, ...other } = props
   window.dataLayer = window.dataLayer || []
   window.dataLayer.push({
      event: event,
      videoID: videoId,
      ...other
   })
}
