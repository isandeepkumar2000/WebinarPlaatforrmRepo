import * as Sentry from '@sentry/react'

import EnvironmentConstants from '../../constants/EnvironmentConstants'
import Config from '../../constants/EnvironmentConstants'
import { showReportDialogErrorTypes } from '../../constants/SentryConstants'

import { getUserInfoDetails } from '../UserInfoUtils'

const isNotDevEnvironment = process.env.NODE_ENV === 'production'

const ignoreErrors = [
   'getReadModeExtract',
   'getReadModeConfig',
   'getReadModeRender',
   'ResizeObserver',
   'SourceBuffer',
   'postMessage',
   'There is no interval scheduled with the given id',
   `null is not an object (evaluating 'this.el_[e]')`,
   `Cannot read property 'buffered' of null`,
   `Cannot read properties of null (reading 'buffered')`,
   `Cannot read properties of null (reading 'currentTime')`
]

const { mediaSrcNotSupported } = showReportDialogErrorTypes

const showReportDialogErrors = [mediaSrcNotSupported]

function shouldIgnoreError(errorMessage) {
   let ignoreError = false
   ignoreErrors.forEach(errorText => {
      if (errorMessage.toString().includes(errorText)) {
         ignoreError = true
      }
   })
   return ignoreError
}

function shouldShowReportDialog(errorMessage = ''): boolean {
   let showReportDialog = false
   showReportDialogErrors.forEach(errorText => {
      if (errorMessage.toString().includes(errorText)) {
         showReportDialog = true
      }
   })
   return showReportDialog
}

export function initializeSentry() {
   if (isNotDevEnvironment) {
      const { SENTRY_DSN_KEY } = EnvironmentConstants
      const { userId } = getUserInfoDetails()
      Sentry.init({
         dsn: SENTRY_DSN_KEY,
         release: process.env.REACT_APP_SENTRY_RELEASE,
         environment: Config.SENTRY_ENVIRONMENT,
         integrations: function(integrations) {
            return integrations.filter(
               i =>
                  i.name !== 'GlobalHandlers' && i.name !== 'ReportingObserver'
            )
         },
         beforeSend: (event, hint) => {
            const originalException = hint && (hint.originalException as Error)
            if (
               event.exception &&
               shouldShowReportDialog(originalException?.message)
            ) {
               Sentry.showReportDialog({
                  eventId: event.event_id,
                  dsn: SENTRY_DSN_KEY,
                  title: 'Having Trouble?',
                  labelSubmit: 'Submit'
               })
            }
            if (hint) {
               // Filter out some errors we don't care about
               const error = hint.originalException
               let errorMessage = ''
               if (typeof error === 'string') {
                  errorMessage = error
               } else if (error instanceof Error) {
                  errorMessage = error.message
               }

               if (shouldIgnoreError(errorMessage)) {
                  return null
               }
            }
            if (event && event.message) {
               if (shouldIgnoreError(event.message)) {
                  return null
               }
            }
            return event
         }
      })
      const currentUserId: string = userId ? userId : 'GUEST'
      Sentry.setUser({ id: currentUserId, user_details: getUserInfoDetails() })
   }
}

function getErrorMessage(e): string {
   return e && e.stack && e.message
}

export function captureSentryException(
   error: Record<string, any>,
   errorInfo: any = undefined
) {
   if (error && isNotDevEnvironment) {
      const { userId } = getUserInfoDetails()
      let updatedError = error
      if (!getErrorMessage(error)) {
         updatedError = new Error(error.toString())
      }
      if (errorInfo) {
         Sentry.configureScope(scope => {
            Object.keys(errorInfo).forEach(key => {
               scope.setExtra(key, errorInfo[key])
            })
            scope.setUser({ id: userId })
         })
      }
      const ignoreError = shouldIgnoreError(error)
      if (!ignoreError) {
         Sentry.captureException(updatedError)
      }
   }
}
