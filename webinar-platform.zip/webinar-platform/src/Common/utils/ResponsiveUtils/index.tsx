import {
   TABLET_MIN_WIDTH,
   DESKTOP_MIN_WIDTH
} from '../../../Common/constants/ResponsiveConstants'

export function isMobile(): boolean {
   if (window.innerWidth < TABLET_MIN_WIDTH) {
      return true
   }
   return false
}

export function isDesktop(): boolean {
   return window.innerWidth >= DESKTOP_MIN_WIDTH - 1
}

export function isTabletOrMobile(): boolean {
   return window.innerWidth < DESKTOP_MIN_WIDTH
}
