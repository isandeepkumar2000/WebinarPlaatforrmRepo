import {
   LogEntriesConstantsEnums,
   logEntriesTypes,
   LogEntryPriorityEnum
} from '../../constants/LogEntriesConstants'
import { apiErrorProblems } from '../../constants/APIErrorConstants'

import { captureLogEntriesExceptionWithScope } from '../LogEntriesUtils'

export function captureError(apiName: string) {
   const getErrorCapturedDescriptor = (
      target: Record<string, any>,
      propertyKey: string,
      descriptor: PropertyDescriptor
   ): PropertyDescriptor => {
      const originalMethod = descriptor.value

      descriptor.value = function(...args) {
         let parsedMessage
         if (args.length > 0) {
            try {
               parsedMessage = JSON.parse(args[0])
               const captureBackEndSpecificError =
                  parsedMessage.hasOwnProperty('ok') &&
                  parsedMessage.ok === false
               if (captureBackEndSpecificError) {
                  const problemCode = parsedMessage.problem
                  const {
                     timeoutError,
                     serverError,
                     connectionError
                  } = apiErrorProblems
                  const isBackEndSpecificError =
                     problemCode === timeoutError ||
                     problemCode === serverError ||
                     problemCode === connectionError
                  if (isBackEndSpecificError) {
                     captureLogEntriesExceptionWithScope(
                        LogEntriesConstantsEnums.API_FAILURE_ERROR,
                        {
                           api_name: apiName,
                           error: args[0]
                        },
                        logEntriesTypes.errors,
                        LogEntryPriorityEnum.CRITICAL
                     )
                  }
               } else {
                  captureLogEntriesExceptionWithScope(
                     LogEntriesConstantsEnums.FRONTEND_EXCEPTION_CATCH,
                     {
                        api_name: apiName,
                        error: args[0]
                     },
                     logEntriesTypes.errors,
                     LogEntryPriorityEnum.CRITICAL
                  )
               }
            } catch (error) {
               parsedMessage = null
               captureLogEntriesExceptionWithScope(
                  LogEntriesConstantsEnums.FRONTEND_EXCEPTION_CATCH,
                  {
                     api_name: apiName,
                     error: args[0]
                  },
                  logEntriesTypes.errors,
                  LogEntryPriorityEnum.CRITICAL
               )
            }
         }
         const result = originalMethod.apply(this, args)
         return result
      }

      return descriptor
   }
   return getErrorCapturedDescriptor
}
