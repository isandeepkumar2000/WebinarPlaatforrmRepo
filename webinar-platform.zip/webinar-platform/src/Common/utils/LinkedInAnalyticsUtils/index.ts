export function initializeLinkedInAnalytics(): void {
   const linkedInScript1 = document.createElement('script')
   linkedInScript1.type = 'text/javascript'
   linkedInScript1.textContent = `
      _linkedin_partner_id = '2907284'
        window._linkedin_data_partner_ids =
        window._linkedin_data_partner_ids || []
        window._linkedin_data_partner_ids.push(_linkedin_partner_id)
        `
   document.head.appendChild(linkedInScript1)

   const linkedInScript2 = document.createElement('script')
   linkedInScript2.type = 'text/javascript'
   linkedInScript2.textContent = `
        ;(function() {
            var s = document.getElementsByTagName('script')[0]
            var b = document.createElement('script')
            b.type = 'text/javascript'
            b.async = true
            b.src = 'https://snap.licdn.com/li.lms-analytics/insight.min.js'
            s.parentNode.insertBefore(b, s)
        })()
        `
   document.head.appendChild(linkedInScript2)

   const linkedInScript3 = document.createElement('noscript')
   linkedInScript3.textContent = `
        <img
            height="1"
            width="1"
            style="display:none;"
            alt=""
            src="https://px.ads.linkedin.com/collect/?pid=2907284&fmt=gif"
        />
        `
   document.head.appendChild(linkedInScript3)
}
