import ReactPixel from 'react-facebook-pixel'

import Config from '../../constants/EnvironmentConstants'

export function initializeFacebookPixelAnalytics(): void {
   ReactPixel.init(`${Config.FACEBOOK_PIXEL_ID}`)
   ReactPixel.pageView()
}
