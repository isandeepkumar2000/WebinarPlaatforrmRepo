import { apiEndpointEnums } from '../../constants/APIEndpointConstants'

export function getWebinarApiEndpointName(enumName = ''): string {
   const otgFormsEndPoints = {
      otgFormsAuth: 'api/otg_forms_auth/',
      otgForms: 'api/otg_forms/'
   }

   const { otgFormsAuth } = apiEndpointEnums

   if (enumName === otgFormsAuth) {
      return otgFormsEndPoints.otgFormsAuth
   }
   return otgFormsEndPoints.otgForms
}
