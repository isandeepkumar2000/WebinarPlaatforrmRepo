import React from 'react'
import { Route, Redirect } from 'react-router-dom'
import stores from '../../stores'

import { isURLInCapitalLetters } from '../ValidationUtils'

interface RouteParams {
   component: any
   [x: string]: any
}

export const ProtectedRoute = ({
   component: Component,
   ...other
}: RouteParams) => {
   const renderComponent = (props: any) => {
      stores.activeWebinarsStore.setActiveSlug(props.match.params.webinar_slug)
      const slug = props.match.params.webinar_slug
      stores.activeWebinarsStore.setActiveSlug(slug.toLowerCase())
      if (isURLInCapitalLetters(slug)) {
         return (
            <Redirect
               to={{
                  pathname: `/${slug.toLowerCase()}`,
                  state: { from: props.location }
               }}
            />
         )
      }

      return <Component {...props} {...other} />
   }
   return <Route {...other} render={renderComponent} />
}

export const ReactRoute = ({ component: Component, ...other }: RouteParams) => {
   const renderComponent = (props: any) => <Component {...props} {...other} />

   return <Route {...other} render={renderComponent} />
}

export const getQueryStringValue = (location, key: string) =>
   // NOTE: Kept eslint-disable as we are not sure if this code breaks
   decodeURIComponent(
      location.search.replace(
         new RegExp(
            `^(?:.*[&\\?]${encodeURIComponent(key).replace(
               /[\.\+\*]/g, // eslint-disable-line
               '\\$&'
            )}(?:\\=([^&]*))?)?.*$`,
            'i'
         ),
         '$1'
      )
   )

export const getAllQueryParams = (urlString: string) => {
   const params = new URLSearchParams(urlString)
   const paramObj = {}
   //@ts-ignore
   for (const value of params.keys()) {
      paramObj[value] = params.get(value)
   }
   return paramObj
}
