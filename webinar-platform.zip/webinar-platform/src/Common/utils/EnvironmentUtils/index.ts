import Config, {
   environmentConstants
} from '../../constants/EnvironmentConstants'
import { FeatureFlagsType } from '../../stores/types'

const isNotDevEnvironment = process.env.NODE_ENV === 'production'

export function isProdEnvironment(): boolean {
   const { prod } = environmentConstants
   return Config.ENVIRONMENT === prod
}

export function isBetaEnvironment(): boolean {
   const { beta } = environmentConstants
   return Config.ENVIRONMENT === beta
}

export function isGammaEnvironment(): boolean {
   const { gamma } = environmentConstants
   return Config.ENVIRONMENT === gamma
}

export function getPlatformFeatureFlags(): FeatureFlagsType {
   const featureFlags = {
      enableSegmentAnalytics: false,
      enableIbEventsAPI: false,
      enableWebinarLogsApi: false
   }
   const isDevEnvironment = !isNotDevEnvironment

   if (isDevEnvironment) {
      featureFlags.enableSegmentAnalytics = false
      featureFlags.enableIbEventsAPI = false
      featureFlags.enableWebinarLogsApi = false
   } else {
      switch (Config.ENVIRONMENT) {
         case environmentConstants.beta:
            featureFlags.enableSegmentAnalytics = false
            featureFlags.enableIbEventsAPI = true
            break
         case environmentConstants.gamma:
            featureFlags.enableSegmentAnalytics = true
            featureFlags.enableIbEventsAPI = true
            featureFlags.enableWebinarLogsApi = true
            break
         case environmentConstants.prod:
            featureFlags.enableSegmentAnalytics = true
            featureFlags.enableIbEventsAPI = false
            featureFlags.enableWebinarLogsApi = true
            break
         case environmentConstants.development:
            featureFlags.enableSegmentAnalytics = true
            featureFlags.enableIbEventsAPI = false
            break
         default:
            featureFlags.enableSegmentAnalytics = false
            featureFlags.enableIbEventsAPI = false
            break
      }
   }
   return featureFlags
}
