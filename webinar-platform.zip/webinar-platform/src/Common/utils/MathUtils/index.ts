export function getRoundedValue(value: number) {
   // NOTE: added the type check here, if the `value` is NaN/undefined
   return typeof value === 'number' ? Math.round(value) : 0
}
