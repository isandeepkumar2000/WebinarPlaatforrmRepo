import { USER_AGENT_DETAILS } from '../../constants/LogEntriesConstants'

import { captureSentryException } from '../SentryUtils'

export function removeDynamicallyAddedChildElements(
   parentClassName: string,
   childClassName: string
): void {
   try {
      const sourceSelectorElements = document.getElementsByClassName(
         parentClassName
      )
      const sourceSelector = sourceSelectorElements[0]

      const selector = `.${childClassName}`
      const observer = new MutationObserver(mutations => {
         for (const mutation of mutations) {
            // examine new nodes

            for (const node of mutation.addedNodes) {
               // we track only elements, skip other nodes (e.g. text nodes)
               if (!(node instanceof HTMLElement)) continue

               // check the inserted element with given class
               if (node.matches(selector)) {
                  observer.disconnect()
                  node.remove()
               }

               // or maybe it's somewhere in its subtree?
               for (const elem of node.querySelectorAll(selector)) {
                  observer.disconnect()
                  elem.remove()
               }
            }
         }
      })
      observer.observe(sourceSelector, {
         childList: true,
         subtree: true
      })
   } catch (exception) {
      const errorInfo = {
         errorCause: 'removeDynamicallyAddedChildElements'
      }
      captureSentryException(exception, errorInfo)
   }
}

export function getUserAgent() {
   try {
      return window.navigator.userAgent
   } catch (err) {
      return 'NA'
   }
}

export function getUserAgentObject() {
   const userAgent = {
      event_name: USER_AGENT_DETAILS,
      user_agent: getUserAgent()
   }

   return userAgent
}
