const CHECK_ONLINE_URL =
   'https://d1tgh8fmlzexmh.cloudfront.net/website/static-images/check_online_image.png'

export const isUserOnline = callback => {
   const url = CHECK_ONLINE_URL
   fetch(url)
      .then(data => {
         callback(true)
      })
      .catch(err => {
         callback(false)
      })
}
