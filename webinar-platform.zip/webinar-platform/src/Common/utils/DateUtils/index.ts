import parse from 'date-fns/parse'
import { differenceInSeconds, format } from 'date-fns'
import { utcToZonedTime } from 'date-fns-tz'

import {
   IndianTimeZone,
   SERVER_DATE_FORMAT
} from '../../constants/DateConstants'

export function getDateObjectFromDateString(
   date: string,
   dateFormat: string = SERVER_DATE_FORMAT
): Date {
   const result = parse(date, dateFormat, new Date())
   return result
}

export function getDurationFromTheDate(date: string): number {
   const today = new Date()
   const dateFromString = getDateObjectFromDateString(date)
   return differenceInSeconds(today, dateFromString)
}

export function getDurationFromTheNetworkDate(networkDate: Date, date) {
   const dateFromString = getDateObjectFromDateString(date)
   return differenceInSeconds(networkDate, dateFromString)
}

export function getMonthNumberFromMonthName(month) {
   switch (month) {
      case 'Jan':
         return '01'
      case 'Feb':
         return '02'
      case 'Mar':
         return '03'
      case 'Apr':
         return '04'
      case 'May':
         return '05'
      case 'Jun':
         return '06'
      case 'Jul':
         return '07'
      case 'Aug':
         return '08'
      case 'Sep':
         return '09'
      case 'Oct':
         return '10'
      case 'Nov':
         return '11'
      case 'Dec':
         return '12'
   }
}

export function getFormattedDateTimeFromNetworkDateTime(networkDateTimeObject) {
   let formattedDateTime = networkDateTimeObject.replace(
      '"network_time":  ',
      '"network_time":  "'
   )
   formattedDateTime = formattedDateTime.replace('\n}', '"\n}')
   formattedDateTime = JSON.parse(formattedDateTime)

   let finalDateTime = formattedDateTime.network_time
   finalDateTime = finalDateTime
      .replace(' +0000', 'Z')
      .split('/')
      .join('-')
      .replace(':', 'T')
   const date = finalDateTime.slice(0, 2)
   const monthName = finalDateTime.slice(3, 6)
   const monthNumber = getMonthNumberFromMonthName(monthName)
   const year = finalDateTime.slice(7, 11)
   const timeWithTZ = finalDateTime.slice(11, finalDateTime.length)
   const formedDate = `${year}-${monthNumber}-${date}${timeWithTZ}`
   return formedDate
}

export function getISTFromUTC(dateTime) {
   return utcToZonedTime(dateTime, IndianTimeZone)
}

export function getServerDateFormat(date: Date | number): string {
   return format(date, SERVER_DATE_FORMAT)
}
