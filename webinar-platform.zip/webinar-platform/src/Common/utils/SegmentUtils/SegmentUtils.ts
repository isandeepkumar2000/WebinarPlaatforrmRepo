// @ts-nocheck

import { getPlatformFeatureFlags } from '../EnvironmentUtils'

const { enableSegmentAnalytics } = getPlatformFeatureFlags()

export function pageEvent(name: string, extraData: Record<string, any> = {}) {
   if (enableSegmentAnalytics) {
      try {
         window.analytics.page(name, extraData, {
            integrations: {
               All: false,
               WebEngage: true,
               Mixpanel: false,
               CleverTap: true
            }
         })
      } catch {
         console.log('Tracking Page in segment failed')
      }
   }
}

export function identifyUser(userId: string, extraData: Record<string, any>) {
   if (enableSegmentAnalytics) {
      try {
         window.analytics.identify(userId, extraData, {
            integrations: {
               All: true,
               WebEngage: true,
               Mixpanel: true,
               CleverTap: true
            }
         })
      } catch (e) {
         console.log('Identify user in segment failed', e)
      }
   }
}

export function trackEvent(event: string, extraData: Record<string, any>) {
   if (enableSegmentAnalytics) {
      try {
         window.analytics.track(event, extraData, {
            integrations: {
               All: false,
               WebEngage: true,
               Mixpanel: false,
               CleverTap: true
            }
         })
      } catch {
         console.log('Tracking event in segment failed')
      }
   }
}
