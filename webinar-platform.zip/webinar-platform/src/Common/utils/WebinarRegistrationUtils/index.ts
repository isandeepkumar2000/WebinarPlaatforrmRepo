import { WEBINAR_REGISTRATION_QUERY_PARAM } from '../../constants/BackendConstants'
import { getPathByAttachingQueryParams } from '../NavigationUtils'

export const getUpdatedRegistrationLink = (
   registrationLink: string
): string => {
   const registrationLinkArray = registrationLink.split('?')

   let registrationLinkWithRegistrationParam = ''

   if (registrationLinkArray.length > 1) {
      registrationLinkWithRegistrationParam = `${registrationLink}&${WEBINAR_REGISTRATION_QUERY_PARAM}`
   } else {
      registrationLinkWithRegistrationParam = `${registrationLinkArray[0]}?${WEBINAR_REGISTRATION_QUERY_PARAM}`
   }

   registrationLinkWithRegistrationParam = getPathByAttachingQueryParams(
      registrationLinkWithRegistrationParam
   )

   return registrationLinkWithRegistrationParam
}
