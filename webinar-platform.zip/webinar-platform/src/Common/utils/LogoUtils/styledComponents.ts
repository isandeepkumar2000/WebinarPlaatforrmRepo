import styled from 'styled-components'

import Image from '../../components/Image'

export const CCBPHorizontalWhiteIcon = styled(Image)`
   height: ${props => props.height - 10}px;
   width: ${props => props.width}px;
   margin-top: -15px;
`

export const CCBPHorizontalIcon = styled(Image)`
   height: ${props => props.height - 10}px;
   width: ${props => props.width}px;
   margin-top: -15px;
`
