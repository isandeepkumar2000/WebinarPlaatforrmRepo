import React from 'react'

import { DARK_THEME } from '../../constants/ThemeConstants'
import { LogoTypes } from '../../stores/types'

import { isMobile, isTabletOrMobile } from '../ResponsiveUtils'

import { CCBPHorizontalIcon, CCBPHorizontalWhiteIcon } from './styledComponents'

export function getCCBPLogo(logoDetails: LogoTypes): React.ReactNode {
   const { theme, height, width } = logoDetails
   return (
      <>
         {theme === DARK_THEME ? (
            <CCBPHorizontalWhiteIcon
               src={'/images/ccbp/ccbp_white_Logo.png'}
               height={height}
               width={width}
            />
         ) : (
            <CCBPHorizontalIcon
               src={'/images/ccbp/ccbp_colored_logo.png'}
               height={height}
               width={width}
            />
         )}
      </>
   )
}

export function getIconDimensions() {
   if (isMobile() || isTabletOrMobile()) {
      return { width: 120, height: 48 }
   }
   return { width: 150, height: 62 }
}

export function getLogo(logoDetails: LogoTypes): React.ReactNode {
   return getCCBPLogo(logoDetails)
}
