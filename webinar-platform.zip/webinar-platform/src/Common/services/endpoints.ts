const endpoints = {
   loginOrRegister: 'login_or_register/v1/',
   getUserAppsAndSubscriptions: 'user_subscriptions/v1/',
   sendLogDetails: '/user/webinar/watched_duration/v1/'
}

export default endpoints
