import { IbEventsRequest } from '../../stores/types'

interface IbEventsService {
   sendIbEventsDataAPI: (requestObject: IbEventsRequest) => Promise<{}>
}

export default IbEventsService
