import { create } from 'apisauce'

import { IbEventsRequest } from '../../stores/types'

import { apiMethods } from '../../constants/APIConstants'
import Config from '../../constants/EnvironmentConstants'

import IbEventsService from '.'

const IB_EVENTS_URL = Config.IB_EVENTS_URL

class IbEventsAPI implements IbEventsService {
   api: Record<string, any>
   networkCallWithAPISauce: Function
   constructor(networkCallWithAPISauce: Function) {
      this.api = create({ baseURL: IB_EVENTS_URL })
      this.networkCallWithAPISauce = networkCallWithAPISauce
   }
   sendIbEventsDataAPI(requestObject: IbEventsRequest) {
      return this.networkCallWithAPISauce(
         this.api,
         '',
         requestObject,
         apiMethods.post,
         undefined,
         false
      )
   }
}

export default IbEventsAPI
