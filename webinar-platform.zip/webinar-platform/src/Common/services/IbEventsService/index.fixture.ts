import { resolveWithTimeout } from '../../utils/TestUtils'

import IbEventsService from '.'

class IbEventsFixture implements IbEventsService {
   sendIbEventsDataAPI(): Promise<{}> {
      return resolveWithTimeout({})
   }
}

export default IbEventsFixture
