import { create, ApisauceInstance } from 'apisauce'

import Config from '../../constants/EnvironmentConstants'
import { apiMethods } from '../../constants/APIConstants'
import { getAccessToken } from '../../utils/StorageUtils'
import { VideoLogsRequestType } from '../../stores/types'

import endpoints from '../endpoints'

import LogsService from '.'

const BASE_URL = `${Config.BASE_URL}`

class LogsServiceApi implements LogsService {
   api: ApisauceInstance
   networkCallWithApisauce: Function

   constructor(networkCallWithApisauce: Function) {
      this.api = create({ baseURL: BASE_URL })
      this.networkCallWithApisauce = networkCallWithApisauce
   }

   sendLogDetails(requestObject: VideoLogsRequestType): Promise<{}> {
      return this.networkCallWithApisauce(
         this.api,
         endpoints.sendLogDetails,
         requestObject,
         apiMethods.post,
         { getAccessToken },
         false
      )
   }
}

export default LogsServiceApi
