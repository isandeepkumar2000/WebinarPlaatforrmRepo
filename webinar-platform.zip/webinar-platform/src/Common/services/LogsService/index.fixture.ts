import { resolveWithTimeout } from '../../utils/TestUtils'
import { VideoLogsRequestType } from '../../stores/types'

import LogsService from '.'

class LogsServiceFixture implements LogsService {
   sendLogDetails(requestObject: VideoLogsRequestType): Promise<{}> {
      return resolveWithTimeout({})
   }
}

export default LogsServiceFixture
