import { VideoLogsRequestType } from '../../stores/types'

interface LogsService {
   sendLogDetails(requestObject: VideoLogsRequestType): Promise<{}>
}

export default LogsService
