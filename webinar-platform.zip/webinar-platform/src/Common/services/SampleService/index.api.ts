import { create, ApisauceInstance } from 'apisauce'

import { apiMethods } from '../../constants/APIConstants'
import Config from '../../constants/EnvironmentConstants'
import { SampleApiResponse, SampleApiRequest } from '../../stores/types'
import { getWebinarApiEndpointName } from '../../utils/WebinarClientUrlUtils'

import endpoints from '../endpoints'

import SampleService from '.'

const WEBINAR_CLIENT_URL = `${
   Config.WEBINAR_CLIENT_BASE_URL
}${getWebinarApiEndpointName()}`

class SampleServiceApi implements SampleService {
   api: ApisauceInstance
   networkCallWithApisauce: Function

   constructor(networkCallWithApisauce: Function) {
      this.api = create({ baseURL: WEBINAR_CLIENT_URL })
      this.networkCallWithApisauce = networkCallWithApisauce
   }

   getData(requestObject: SampleApiRequest): Promise<SampleApiResponse> {
      return this.networkCallWithApisauce(
         this.api,
         endpoints.loginOrRegister,
         requestObject,
         apiMethods.post
      )
   }
}

export default SampleServiceApi
