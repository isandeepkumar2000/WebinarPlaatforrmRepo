import { resolveWithTimeout } from '../../../Common/utils/TestUtils'

import getUserAppsAndSubscriptionsResponse from '../../fixtures/getUserAppsAndSubscriptionsResponse.json'

import AppsAndSubscriptionsService from '.'

class AppsAndSubscriptionsFixture implements AppsAndSubscriptionsService {
   getUserAppsAndSubscriptions() {
      return resolveWithTimeout(getUserAppsAndSubscriptionsResponse)
   }
}

export default AppsAndSubscriptionsFixture
