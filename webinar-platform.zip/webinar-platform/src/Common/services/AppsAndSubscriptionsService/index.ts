import { UserAppsAndSubscriptionsResponseType } from '../../stores/types'

interface AppsAndSubscriptionsService {
   getUserAppsAndSubscriptions: () => Promise<
      UserAppsAndSubscriptionsResponseType
   >
}

export default AppsAndSubscriptionsService
