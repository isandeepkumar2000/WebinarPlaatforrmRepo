import { create } from 'apisauce'

import { apiMethods } from '../../../Common/constants/APIConstants'
import Config from '../../../Common/constants/EnvironmentConstants'
import { getAccessToken } from '../../../UserProfile/utils/StorageUtils'

import { UserAppsAndSubscriptionsResponseType } from '../../stores/types'
import { getWebinarApiEndpointName } from '../../utils/WebinarClientUrlUtils'

import endpoints from '../endpoints'

import AppsAndSubscriptionsService from '.'

const WEBINAR_CLIENT_URL = `${
   Config.WEBINAR_CLIENT_BASE_URL
}${getWebinarApiEndpointName()}`

class AppsAndSubscriptionsAPI implements AppsAndSubscriptionsService {
   api: Record<string, any>
   networkCallWithAPISauce: Function
   constructor(networkCallWithAPISauce: Function) {
      this.api = create({ baseURL: WEBINAR_CLIENT_URL })
      this.networkCallWithAPISauce = networkCallWithAPISauce
   }

   getUserAppsAndSubscriptions(): Promise<
      UserAppsAndSubscriptionsResponseType
   > {
      return this.networkCallWithAPISauce(
         this.api,
         endpoints.getUserAppsAndSubscriptions,
         {},
         apiMethods.get,
         { getAccessToken: getAccessToken },
         true
      )
   }
}

export default AppsAndSubscriptionsAPI
