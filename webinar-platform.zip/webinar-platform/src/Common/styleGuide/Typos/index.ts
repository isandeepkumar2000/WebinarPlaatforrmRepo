import styled from 'styled-components'

import Colors from '../../themes/Colors'

export const BaseText = styled.span`
   font-family: 'HKGrotesk';
`

export const BaseHKGroteskText = styled(BaseText)`
   font-family: 'HKGrotesk';
`
export const BaseHkGrotesk = styled(BaseText)`
   font-family: 'HKGrotesk';
`

export const BaseHKGroteskMediumText = styled(BaseHKGroteskText)`
   font-weight: 500;
`

export const BaseHKGroteskSemiBoldText = styled(BaseHKGroteskText)`
   font-weight: 600;
`

export const BaseHKGroteskBoldText = styled(BaseHKGroteskText)`
   font-weight: bold;
`

export const Typo12BlackHKGrotesk = styled(BaseHKGroteskText)`
   font-size: 12px;
   color: ${Colors.black};
`

export const Typo12PinkishOrangeHKGrotesk = styled(BaseHKGroteskText)`
   font-size: 12px;
   color: ${Colors.pinkishOrange};
`

export const Typo12WhiteHKGroteskMedium = styled(BaseHKGroteskText)`
   font-size: 12px;
   color: ${Colors.white};
`

export const Typo12Steel60HKGroteskSemiBold = styled(BaseHKGroteskSemiBoldText)`
   font-size: 12px;
   color: ${Colors.steel60};
`

export const Typo12WhiteHKGroteskBold = styled(BaseHKGroteskBoldText)`
   font-size: 12px;
   color: ${Colors.white};
`

export const Typo14DarkRR = styled(BaseHKGroteskText)`
   font-size: 14px;
   color: ${Colors.dark};
`

export const Typo14CeruleanHKGroteskSemiBold = styled(
   BaseHKGroteskSemiBoldText
)`
   font-size: 14px;
   color: ${Colors.cerulean};
`

export const Typo14SlateHKGroteskSemiBold = styled(BaseHKGroteskMediumText)`
   font-size: 14px;
   color: ${Colors.slate};
`

export const Typo16DuskRR = styled(BaseHKGroteskText)`
   font-size: 16px;
   color: ${Colors.dusk};
`

export const Typo26BlackHKGrotesk = styled(BaseHKGroteskText)`
   font-size: 26px;
`

export const Typo20CharcoalGreyHKGroteskBold = styled(BaseHKGroteskBoldText)`
   font-size: 20px;
   color: ${Colors.charcoalGrey};
`

export const Typo16BlackHKGrotesk = styled(BaseHKGroteskText)`
   font-size: 16px;
   color: ${Colors.black};
`

export const Typo16BattleshipGreyHKGroteskSemiBold = styled(
   BaseHKGroteskSemiBoldText
)`
   font-size: 16px;
   color: ${Colors.battleshipGrey};
`

export const Typo16CharcoalGreyHKGroteskSemiBold = styled(
   BaseHKGroteskSemiBoldText
)`
   font-size: 16px;
   color: ${Colors.charcoalGrey};
`

export const Typo16SlateHKGroteskSemiBold = styled(BaseHKGroteskSemiBoldText)`
   font-size: 16px;
   color: ${Colors.slate};
`

export const Typo12SteelHKGroteskSemiBold = styled(BaseHkGrotesk)`
   font-size: 12px;
   font-weight: 600;
   color: ${Colors.steel};
`

export const Typo32DarkBlueGreyHKGroteskRegular = styled(BaseHKGroteskText)`
   font-size: 32px;
   color: ${Colors.darkBlueGrey};
`

export const Typo32WhiteHKGroteskMedium = styled(BaseHKGroteskSemiBoldText)`
   font-size: 32px;
   color: ${Colors.white};
`

export const Typo32DarkBlueGreyHKGrotesk = styled(BaseHKGroteskText)`
   font-size: 32px;
   color: ${Colors.darkBlueGrey};
`

export const Typo14DarkBlueGreyHKGroteskSemiBold = styled(
   BaseHKGroteskSemiBoldText
)`
   font-size: 14px;
   color: ${Colors.darkBlueGrey};
`

export const Typo14BattleshipGreyHKGroteskMediumText = styled(
   BaseHKGroteskMediumText
)`
   font-size: 14px;
   color: ${Colors.battleshipGrey};
`

export const Typo14WhiteHKGroteskSemiBold = styled(BaseHKGroteskSemiBoldText)`
   font-size: 14px;
   color: ${Colors.white};
`

export const Typo14WhiteHKGroteskMedium = styled(BaseHKGroteskMediumText)`
   font-size: 14px;
   color: ${Colors.white};
`

export const Typo14SteelHKGroteskRegular = styled(BaseHKGroteskText)`
   font-size: 14px;
   color: ${Colors.steel};
`

export const Typo14SteelHKGroteskBold = styled(BaseHKGroteskBoldText)`
   font-size: 14px;
   color: ${Colors.steel};
`

export const Typo14Steel60HKGroteskRegular = styled(BaseHKGroteskText)`
   font-size: 14px;
   color: ${Colors.steel60};
`

export const Typo14DarkBlueGreyHKGroteskRegular = styled(BaseHKGroteskText)`
   font-size: 14px;
   color: ${Colors.darkBlueGrey};
`

export const Typo14BrightBlueHKGroteskRegular = styled(BaseHKGroteskText)`
   font-size: 14px;
   color: ${Colors.brightBlue};
`

export const Typo12DarkBlueGreyHKGroteskSemiBold = styled(
   BaseHKGroteskSemiBoldText
)`
   font-size: 12px;
   color: ${Colors.darkBlueGrey};
`

export const Typo12CherryHKGroteskSemiBold = styled(BaseHKGroteskSemiBoldText)`
   font-size: 12px;
   color: ${Colors.cherry};
`

export const Typo12SteelKGroteskSemiBold = styled(BaseHKGroteskSemiBoldText)`
   font-size: 12px;
   color: ${Colors.steel};
`

export const Typo12SteelHKGroteskMedium = styled(BaseHKGroteskMediumText)`
   font-size: 12px;
   color: ${Colors.steel};
`

export const Typo12SteelHKGroteskRegular = styled(BaseHKGroteskText)`
   font-size: 12px;
   color: ${Colors.steel};
`

export const Typo12BrightBlueHKGroteskRegular = styled(BaseHKGroteskText)`
   font-size: 12px;
   color: ${Colors.brightBlue};
`

export const Typo10BrightBlueHKGroteskRegular = styled(BaseHKGroteskText)`
   font-size: 10px;
   color: ${Colors.brightBlue};
`

export const Typo9SteelHKGrotesk = styled(BaseHKGroteskText)`
   font-size: 9px;
   color: ${Colors.steel};
`

export const Typo18DarkBlueGreyHKGroteskMedium = styled(
   BaseHKGroteskMediumText
)`
   font-size: 18px;
   color: ${Colors.darkBlueGrey};
`

export const Typo18WhiteHKGroteskBold = styled(BaseHKGroteskBoldText)`
   font-size: 18px;
   color: ${Colors.white};
`

export const Typo18CharcoalGreyHKGroteskMedium = styled(
   BaseHKGroteskMediumText
)`
   font-size: 18px;
   color: ${Colors.charcoalGrey};
`

export const Typo18GunMetalHKGroteskMedium = styled(BaseHKGroteskMediumText)`
   font-size: 18px;
   color: ${Colors.gunMetal};
`

export const Typo24GunMetalHKGroteskMedium = styled(BaseHKGroteskMediumText)`
   font-size: 24px;
   color: ${Colors.gunMetal};
`

export const Typo24PaleGrayTwoHKGroteskMedium = styled(BaseHKGroteskMediumText)`
   font-size: 24px;
   color: ${Colors.paleGrayTwo};
`

export const Typo28GunMetalHKGroteskMedium = styled(BaseHKGroteskSemiBoldText)`
   font-size: 28px;
   color: ${Colors.gunMetal};
`

export const Typo12WhiteHKGroteskRegular = styled(BaseHKGroteskText)`
   font-size: 12px;
   color: ${Colors.white};
`

export const Typo24GunMetalHKGroteskSemiBoldText = styled(
   BaseHKGroteskSemiBoldText
)`
   font-size: 24px;
   color: ${Colors.gunMetal};
`

export const Typo18BattleshipGreyHKGroteskRegular = styled(
   BaseHKGroteskMediumText
)`
   font-size: 18px;
   color: ${Colors.battleshipGrey};
`
export const Typo14BlackHKGroteskSemiBold = styled(BaseHKGroteskSemiBoldText)`
   font-size: 14px;
   color: ${Colors.black};
`
export const Typo30OceanBlueHKGroteskBold = styled(BaseHKGroteskBoldText)`
   font-size: 30px;
   color: ${Colors.oceanBlue};
`
export const Typo30paleGreyHKGroteskBold = styled(BaseHKGroteskBoldText)`
   font-size: 30px;
   color: ${Colors.paleGrey};
   font-weight: bold;
`
export const Typo36CharcoalGreyHKGroteskBold = styled(BaseHKGroteskBoldText)`
   font-size: 36px;
   color: ${Colors.charcoalGrey};
`

export const Typo16GunMetalHKGroteskMedium = styled(BaseHKGroteskMediumText)`
   font-size: 16px;
   color: ${Colors.gunMetal};
`
export const Typo14charcoalGreyTwoHKGroteskSemiBold = styled(
   BaseHKGroteskSemiBoldText
)`
   font-size: 14px;
   color: ${Colors.charcoalGreyTwo};
`
export const Typo12SlateGreyHKGrotesk = styled(BaseHKGroteskText)`
   font-size: 12px;
   color: ${Colors.slateGrey};
`
export const Typo12NiceBlueHKGroteskBold = styled(BaseHKGroteskBoldText)`
   font-size: 12px;
   color: ${Colors.niceBlue};
`

export const Typo14AzulTwoHKGroteskMedium = styled(BaseHKGroteskMediumText)`
   font-size: 14px;
   color: ${Colors.azulTwo};
`
export const Typo16PaleGreTwoHKGroteskSemiBold = styled(
   BaseHKGroteskSemiBoldText
)`
   font-size: 16px;
   color: ${Colors.paleGreyTwo};
`

export const BaseRobotoBoldText = styled(BaseText)`
   font-weight: bold;
`

export const Typo32DodgerBlueThreeRobotoBold = styled(BaseRobotoBoldText)`
   font-size: 32px;
   color: ${Colors.dodgerBlueThree};
`

export const BaseRobotoMediumText = styled(BaseText)`
   font-weight: 500;
`
export const Typo24SlateBlueRobotoMedium = styled(BaseRobotoMediumText)`
   font-size: 24px;
   color: ${Colors.slateBlue};
`
