import styled from 'styled-components'

export const BaseText = styled.span`
   font-family: 'Roboto';
`
export const BaseRobotoText = styled(BaseText)`
   font-family: 'Roboto';
`
