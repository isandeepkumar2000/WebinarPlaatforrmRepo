import { observable } from 'mobx'
import {
   setSelectedTheme,
   getSelectedTheme
} from '../../utils/LocalStorageUtils'
import { DARK_THEME, LIGHT_THEME } from '../../constants/ThemeConstants'
import { themes } from '../../themes/Colors'

class ThemeStore {
   @observable selectedTheme!: string
   @observable backgroundColor!: string
   constructor() {
      this.selectedTheme = getSelectedTheme()
      if (this.selectedTheme === DARK_THEME) {
         this.setBodyBackgroundColor(themes.dark.primaryBackgroundColor)
      } else {
         this.setBodyBackgroundColor(themes.light.primaryBackgroundColor)
      }
   }

   setBodyBackgroundColor = (backgroundColor: string) => {
      document.body.style.backgroundColor = backgroundColor
      this.backgroundColor = backgroundColor
   }
   setTheme = () => {
      if (this.selectedTheme === DARK_THEME) {
         this.selectedTheme = LIGHT_THEME
         this.setBodyBackgroundColor(themes.light.primaryBackgroundColor)
      } else {
         this.selectedTheme = DARK_THEME
         this.setBodyBackgroundColor(themes.dark.primaryBackgroundColor)
      }
      setSelectedTheme(this.selectedTheme)
   }
}

export default ThemeStore
