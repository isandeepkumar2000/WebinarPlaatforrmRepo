import { observable, action } from 'mobx'

import { APIStatus, API_INITIAL } from '@ib/api-constants'

import LogsService from '../../../services/LogsService'
import { captureError } from '../../../utils/DecoratorLogEntriesUtils'
import { isAPIFetching } from '../../../utils/APIUtils'
import { getUniversalUniqueId } from '../../../utils/UuidUtils'
import { bindPromiseWithOnSuccess } from '../../../utils/MobxPromise'
import { sendLogEntriesObjectData } from '../../../utils/LogEntriesUtils'
import { ON_FAILURE_SEND_LOGS_API } from '../../../constants/LogEntriesConstants'

import {
   VideoLogsRequestType,
   VideoLogsNetworkCallRequestType
} from '../../types'

class LogsNetworkCallModel {
   @observable sendLogsApiStatus!: APIStatus
   @observable sendLogsApiError!: Error | null
   @observable networkCallQueue!: Array<VideoLogsNetworkCallRequestType>
   logsService: LogsService

   constructor(service: LogsService) {
      this.logsService = service
      this.init()
   }

   @action.bound
   init() {
      this.sendLogsApiStatus = API_INITIAL
      this.sendLogsApiError = null
      this.networkCallQueue = []
   }

   @action.bound
   setsendLogsApiStatus(status: APIStatus): void {
      this.sendLogsApiStatus = status
   }

   @action.bound
   @captureError('sendLogsAPI')
   setsendLogsApiError(error: any): void {
      this.sendLogsApiError = error
   }

   @action.bound
   getRequestObject(logObject: any): VideoLogsRequestType {
      const {
         userId,
         webinar_id,
         event,
         browserSessionId,
         videoCurrentTime,
         additionalData2
      } = logObject

      const backendLogObject = {
         user_id: userId,
         webinar_id: webinar_id,
         event_type: event,
         browser_session_id: browserSessionId,
         video_position: videoCurrentTime ?? 0
      }

      if (typeof additionalData2 === 'number') {
         backendLogObject['watched_duration'] = additionalData2
      }

      return backendLogObject
   }

   @action.bound
   onCompleteSendLogsApi(residueRequestId?: string): void {
      if (residueRequestId) {
         let requestIndex

         this.networkCallQueue.forEach((eachRequest, index) => {
            if (eachRequest.request_id === residueRequestId) {
               requestIndex = index
            }
         })

         this.networkCallQueue.splice(requestIndex, 1)
      }

      if (this.networkCallQueue.length > 0) {
         this.sendLogDetailsApi(this.networkCallQueue[0])
      }
   }

   @action.bound
   sendLogDetailsApi(requestObject): Promise<void | {}> {
      let residueRequestId

      if (requestObject.request_id) {
         residueRequestId = requestObject.request_id

         delete requestObject.request_id
      }

      const finalRequestObject = this.getRequestObject(requestObject)

      const getDataPromise = this.logsService.sendLogDetails(finalRequestObject)

      return bindPromiseWithOnSuccess(getDataPromise)
         .to(this.setsendLogsApiStatus, () => {
            this.onCompleteSendLogsApi(residueRequestId)
         })
         .catch(e => {
            this.setsendLogsApiError(e)
            sendLogEntriesObjectData({
               event_name: ON_FAILURE_SEND_LOGS_API,
               error: e,
               log_object: finalRequestObject
            })
            this.onCompleteSendLogsApi(residueRequestId)
         })
   }

   @action.bound
   sendLogsToBackend(logObject): void {
      if (
         isAPIFetching(this.sendLogsApiStatus) ||
         this.networkCallQueue.length > 0
      ) {
         const requestObject = {
            request_id: getUniversalUniqueId(),
            ...logObject
         }

         this.networkCallQueue.push(requestObject)
      } else {
         this.sendLogDetailsApi(logObject)
      }
   }
}

export default LogsNetworkCallModel
