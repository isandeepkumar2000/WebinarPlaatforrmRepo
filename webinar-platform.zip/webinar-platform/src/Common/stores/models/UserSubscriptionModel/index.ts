import { observable } from 'mobx'

import { UserSubscriptionType } from '../../types'

class UserSubscriptionModel {
   @observable userId: string
   @observable productCode: string
   @observable orderId: string
   @observable orderStatus: string

   constructor(userSubscription: UserSubscriptionType) {
      const {
         user_id: userId,
         product_code: productCode,
         order_id: orderId,
         order_status: orderStatus
      } = userSubscription
      this.userId = userId
      this.productCode = productCode
      this.orderId = orderId
      this.orderStatus = orderStatus
   }
}

export default UserSubscriptionModel
