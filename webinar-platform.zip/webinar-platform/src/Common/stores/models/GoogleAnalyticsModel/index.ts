import { action, observable } from 'mobx'

import { googleAnalyticsEvent } from '../../../../ContentManagement/constants'
import { getPlatformFeatureFlags } from '../../../utils/EnvironmentUtils'

import Config from '../../../constants/EnvironmentConstants'
import { VIDEO_WATCHED_DURATION_EVENT } from '../../../constants/SegmentConstants'
import {
   MAXIMUM_TIME_IN_PROGRESS_EVENT,
   VIDEO_WATCHED_DURATION_TRACKING_INTERVAL
} from '../../../constants/TimeConstants'
import { pushToDataLayer } from '../../../utils/GoogleAnalyticsUtils'
import { sendLogEntriesObjectData } from '../../../utils/LogEntriesUtils'
import { trackEvent } from '../../../utils/SegmentUtils/SegmentUtils'
import { getRoundedValue } from '../../../utils/MathUtils'
import { getCumulativeWatchedDuration } from '../../../components/Video/utils'
import { getUserUUID } from '../../../utils/LocalStorageUtils'

import { getLogsService } from '../../index'
import {
   GoogleAnalyticsModelType,
   GoogleAnalyticsWebinarObjectType
} from '../../types'

import LogsNetworkCallModel from '../LogsNetworkCallModel'

class GoogleAnalyticsModel {
   @observable playBackRate: number
   @observable currentVideoTime: number
   @observable videoStartTime!: number
   @observable progressEventDuration!: number
   @observable webinarDetails: GoogleAnalyticsWebinarObjectType
   @observable logsNetworkCallModel: LogsNetworkCallModel
   browserSessionId: string
   userId: string
   trackedDuration: number
   cumulativeOffset: number

   constructor(analyticsObject: GoogleAnalyticsModelType) {
      this.browserSessionId = analyticsObject.browserSessionId
      this.playBackRate = 1
      this.userId = analyticsObject.userId
      this.currentVideoTime = 0
      this.webinarDetails = analyticsObject.webinarDetails
      this.trackedDuration = 0
      this.cumulativeOffset = 0
      this.logsNetworkCallModel = new LogsNetworkCallModel(getLogsService())
   }

   @action.bound
   setVideoStartTime(value: number) {
      this.videoStartTime = value
   }

   @action.bound
   setProgressEventDuration(value: number) {
      this.progressEventDuration = value
   }

   @action.bound
   setOnPlayBackRateChangeValue(value: number) {
      this.playBackRate = value
   }
   @action.bound
   setCurrentVideoTime(value: number) {
      this.currentVideoTime = value
   }

   @action.bound
   resetCumulativeOffset() {
      this.cumulativeOffset = 0
   }

   @action.bound
   onVideoEnteredEvent(currentVideoTime: number): void {
      const videoScreenEnteredObject = {
         ...this.getEventTriggedDetails(
            googleAnalyticsEvent.videoScreenEntered,
            currentVideoTime
         )
      }
      this.pushDetailsToDataLayerAndLogEntries(videoScreenEnteredObject)
   }

   @action.bound
   onForwardEvent(currentVideoTime: number) {
      const progressEventDuration = this.getProgressEventDuration()
      if (progressEventDuration > 0) {
         const forwardEventObject = {
            ...this.getEventTriggedDetails(
               googleAnalyticsEvent.forward,
               currentVideoTime
            ),
            additionalData2: progressEventDuration
         }
         this.pushDetailsToDataLayerAndLogEntries(forwardEventObject)
      }
   }

   @action.bound
   onVideoPlayEvent(currentVideoTime: number): void {
      this.onForwardEvent(currentVideoTime)
      const videoPlayEventObject = {
         ...this.getEventTriggedDetails(
            googleAnalyticsEvent.play,
            currentVideoTime
         )
      }
      this.pushDetailsToDataLayerAndLogEntries(videoPlayEventObject)
   }

   @action.bound
   onVideoPauseEvent(currentVideoTime: number): void {
      const videoPauseEventObject = {
         ...this.getEventTriggedDetails(
            googleAnalyticsEvent.pause,
            currentVideoTime,
            true
         ),
         additionalData2: this.getProgressEventDuration()
      }
      this.pushDetailsToDataLayerAndLogEntries(videoPauseEventObject)
   }

   @action.bound
   onPlayBackRateChangeEvent(currentVideoTime: number): void {
      const videoPlayBackRateEventObject = {
         ...this.getEventTriggedDetails(
            googleAnalyticsEvent.playBackRateChange,
            currentVideoTime,
            true
         ),
         additionalData2: this.getProgressEventDuration()
      }
      this.pushDetailsToDataLayerAndLogEntries(videoPlayBackRateEventObject)
   }

   @action.bound
   onVideoEndEvent(videoCurrentTime: number): void {
      const videoEndEventObject = {
         ...this.getEventTriggedDetails(
            googleAnalyticsEvent.end,
            videoCurrentTime,
            true
         ),
         additionalData2: this.getProgressEventDuration()
      }
      this.pushDetailsToDataLayerAndLogEntries(videoEndEventObject)
   }

   @action.bound
   onVideoProgressEvent(
      videoCurrentTime: number,
      intervalUniqueId: number
   ): void {
      const videoProgressEventObject = {
         ...this.getEventTriggedDetails(
            googleAnalyticsEvent.progress,
            videoCurrentTime,
            true
         ),
         intervalUniqueId,
         additionalData2: this.getProgressEventDuration()
      }
      this.pushDetailsToDataLayerAndLogEntries(videoProgressEventObject)
   }

   @action.bound
   onVideoExitEvent(videoCurrentTime: number): void {
      const videoScreenExitEventObject = {
         ...this.getEventTriggedDetails(
            googleAnalyticsEvent.videoScreenExit,
            videoCurrentTime,
            true
         ),
         additionalData2: this.getProgressEventDuration()
      }
      this.pushDetailsToDataLayerAndLogEntries(videoScreenExitEventObject)
   }

   @action.bound
   getEventTriggedDetails(
      event: string,
      videoCurrentTime: number,
      requestWatchedDuration = false
   ) {
      const defaultTriggeredDetails = {
         eventSource: Config.ENVIRONMENT,
         event: event,
         browserSessionId: this.browserSessionId,
         playBackRate: this.playBackRate,
         userId: this.userId,
         videoCurrentTime: videoCurrentTime,
         eventTimeStamp: new Date().getTime()
      }

      if (requestWatchedDuration) {
         return {
            ...defaultTriggeredDetails,
            additionalData3: this.getWatchedDuration()
         }
      }

      return defaultTriggeredDetails
   }

   @action.bound
   getWatchedDuration() {
      const watchedDuration =
         ((new Date().getTime() - this.videoStartTime) / 1000) *
         this.playBackRate
      return Number.isNaN(watchedDuration) ? -1 : watchedDuration
   }

   @action.bound
   getProgressEventDuration() {
      const progressEventWatchedDuration =
         ((new Date().getTime() - this.progressEventDuration) / 1000) *
         this.playBackRate
      if (progressEventWatchedDuration > MAXIMUM_TIME_IN_PROGRESS_EVENT) {
         const exceedWatchedDuration = {
            event: 'exceed_watched_duration',
            progressEventStartTime: this.progressEventDuration,
            currentTime: new Date().getTime(),
            playBackRate: this.playBackRate
         }
         sendLogEntriesObjectData(exceedWatchedDuration)
      }
      return Number.isNaN(progressEventWatchedDuration)
         ? -1
         : progressEventWatchedDuration
   }

   @action.bound
   trackVideoDuration(eventObject) {
      // FIXME: Need to add type for event object here
      const {
         end,
         forward,
         videoScreenExit,
         playBackRateChange,
         progress,
         pause
      } = googleAnalyticsEvent
      const events = [
         end,
         forward,
         videoScreenExit,
         playBackRateChange,
         progress,
         pause
      ]
      const { additionalData2 } = eventObject

      if (additionalData2 > 0) {
         this.trackedDuration += additionalData2
         this.cumulativeOffset += getRoundedValue(additionalData2)

         const roundedDuration = getRoundedValue(this.trackedDuration)
         const {
            analyticsConfiguration,
            language,
            webinarId,
            webinarSlug
         } = this.webinarDetails
         const shouldTrackVideoWatchedDurationEvent =
            analyticsConfiguration.shouldTrackEvents &&
            roundedDuration >= VIDEO_WATCHED_DURATION_TRACKING_INTERVAL &&
            events.includes(eventObject.event)

         if (shouldTrackVideoWatchedDurationEvent) {
            trackEvent(VIDEO_WATCHED_DURATION_EVENT, {
               position: getRoundedValue(eventObject.videoCurrentTime),
               language,
               serial_number: analyticsConfiguration.serialNumber,
               webinar_category: analyticsConfiguration.webinarCategory,
               watched_duration: roundedDuration,
               webinar_slug: webinarSlug,
               cumulative_watched_duration:
                  getCumulativeWatchedDuration(getUserUUID(), webinarId) +
                  this.cumulativeOffset
            })
            this.trackedDuration = 0
         }
      }
   }

   @action.bound
   sendLogsToBackend(eventData): void {
      if (getPlatformFeatureFlags().enableWebinarLogsApi)
         this.logsNetworkCallModel.sendLogsToBackend(eventData)
   }

   @action.bound
   pushDetailsToDataLayerAndLogEntries(eventObject) {
      const addWebinarIdWithEventData = {
         ...eventObject,
         webinar_id: this.webinarDetails.webinarId
      }
      this.trackVideoDuration(eventObject)
      pushToDataLayer(addWebinarIdWithEventData)
      sendLogEntriesObjectData(addWebinarIdWithEventData)
      this.sendLogsToBackend(addWebinarIdWithEventData)
   }
}

export default GoogleAnalyticsModel
