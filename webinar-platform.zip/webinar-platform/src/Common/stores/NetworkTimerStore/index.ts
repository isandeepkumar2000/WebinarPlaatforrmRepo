import { observable, action } from 'mobx'
import { APIStatus, API_INITIAL } from '@ib/api-constants'

import { NetworkTimeObjectType } from '../../../ContentManagement/stores/types'
import NetworkTimeAPI from '../../../ContentManagement/services/NetworkTimeService/index.api'

import { captureError } from '../../utils/DecoratorLogEntriesUtils'
import { bindPromiseWithOnSuccess } from '../../utils/MobxPromise'
import { networkCallWithApisauce } from '../../utils/AuthAPIUtils'
import { getFormattedDateTimeFromNetworkDateTime } from '../../utils/DateUtils'

class NetworkTimerStore {
   @observable getCurrentNetworkDateTimeAPIStatus!: APIStatus
   @observable getCurrentNetworkDateTimeAPIError!: Error | null
   @observable currentNetworkDateTime!: string

   constructor() {
      this.getCurrentNetworkDateTimeAPIStatus = API_INITIAL
      this.getCurrentNetworkDateTimeAPIError = null
      this.currentNetworkDateTime = ''
   }

   @action.bound
   setCurrentNetworkDateTimeAPIStatus(status: APIStatus): void {
      this.getCurrentNetworkDateTimeAPIStatus = status
   }

   @action.bound
   @captureError('networkDateTimeAPI')
   setCurrentNetworkDateTimeAPIError(error: Error | null): void {
      this.getCurrentNetworkDateTimeAPIError = error
   }

   @action.bound
   setCurrentNetworkDateTimeAPIResponse(response: NetworkTimeObjectType) {
      this.currentNetworkDateTime = getFormattedDateTimeFromNetworkDateTime(
         response
      )
   }

   @action.bound
   getCurrentNetworkDateTimeAPI(
      onSuccess: Function = () => {},
      onFailure: Function = () => {}
   ) {
      const networkTimePromise = new NetworkTimeAPI(
         networkCallWithApisauce
      ).getCurrentNetworkDateTimeAPI()
      return bindPromiseWithOnSuccess(networkTimePromise)
         .to(this.setCurrentNetworkDateTimeAPIStatus, response => {
            this.setCurrentNetworkDateTimeAPIResponse(
               response as NetworkTimeObjectType
            )
            onSuccess()
         })
         .catch(error => {
            this.setCurrentNetworkDateTimeAPIError(error)
            onFailure()
         })
   }
}

export default NetworkTimerStore
