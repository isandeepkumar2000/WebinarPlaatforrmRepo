import uuid from 'uuid'

class UIStore {
   browserSessionId: string
   constructor() {
      this.browserSessionId = uuid.v4()
   }
}

export default UIStore
