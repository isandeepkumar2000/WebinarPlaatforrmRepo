import { networkCallWithApisauce as networkCallWithAPISauceWithoutAuth } from '../utils/AuthAPIUtils'
import { networkCallWithApisauce } from '../utils/APIUtils'

import ThemeStore from '../stores/ThemeStore'

import AuthFixture from '../../UserProfile/services/AuthService/index.fixture'
import AuthService from '../../UserProfile/services/AuthService/index.api'
import AuthStore from '../../UserProfile/stores/AuthStore'

import UserDetailsFixture from '../../UserProfile/services/UserDetailsService/index.fixture'
import UserDetailsService from '../../UserProfile/services/UserDetailsService/index.api'
import UserDetailsStore from '../../UserProfile/stores/UserDetailsStore'
import LiveWebinarStore from '../../LiveWebinar/stores/LiveWebinarStore'
import LiveWebinarService from '../../LiveWebinar/services/LiveWebinarService/index.api'

import QuestionFixture from '../../ContentManagement/services/QuestionService/index.fixture'
import QuestionService from '../../ContentManagement/services/QuestionService/index.api'
import QuestionStore from '../../ContentManagement/stores/QuestionStore'
import WebinarInfoStore from '../../ContentManagement/stores/WebinarInfoStore'
import { ActiveWebinarsStore } from '../../ContentManagement/stores/ActiveWebinarsStore/ActiveWebinarsStore'
import ActiveWebinarsFixtureService from '../../ContentManagement/services/ActiveWebinarsService/index.fixtures'
import ActiveWebinarsAPI from '../../ContentManagement/services/ActiveWebinarsService/index.api'
import UserPresenceStore from '../../LiveWebinar/stores/UserPresenceStore'
import IbEventsAPI from '../services/IbEventsService/index.api'
import IbEventsFixture from '../services/IbEventsService/index.fixture'

import AppsAndSubscriptionsAPI from '../services/AppsAndSubscriptionsService/index.api'
import AppsAndSubscriptionsFixture from '../services/AppsAndSubscriptionsService/index.fixture'

import LogsServiceApi from '../services/LogsService/index.api'
import LogsServiceFixture from '../services/LogsService/index.fixture'

import NetworkTimerStore from './NetworkTimerStore'
import AppsAndSubscriptionsStore from './AppsAndSubscriptionsStore'

import CommonUIStore from './UIStore'

export const isFixtures = false

const commonUIStore = new CommonUIStore()

const getAuthServiceInstance = () => {
   if (isFixtures) {
      return new AuthFixture()
   }
   return new AuthService(networkCallWithAPISauceWithoutAuth)
}

const authStore = new AuthStore(getAuthServiceInstance())
export const authNetworkCallWithApisauce = networkCallWithApisauce(authStore)

const getUserDetailsInstance = () => {
   if (isFixtures) {
      return new UserDetailsFixture()
   }
   return new UserDetailsService(
      networkCallWithAPISauceWithoutAuth,
      authNetworkCallWithApisauce
   )
}

const getQuestionInstance = () => {
   if (isFixtures) {
      return new QuestionFixture()
   }
   return new QuestionService(networkCallWithAPISauceWithoutAuth)
}

const getActiveWebinarService = () => {
   if (isFixtures) {
      return new ActiveWebinarsFixtureService()
   }
   return new ActiveWebinarsAPI(authNetworkCallWithApisauce)
}

export const getLogsService = () =>
   isFixtures
      ? new LogsServiceFixture()
      : new LogsServiceApi(authNetworkCallWithApisauce)

const questionStore = new QuestionStore(getQuestionInstance())
const userDetailsStore = new UserDetailsStore(getUserDetailsInstance())
const webinarInfoStore = new WebinarInfoStore()
const clearAllStores = (): void => {
   authStore.clearStore()
   userDetailsStore.clearStore()
}

const liveWebinarService = new LiveWebinarService(
   networkCallWithAPISauceWithoutAuth
)
const liveWebinarStore = new LiveWebinarStore(liveWebinarService)

export const getIbEventsServiceInstance = () => {
   if (isFixtures) {
      return new IbEventsFixture()
   }
   return new IbEventsAPI(authNetworkCallWithApisauce)
}

const activeWebinarsStore = new ActiveWebinarsStore(
   getActiveWebinarService(),
   getQuestionInstance(),
   getIbEventsServiceInstance()
)

const userPresenceStore = new UserPresenceStore()

const networkTimerStore = new NetworkTimerStore()

const appsAndSubscriptionsServiceInstance = () => {
   if (isFixtures) {
      return new AppsAndSubscriptionsFixture()
   }
   return new AppsAndSubscriptionsAPI(authNetworkCallWithApisauce)
}

const appsAndSubscriptionsStore = new AppsAndSubscriptionsStore(
   appsAndSubscriptionsServiceInstance()
)

authStore.setClearAllStoresFunction(clearAllStores)

export default {
   authStore,
   userDetailsStore,
   questionStore,
   webinarInfoStore,
   liveWebinarStore,
   activeWebinarsStore,
   userPresenceStore,
   commonUIStore,
   appsAndSubscriptionsStore,
   networkTimerStore
}

export const themeStore = new ThemeStore()
