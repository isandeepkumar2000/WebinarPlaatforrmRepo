import AnalyticsConfiguration from '../../ContentManagement/stores/models/AnalyticsConfiguration'

export interface SampleApiRequest {
   phone_number: string
   country_code: string
}

export interface IbEventsRequest {
   user_id: string
   webinar_id: string
   watch_duration_in_seconds: number
}

export interface SampleApiResponse {
   is_profile_updated: boolean
   is_new_user: boolean
}

export interface LabelValueType {
   value: string
   label: string
}

export interface ValidationResponseType {
   errorMessage: string
   shouldShowError: boolean
}

export interface GoogleAnalyticsWebinarObjectType {
   analyticsConfiguration: AnalyticsConfiguration
   language: string
   webinarId: string
   webinarSlug: string
}

export interface GoogleAnalyticsModelType {
   browserSessionId: string
   userId: string
   webinarDetails: GoogleAnalyticsWebinarObjectType
}

export interface UserSubscriptionType {
   user_id: string
   product_code: string
   order_id: string
   order_status: string
}

export interface UserAppsAndSubscriptionsResponseType {
   user_subscriptions: Array<UserSubscriptionType>
}

export interface FeatureFlagsType {
   enableSegmentAnalytics: boolean
   enableIbEventsAPI: boolean
   enableWebinarLogsApi: boolean
}

export interface LogoTypes {
   height?: string | number
   width?: string | number
   theme?: string
}

export interface VideoLogsRequestType {
   user_id: string
   webinar_id: string
   event_type: string
   browser_session_id: string
   video_position: number
   watched_duration?: number
}

export interface VideoLogsNetworkCallRequestType extends VideoLogsRequestType {
   request_id: string
}
