import { APIStatus, API_INITIAL } from '@ib/api-constants'
import { bindPromiseWithOnSuccess } from '@ib/mobx-promise'
import { action, observable } from 'mobx'

import AppsAndSubscriptionsService from '../../services/AppsAndSubscriptionsService'
import { captureError } from '../../utils/DecoratorLogEntriesUtils'

import UserSubscriptionModel from '../models/UserSubscriptionModel'
import { UserAppsAndSubscriptionsResponseType } from '../types'

class AppsAndSubscriptionsStore {
   appsAndSubscriptionsService: AppsAndSubscriptionsService

   @observable getAppsAndSubscriptionsAPIStatus!: APIStatus
   @observable getAppsAndSubscriptionsAPIError!: any
   @observable userAppsAndSubscriptions!: Array<UserSubscriptionModel>
   @observable productCodeArray!: Array<string>

   constructor(appsAndSubscriptionsService: AppsAndSubscriptionsService) {
      this.appsAndSubscriptionsService = appsAndSubscriptionsService
      this.init()
   }

   @action.bound
   init() {
      this.getAppsAndSubscriptionsAPIStatus = API_INITIAL
      this.getAppsAndSubscriptionsAPIError = null
      this.userAppsAndSubscriptions = []
      this.productCodeArray = []
   }

   @action.bound
   setGetAppsAndSubscriptionsAPIStatus(status: APIStatus) {
      this.getAppsAndSubscriptionsAPIStatus = status
   }

   @action.bound
   @captureError('appsAndSubscriptionsAPI')
   setGetAppsAndSubscriptionsAPIError(error: any) {
      this.getAppsAndSubscriptionsAPIError = error
   }

   @action.bound
   setUserAppsAndSubscriptionsResponse(
      response: UserAppsAndSubscriptionsResponseType
   ) {
      this.userAppsAndSubscriptions = response.user_subscriptions.map(
         eachSubscription => new UserSubscriptionModel(eachSubscription)
      )
      this.productCodeArray = this.userAppsAndSubscriptions.map(
         eachSubscription => eachSubscription.productCode
      )
   }

   @action.bound
   getUserAppsAndSubscriptions(
      onSuccess: Function = () => {},
      onFailure: Function = () => {}
   ) {
      const getUserAppsAndSubscriptionsPromise = this.appsAndSubscriptionsService.getUserAppsAndSubscriptions()

      return bindPromiseWithOnSuccess(getUserAppsAndSubscriptionsPromise)
         .to(this.setGetAppsAndSubscriptionsAPIStatus, response => {
            this.setUserAppsAndSubscriptionsResponse(
               response as UserAppsAndSubscriptionsResponseType
            )
            onSuccess()
         })
         .catch(error => {
            this.setGetAppsAndSubscriptionsAPIError(error)
            onFailure()
         })
   }
}

export default AppsAndSubscriptionsStore
