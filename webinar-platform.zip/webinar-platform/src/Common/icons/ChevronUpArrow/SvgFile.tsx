import React, { Component } from 'react'

interface Props {
   width?: number
   height?: number
   fill?: string
   className?: string
}

class SvgComponent extends Component<Props> {
   static defaultProps = {
      width: 20,
      height: 20
   }

   render() {
      const { width, height, fill } = this.props

      return (
         <svg
            xmlns='http://www.w3.org/2000/svg'
            width={width}
            height={height}
            fill={fill}
            {...this.props}
            viewBox='0 0 20 20'
         >
            <path
               fill={fill}
               fillRule='evenodd'
               d='M13.333 12.083c-.213 0-.426-.081-.589-.244L9.99 9.085l-2.744 2.65c-.332.32-.859.312-1.179-.02-.32-.332-.31-.86.02-1.18l3.334-3.218c.327-.315.847-.311 1.168.01l3.333 3.334c.326.326.326.852 0 1.178-.162.163-.375.244-.589.244z'
               clipRule='evenodd'
            />
         </svg>
      )
   }
}

export default SvgComponent
