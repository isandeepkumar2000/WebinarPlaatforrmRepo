import React, { Component } from 'react'

interface Props {
   width?: number
   height?: number
   className?: string
}

class OfflineIcon extends Component<Props> {
   static defaultProps = {
      height: 80,
      width: 80
   }

   render() {
      const { width, height } = this.props
      return (
         <svg
            xmlns='http://www.w3.org/2000/svg'
            width={width}
            height={height}
            fill='none'
            viewBox='0 0 80 80'
            {...this.props}
         >
            <mask
               id='prefix__a'
               width={70}
               height={60}
               x={5}
               y={10}
               maskUnits='userSpaceOnUse'
            >
               <path
                  fill='#ffffff'
                  fillRule='evenodd'
                  d='M13.716 11.75l51.867 51.867c1.3 1.3 1.3 3.4 0 4.633a3.32 3.32 0 01-4.7 0L39.648 47.017c-4.633.1-9.267 1.5-13.233 4.3-1.9 1.366-4.467 1.2-6.1-.434l-.034-.033c-2-2-1.866-5.367.434-7.034a32.115 32.115 0 0110.633-5.033l-7.433-7.433a42.275 42.275 0 00-10.834 6.433c-1.833 1.533-4.533 1.367-6.233-.333-1.966-1.967-1.833-5.233.334-7 3-2.467 6.266-4.5 9.633-6.167l-7.8-7.833a3.32 3.32 0 010-4.7 3.32 3.32 0 014.7 0zm59.433 25.7a4.703 4.703 0 01-6.3.3c-7.9-6.467-17.6-9.634-27.233-9.534l-8.633-8.633c14.5-2.566 29.866 1.067 41.833 10.867 2.166 1.767 2.3 5.033.333 7zm-22.267 2.066c2.967 1 5.8 2.434 8.4 4.334 1.767 1.267 2.234 3.566 1.434 5.5l-9.834-9.834zm-4.4 18.534c-4.066-2.1-8.933-2.1-13.033 0-1.966 1.033-2.333 3.733-.767 5.3l4.9 4.9c1.3 1.3 3.4 1.3 4.7 0l4.9-4.9c1.634-1.567 1.3-4.267-.7-5.3z'
                  clipRule='evenodd'
               />
            </mask>
            <g mask='url(#prefix__a)'>
               <path fill='#ffffff' d='M0 0h80v80H0z' />
            </g>
         </svg>
      )
   }
}

export default OfflineIcon
