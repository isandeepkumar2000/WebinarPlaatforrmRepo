import React from 'react'

function NoWebinarsIcon(props: any) {
   return (
      <svg
         xmlns='http://www.w3.org/2000/svg'
         width={props.width ?? '159'}
         height={props.height ?? '163'}
         fill='none'
         viewBox={`0 0 159 163`}
      >
         <path
            fill='url(#paint0_linear)'
            d='M132.25 147.61a68.01 68.01 0 01-23.178 11.409 79.917 79.917 0 01-8.402 1.848 81.681 81.681 0 01-7.846.923l-.576.039-.653.039c-.934.054-1.858.088-2.788.107-.59 0-1.18.025-1.766.025-.678 0-1.355 0-2.028-.025-.838 0-1.67-.048-2.498-.092a84.754 84.754 0 01-4.84-.389 77.763 77.763 0 01-8.915-1.503c-12.975-2.981-23.604-9.118-28.4-17.278-4.482-7.634.087-10.314-4.578-23.006C26.88 95.485 5.948 93.545.982 73.997c-2.986-11.75 1.501-23.202 4.58-28.526C24.992 11.883 117.323-.377 148.158 48.34c17.936 28.336 14.273 76.055-15.909 99.27z'
         ></path>
         <path
            fill='url(#paint1_linear)'
            d='M118.461 143.068c-1.06 3.628-5.914 3.964-6.393 7.402-.145 1.045.29 1.094.334 2.349.072 2.202-1.278 4.376-3.33 6.19-2.766.77-5.57 1.39-8.402 1.858a81.681 81.681 0 01-5.987.773 6.008 6.008 0 01-.9-.511c-1.53-1.196-.484-4.347.12-5.777.572-1.357 1.777-5.66 4.986-8.223 1.452-1.153 2.265-.919 3.325-1.425.353-.188.685-.413.992-.671 1.597-1.318 1.35-5.315 2.768-7.197 2.12-2.806 9.404-2.816 11.781.798a5.51 5.51 0 01.706 4.434z'
         ></path>
         <path
            stroke='#fff'
            strokeMiterlimit='10'
            strokeWidth='0.52'
            d='M112.818 141.235a65.76 65.76 0 00-4.68 4.654 66.57 66.57 0 00-9.307 13.13 11.447 11.447 0 015.357-5.004 10.58 10.58 0 012.904-.783'
            opacity='0.7'
         ></path>
         <path
            style={{ mixBlendMode: 'multiply' }}
            fill='url(#paint2_radial)'
            d='M118.461 143.068c-1.06 3.628-5.914 3.964-6.393 7.402-.145 1.045.29 1.094.334 2.349.072 2.202-1.278 4.376-3.33 6.19-2.766.77-5.57 1.39-8.402 1.858a81.681 81.681 0 01-5.987.773 6.008 6.008 0 01-.9-.511c-1.53-1.196-.484-4.347.12-5.777.572-1.357 1.777-5.66 4.986-8.223 1.452-1.153 2.265-.919 3.325-1.425.353-.188.685-.413.992-.671 1.597-1.318 1.35-5.315 2.768-7.197 2.12-2.806 9.404-2.816 11.781.798a5.51 5.51 0 01.706 4.434z'
         ></path>
         <path
            style={{ mixBlendMode: 'multiply' }}
            fill='url(#paint3_linear)'
            d='M118.461 143.068c-1.06 3.628-5.914 3.964-6.393 7.402-.145 1.045.29 1.094.334 2.349.072 2.202-1.278 4.376-3.33 6.19-2.766.77-5.57 1.39-8.402 1.858a81.681 81.681 0 01-5.987.773 6.008 6.008 0 01-.9-.511c-1.53-1.196-.484-4.347.12-5.777.572-1.357 1.777-5.66 4.986-8.223 1.452-1.153 2.265-.919 3.325-1.425.353-.188.685-.413.992-.671 1.597-1.318 1.35-5.315 2.768-7.197 2.12-2.806 9.404-2.816 11.781.798a5.51 5.51 0 01.706 4.434z'
         ></path>
         <path
            fill='url(#paint4_linear)'
            d='M100.67 96.088v64.779c-2.787.47-5.596.794-8.417.972l-.658.039v-65.79h9.075z'
         ></path>
         <path
            fill='url(#paint5_linear)'
            d='M92.273 96.088v65.742l-.659.038a74.7 74.7 0 01-2.782.107V96.088h3.44z'
         ></path>
         <path
            fill='url(#paint6_linear)'
            d='M77.487 45.495h11.93c11.191 0 21.923 4.467 29.836 12.417s12.358 18.734 12.358 29.977v13.13H35.298v-13.13a42.495 42.495 0 0112.356-29.975 42.094 42.094 0 0129.833-12.419z'
         ></path>
         <path
            fill='url(#paint7_linear)'
            d='M131.437 100.995h-51.71v-3.779h51.71c.498 0 .976.2 1.328.553a1.893 1.893 0 01.408 2.058 1.9 1.9 0 01-.406.614 1.873 1.873 0 01-1.33.554z'
         ></path>
         <path
            fill='url(#paint8_linear)'
            d='M81.238 101.014H37.29l.218-37.497a19.194 19.194 0 015.617-13.472 19.01 19.01 0 0113.438-5.571h2.7c2.886 0 5.743.57 8.41 1.68a21.99 21.99 0 017.128 4.786 22.083 22.083 0 014.763 7.163 22.17 22.17 0 011.673 8.448v34.463z'
         ></path>
         <path
            fill='url(#paint9_linear)'
            d='M56.4 44.474c2.885 0 5.742.57 8.408 1.68a21.983 21.983 0 017.129 4.786 22.083 22.083 0 014.763 7.163 22.168 22.168 0 011.672 8.448v34.463h-43.94V66.551a22.132 22.132 0 016.433-15.61 21.92 21.92 0 0115.534-6.467z'
         ></path>
         <path
            fill='url(#paint10_linear)'
            d='M56.4 49.118c4.877 0 9.555 1.947 13.004 5.412a18.522 18.522 0 015.387 13.067v33.383H37.988V67.63a18.574 18.574 0 011.392-7.086 18.504 18.504 0 013.99-6.009 18.392 18.392 0 015.977-4.013 18.305 18.305 0 017.052-1.404z'
         ></path>
         <path
            fill='url(#paint11_linear)'
            d='M3.93 97.26h70.885v3.779H3.93c-.498 0-.976-.199-1.328-.553a1.893 1.893 0 01-.408-2.058c.094-.23.232-.438.407-.613.174-.176.381-.316.61-.41.228-.096.472-.145.72-.145z'
         ></path>
         <path
            fill='url(#paint12_linear)'
            d='M16.63 106.787c4.196-1.231 16.533 15.308 12.235 27.105-.227.632-1.98 5.442-4.728 5.593-3.954.214-7.962-9.357-9.196-16.768-.828-5.149-1.278-15.06 1.689-15.93z'
         ></path>
         <path
            stroke='url(#paint13_linear)'
            strokeLinecap='round'
            strokeMiterlimit='10'
            strokeWidth='2.57'
            d='M74.713 91.965c-2.811-.428-41.061-6.668-49.013-28.103-.997-2.675-3.872-10.13-.716-17.453 2.086-4.863 7.032-10.48 10.822-9.862.929.156 2.604.812 2.865 1.999.218.972-.6 2.008-1.384 2.524-1.631 1.06-3.838.379-4.618.136-4.457-1.381-8.13-8.136-8.344-13.529-.324-8.267 7.449-16.913 19.452-20.959'
         ></path>
         <path
            fill='url(#paint14_linear)'
            d='M48.181 5.196a3.187 3.187 0 00.286-4.012c-.784-1.011-2.338-1.492-3-.972-.79.627-.456 2.708.914 5.227-1.936-2.703-2.735-3.049-3.117-2.888-.528.219-.74 1.62-.102 2.606a2.31 2.31 0 002.236 1.007'
         ></path>
         <path
            fill='url(#paint15_linear)'
            d='M48.36 5.415a3.156 3.156 0 011.877 1.004 3.19 3.19 0 01.82 1.972c0 1.284-.916 2.626-1.767 2.626-.998 0-2.019-1.867-2.493-4.673.15 3.321-.271 4.094-.668 4.206-.552.151-1.602-.822-1.684-1.984a2.319 2.319 0 011.137-2.183'
         ></path>
         <path
            stroke='url(#paint16_linear)'
            strokeLinecap='round'
            strokeMiterlimit='10'
            strokeWidth='1.28'
            d='M49.222 5.293a7.55 7.55 0 012.87-.209c.517.063 1.027.18 1.52.35'
         ></path>
         <path
            stroke='url(#paint17_linear)'
            strokeLinecap='round'
            strokeMiterlimit='10'
            strokeWidth='1.28'
            d='M49.169 4.55a5.18 5.18 0 002.72-1.824c.147-.2.275-.413.382-.637'
         ></path>
         <path
            fill='url(#paint18_linear)'
            d='M48.529 4.176L43.864 5.8a.915.915 0 00-.562 1.163.91.91 0 001.158.565l4.665-1.624a.916.916 0 00.562-1.163.91.91 0 00-1.158-.565z'
         ></path>
         <path
            fill='url(#paint19_linear)'
            d='M92.844 161.791l-.576.038-.654.039c-.934.054-1.858.088-2.787.107-.59 0-1.181.025-1.767.025a85.634 85.634 0 01-9.35-.487c-4.753-4.576-8.504-10.601-7.125-14.17.484-1.206 1.128-1.114 1.631-2.485 1.738-4.727-5.208-8.388-5.222-14.185 0-6.239 8.03-13.037 12.826-11.608 2.42.725 3.654 3.453 4.075 4.377 2.821 6.322-2.12 11.219.595 15.284 1.81 2.713 4.279.934 7.149 3.827 4.965 4.999 2.303 15.094 1.205 19.238z'
         ></path>
         <path
            stroke='#fff'
            strokeMiterlimit='10'
            strokeWidth='1.04'
            d='M75.55 126.948A82.518 82.518 0 0087.06 162'
            opacity='0.7'
         ></path>
         <path
            style={{ mixBlendMode: 'multiply' }}
            fill='url(#paint20_linear)'
            d='M92.844 161.791l-.576.038-.654.039c-.934.054-1.858.088-2.787.107-.59 0-1.181.025-1.767.025a85.634 85.634 0 01-9.35-.487c-4.753-4.576-8.504-10.601-7.125-14.17.484-1.206 1.128-1.114 1.631-2.485 1.738-4.727-5.208-8.388-5.222-14.185 0-6.239 8.03-13.037 12.826-11.608 2.42.725 3.654 3.453 4.075 4.377 2.821 6.322-2.12 11.219.595 15.284 1.81 2.713 4.279.934 7.149 3.827 4.965 4.999 2.303 15.094 1.205 19.238z'
         ></path>
         <path
            fill='url(#paint21_linear)'
            d='M85.032 161.975c-.837 0-1.67-.048-2.497-.092a84.608 84.608 0 01-4.84-.389 77.793 77.793 0 01-8.934-1.503c-.059-.1-.11-.204-.155-.311-.968-2.164.44-2.874-.649-4.547-1.534-2.358-5.358-1.011-8.02-3.978-.343-.384-1.379-2.178-1.297-3.729.189-3.696 6.64-6.872 10.46-5.316 3.547 1.459 3.62 6.57 6.824 6.881 1.582.156 1.989-.792 3.387-.632 3.587.404 6.752 9.405 5.721 13.616z'
         ></path>
         <path
            stroke='#fff'
            strokeMiterlimit='10'
            strokeWidth='0.93'
            d='M66.442 147.737a53.537 53.537 0 0116.093 14.146'
            opacity='0.7'
         ></path>
         <path
            style={{ mixBlendMode: 'multiply' }}
            fill='url(#paint22_linear)'
            d='M85.032 161.975c-.837 0-1.67-.048-2.497-.092a84.608 84.608 0 01-4.84-.389 77.793 77.793 0 01-8.934-1.503c-.059-.1-.11-.204-.155-.311-.968-2.164.44-2.874-.649-4.547-1.534-2.358-5.358-1.011-8.02-3.978-.343-.384-1.379-2.178-1.297-3.729.189-3.696 6.64-6.872 10.46-5.316 3.547 1.459 3.62 6.57 6.824 6.881 1.582.156 1.989-.792 3.387-.632 3.587.404 6.752 9.405 5.721 13.616z'
         ></path>
         <path
            style={{ mixBlendMode: 'multiply' }}
            fill='url(#paint23_radial)'
            d='M131.331 71.4v26.099c-1.002.107-2.008.16-3.016.16a27.542 27.542 0 01-10.582-2.112 27.639 27.639 0 01-8.971-6.022 27.793 27.793 0 01-5.992-9.015 27.89 27.89 0 01-2.1-10.633c0-.703.024-1.398.072-2.086a27.807 27.807 0 018.64-18.163l19.18 15.868a7.666 7.666 0 011.868 2.295c.094.172.178.35.252.53.429.97.65 2.018.649 3.079z'
         ></path>
         <path
            fill='url(#paint24_linear)'
            d='M128.31 85.137c8.388 0 15.188-6.832 15.188-15.26 0-8.427-6.8-15.26-15.188-15.26-8.387 0-15.187 6.833-15.187 15.26 0 8.428 6.8 15.26 15.187 15.26z'
         ></path>
         <path
            style={{ mixBlendMode: 'screen' }}
            fill='url(#paint25_linear)'
            d='M143.498 69.877a15.296 15.296 0 01-2.382 8.21 15.193 15.193 0 01-6.407 5.63 15.019 15.019 0 005.349-4.583 15.14 15.14 0 002.113-13.569 15.08 15.08 0 00-3.699-6.006 14.994 14.994 0 00-6.017-3.654 14.937 14.937 0 00-13.482 2.267 15.057 15.057 0 00-4.505 5.423 15.22 15.22 0 017-7.36 15.114 15.114 0 0110.049-1.3 15.177 15.177 0 018.627 5.34 15.31 15.31 0 013.364 9.602h-.01z'
         ></path>
         <path
            fill='#FBE9E5'
            d='M123.141 69.858c0-2.334.444-4.103 1.331-5.305a4.498 4.498 0 013.829-1.8c1.781 0 3.089.59 3.925 1.77.836 1.18 1.255 2.964 1.258 5.35 0 2.317-.448 4.088-1.345 5.31a4.47 4.47 0 01-3.838 1.833 5.03 5.03 0 01-2.299-.486 4.248 4.248 0 01-1.607-1.43 6.681 6.681 0 01-.944-2.251 12.966 12.966 0 01-.31-2.991zm2.803 0a9.386 9.386 0 00.547 3.55 1.868 1.868 0 001.81 1.303 1.884 1.884 0 001.834-1.177c.365-.784.545-2.01.542-3.676a14.643 14.643 0 00-.126-2.008 5.778 5.778 0 00-.401-1.518 2.28 2.28 0 00-.726-.972 1.876 1.876 0 00-1.123-.33 1.869 1.869 0 00-1.81 1.22 9.173 9.173 0 00-.547 3.608z'
         ></path>
         <defs>
            <linearGradient
               id='paint0_linear'
               x1='20.042'
               x2='130.415'
               y1='-51.14'
               y2='174.523'
               gradientUnits='userSpaceOnUse'
            >
               <stop stopColor='#99C4DE'></stop>
               <stop offset='0.65' stopColor='#D4E6F0'></stop>
               <stop offset='1' stopColor='#EEF5F8'></stop>
            </linearGradient>
            <linearGradient
               id='paint1_linear'
               x1='114.493'
               x2='101.502'
               y1='143.953'
               y2='151.946'
               gradientUnits='userSpaceOnUse'
            >
               <stop stopColor='#C4DFCC'></stop>
               <stop offset='0.17' stopColor='#BBDAC6'></stop>
               <stop offset='0.68' stopColor='#A3CCB6'></stop>
               <stop offset='1' stopColor='#9AC7B0'></stop>
            </linearGradient>
            <linearGradient
               id='paint3_linear'
               x1='5285.64'
               x2='5685.49'
               y1='8066.55'
               y2='8016.06'
               gradientUnits='userSpaceOnUse'
            >
               <stop offset='0.18' stopColor='#9AC7B0'></stop>
               <stop offset='0.27' stopColor='#9EC9B3' stopOpacity='0.9'></stop>
               <stop
                  offset='0.46'
                  stopColor='#A9CFBA'
                  stopOpacity='0.65'
               ></stop>
               <stop
                  offset='0.72'
                  stopColor='#BAD9C5'
                  stopOpacity='0.25'
               ></stop>
               <stop offset='0.88' stopColor='#C4DFCC' stopOpacity='0'></stop>
            </linearGradient>
            <linearGradient
               id='paint4_linear'
               x1='96.149'
               x2='96.149'
               y1='156.889'
               y2='101.345'
               gradientUnits='userSpaceOnUse'
            >
               <stop stopColor='#2059B1'></stop>
               <stop offset='0.18' stopColor='#2662B7'></stop>
               <stop offset='0.49' stopColor='#387BC7'></stop>
               <stop offset='0.87' stopColor='#54A3E1'></stop>
               <stop offset='1' stopColor='#5FB3EB'></stop>
            </linearGradient>
            <linearGradient
               id='paint5_linear'
               x1='90.55'
               x2='90.55'
               y1='148.671'
               y2='81.767'
               gradientUnits='userSpaceOnUse'
            >
               <stop stopColor='#6BA3D8'></stop>
               <stop offset='0.16' stopColor='#75ABDB'></stop>
               <stop offset='0.44' stopColor='#8FBFE3'></stop>
               <stop offset='0.79' stopColor='#BAE0EF'></stop>
               <stop offset='1' stopColor='#D7F7F8'></stop>
            </linearGradient>
            <linearGradient
               id='paint6_linear'
               x1='83.45'
               x2='83.45'
               y1='41.59'
               y2='100.387'
               gradientUnits='userSpaceOnUse'
            >
               <stop stopColor='#F9DE5B'></stop>
               <stop offset='0.21' stopColor='#FFE361'></stop>
               <stop offset='0.25' stopColor='#FDD851'></stop>
               <stop offset='0.35' stopColor='#F9C534'></stop>
               <stop offset='0.44' stopColor='#F7B71D'></stop>
               <stop offset='0.55' stopColor='#F5AC0D'></stop>
               <stop offset='0.67' stopColor='#F3A604'></stop>
               <stop offset='0.84' stopColor='#F3A401'></stop>
               <stop offset='0.92' stopColor='#F39805'></stop>
               <stop offset='1' stopColor='#F39007'></stop>
            </linearGradient>
            <linearGradient
               id='paint7_linear'
               x1='138.915'
               x2='80.919'
               y1='96.084'
               y2='101.334'
               gradientUnits='userSpaceOnUse'
            >
               <stop stopColor='#F9DE5B' stopOpacity='0.99'></stop>
               <stop offset='1' stopColor='#F3A401'></stop>
            </linearGradient>
            <linearGradient
               id='paint8_linear'
               x1='59.265'
               x2='59.265'
               y1='46.234'
               y2='97.669'
               gradientUnits='userSpaceOnUse'
            >
               <stop offset='0.01' stopColor='#F2F7F8'></stop>
               <stop offset='0.7' stopColor='#89B5D4'></stop>
            </linearGradient>
            <linearGradient
               id='paint9_linear'
               x1='46.032'
               x2='61.439'
               y1='40.506'
               y2='102.191'
               gradientUnits='userSpaceOnUse'
            >
               <stop stopColor='#F2F7F8'></stop>
               <stop offset='0.04' stopColor='#EBF3F6'></stop>
               <stop offset='0.37' stopColor='#B0D0E9'></stop>
               <stop offset='0.65' stopColor='#85B6E0'></stop>
               <stop offset='0.87' stopColor='#6BA6DA'></stop>
               <stop offset='1' stopColor='#61A0D8'></stop>
            </linearGradient>
            <linearGradient
               id='paint10_linear'
               x1='9.302'
               x2='80.348'
               y1='42.991'
               y2='97.984'
               gradientUnits='userSpaceOnUse'
            >
               <stop offset='0.1' stopColor='#228DF5'></stop>
               <stop offset='0.17' stopColor='#2083E6'></stop>
               <stop offset='0.45' stopColor='#1A5BAF'></stop>
               <stop offset='0.69' stopColor='#163F86'></stop>
               <stop offset='0.88' stopColor='#132D6D'></stop>
               <stop offset='1' stopColor='#122764'></stop>
            </linearGradient>
            <linearGradient
               id='paint11_linear'
               x1='2.052'
               x2='74.815'
               y1='99.128'
               y2='99.128'
               gradientUnits='userSpaceOnUse'
            >
               <stop stopColor='#F9DE5B'></stop>
               <stop offset='0.64' stopColor='#F3A401'></stop>
               <stop offset='0.82' stopColor='#F39805'></stop>
               <stop offset='1' stopColor='#F39007'></stop>
            </linearGradient>
            <linearGradient
               id='paint12_linear'
               x1='-1486.13'
               x2='7930.25'
               y1='-1128.57'
               y2='7985.52'
               gradientUnits='userSpaceOnUse'
            >
               <stop stopColor='#99C4DE'></stop>
               <stop offset='0.65' stopColor='#D4E6F0'></stop>
               <stop offset='1' stopColor='#EEF5F8'></stop>
            </linearGradient>
            <linearGradient
               id='paint13_linear'
               x1='68.969'
               x2='23.581'
               y1='95.972'
               y2='16.683'
               gradientUnits='userSpaceOnUse'
            >
               <stop stopColor='#4696D8'></stop>
               <stop offset='0.24' stopColor='#509BD9'></stop>
               <stop offset='0.63' stopColor='#6AA9DC'></stop>
               <stop offset='1' stopColor='#88B9E0'></stop>
            </linearGradient>
            <linearGradient
               id='paint14_linear'
               x1='679.204'
               x2='576.187'
               y1='10.578'
               y2='97.57'
               gradientUnits='userSpaceOnUse'
            >
               <stop stopColor='#F2F7F8'></stop>
               <stop offset='0.04' stopColor='#EBF3F6'></stop>
               <stop offset='0.37' stopColor='#B0D0E9'></stop>
               <stop offset='0.65' stopColor='#85B6E0'></stop>
               <stop offset='0.87' stopColor='#6BA6DA'></stop>
               <stop offset='1' stopColor='#61A0D8'></stop>
            </linearGradient>
            <linearGradient
               id='paint15_linear'
               x1='759.765'
               x2='665.152'
               y1='60.203'
               y2='153.208'
               gradientUnits='userSpaceOnUse'
            >
               <stop stopColor='#F2F7F8'></stop>
               <stop offset='0.04' stopColor='#EBF3F6'></stop>
               <stop offset='0.37' stopColor='#B0D0E9'></stop>
               <stop offset='0.65' stopColor='#85B6E0'></stop>
               <stop offset='0.87' stopColor='#6BA6DA'></stop>
               <stop offset='1' stopColor='#61A0D8'></stop>
            </linearGradient>
            <linearGradient
               id='paint16_linear'
               x1='492.809'
               x2='538.287'
               y1='9.37'
               y2='9.37'
               gradientUnits='userSpaceOnUse'
            >
               <stop stopColor='#2059B1'></stop>
               <stop offset='0.18' stopColor='#2662B7'></stop>
               <stop offset='0.49' stopColor='#387BC7'></stop>
               <stop offset='0.87' stopColor='#54A3E1'></stop>
               <stop offset='1' stopColor='#5FB3EB'></stop>
            </linearGradient>
            <linearGradient
               id='paint17_linear'
               x1='362.353'
               x2='386.304'
               y1='18.87'
               y2='18.87'
               gradientUnits='userSpaceOnUse'
            >
               <stop stopColor='#2059B1'></stop>
               <stop offset='0.18' stopColor='#2662B7'></stop>
               <stop offset='0.49' stopColor='#387BC7'></stop>
               <stop offset='0.87' stopColor='#54A3E1'></stop>
               <stop offset='1' stopColor='#5FB3EB'></stop>
            </linearGradient>
            <linearGradient
               id='paint18_linear'
               x1='49.95'
               x2='45.881'
               y1='-2.062'
               y2='7.159'
               gradientUnits='userSpaceOnUse'
            >
               <stop stopColor='#5FB3EB'></stop>
               <stop offset='0.13' stopColor='#54A3E1'></stop>
               <stop offset='0.51' stopColor='#387BC7'></stop>
               <stop offset='0.82' stopColor='#2662B7'></stop>
               <stop offset='1' stopColor='#2059B1'></stop>
            </linearGradient>
            <linearGradient
               id='paint19_linear'
               x1='4765.24'
               x2='4378.12'
               y1='11120.6'
               y2='13550'
               gradientUnits='userSpaceOnUse'
            >
               <stop stopColor='#C4DFCC'></stop>
               <stop offset='0.17' stopColor='#BBDAC6'></stop>
               <stop offset='0.68' stopColor='#A3CCB6'></stop>
               <stop offset='1' stopColor='#9AC7B0'></stop>
            </linearGradient>
            <linearGradient
               id='paint20_linear'
               x1='74.336'
               x2='86.344'
               y1='155.362'
               y2='133.527'
               gradientUnits='userSpaceOnUse'
            >
               <stop stopColor='#9AC7B0'></stop>
               <stop
                  offset='0.34'
                  stopColor='#ACD1BC'
                  stopOpacity='0.58'
               ></stop>
               <stop
                  offset='0.71'
                  stopColor='#BDDBC7'
                  stopOpacity='0.16'
               ></stop>
               <stop offset='0.88' stopColor='#C4DFCC' stopOpacity='0'></stop>
            </linearGradient>
            <linearGradient
               id='paint21_linear'
               x1='4299.87'
               x2='4033.9'
               y1='6194.87'
               y2='6783.6'
               gradientUnits='userSpaceOnUse'
            >
               <stop stopColor='#C4DFCC'></stop>
               <stop offset='0.17' stopColor='#BBDAC6'></stop>
               <stop offset='0.68' stopColor='#A3CCB6'></stop>
               <stop offset='1' stopColor='#9AC7B0'></stop>
            </linearGradient>
            <linearGradient
               id='paint22_linear'
               x1='3982.87'
               x2='4015.16'
               y1='6762.43'
               y2='6369.53'
               gradientUnits='userSpaceOnUse'
            >
               <stop stopColor='#9AC7B0'></stop>
               <stop
                  offset='0.34'
                  stopColor='#ACD1BC'
                  stopOpacity='0.58'
               ></stop>
               <stop
                  offset='0.71'
                  stopColor='#BDDBC7'
                  stopOpacity='0.16'
               ></stop>
               <stop offset='0.88' stopColor='#C4DFCC' stopOpacity='0'></stop>
            </linearGradient>
            <linearGradient
               id='paint24_linear'
               x1='115.185'
               x2='141.969'
               y1='83.066'
               y2='56.408'
               gradientUnits='userSpaceOnUse'
            >
               <stop offset='0.01' stopColor='#CC1E13'></stop>
               <stop offset='0.15' stopColor='#D02519'></stop>
               <stop offset='0.36' stopColor='#DC3A28'></stop>
               <stop offset='0.61' stopColor='#EF5B42'></stop>
               <stop offset='0.64' stopColor='#F25F45'></stop>
               <stop offset='1' stopColor='#F89574'></stop>
            </linearGradient>
            <linearGradient
               id='paint25_linear'
               x1='7816.58'
               x2='7886.68'
               y1='5116.14'
               y2='3118.8'
               gradientUnits='userSpaceOnUse'
            >
               <stop offset='0.01' stopColor='#CC1E13'></stop>
               <stop offset='0.15' stopColor='#D02519'></stop>
               <stop offset='0.36' stopColor='#DC3A28'></stop>
               <stop offset='0.61' stopColor='#EF5B42'></stop>
               <stop offset='0.64' stopColor='#F25F45'></stop>
               <stop offset='1' stopColor='#F89574'></stop>
            </linearGradient>
            <radialGradient
               id='paint2_radial'
               cx='0'
               cy='0'
               r='1'
               gradientTransform='matrix(-6.55433 -10.31722 11.12035 -7.06454 103.18 142.317)'
               gradientUnits='userSpaceOnUse'
            >
               <stop offset='0.18' stopColor='#9AC7B0'></stop>
               <stop offset='0.27' stopColor='#9EC9B3' stopOpacity='0.9'></stop>
               <stop
                  offset='0.46'
                  stopColor='#A9CFBA'
                  stopOpacity='0.65'
               ></stop>
               <stop
                  offset='0.72'
                  stopColor='#BAD9C5'
                  stopOpacity='0.25'
               ></stop>
               <stop offset='0.88' stopColor='#C4DFCC' stopOpacity='0'></stop>
            </radialGradient>
            <radialGradient
               id='paint23_radial'
               cx='0'
               cy='0'
               r='1'
               gradientTransform='matrix(24.5092 0 0 24.6256 128.402 69.785)'
               gradientUnits='userSpaceOnUse'
            >
               <stop offset='0.01' stopColor='#BABBBB'></stop>
               <stop
                  offset='0.12'
                  stopColor='#BDBDBD'
                  stopOpacity='0.94'
               ></stop>
               <stop
                  offset='0.31'
                  stopColor='#C4C3C2'
                  stopOpacity='0.78'
               ></stop>
               <stop
                  offset='0.56'
                  stopColor='#D0CDCA'
                  stopOpacity='0.52'
               ></stop>
               <stop
                  offset='0.86'
                  stopColor='#E0DBD6'
                  stopOpacity='0.17'
               ></stop>
               <stop offset='1' stopColor='#E8E1DB' stopOpacity='0'></stop>
            </radialGradient>
         </defs>
      </svg>
   )
}

export default NoWebinarsIcon
