import React, { Component } from 'react'

interface Props {
   height?: number
   width?: number
}

class AlarmClockIcon extends Component<Props> {
   static defaultProps = {
      height: 30,
      width: 30
   }

   render() {
      const { height, width } = this.props

      return (
         <svg
            width={height}
            height={width}
            viewBox='0 0 30 30'
            fill='none'
            xmlns='http://www.w3.org/2000/svg'
            {...this.props}
         >
            <mask
               id='prefix__a'
               maskUnits='userSpaceOnUse'
               x={2}
               y={2}
               width={26}
               height={26}
            >
               <path
                  fillRule='evenodd'
                  clipRule='evenodd'
                  d='M14.988 2.5C8.088 2.5 2.5 8.1 2.5 15s5.588 12.5 12.488 12.5C21.9 27.5 27.5 21.9 27.5 15S21.9 2.5 14.988 2.5zM15 25C9.475 25 5 20.525 5 15S9.475 5 15 5s10 4.475 10 10-4.475 10-10 10zm-.35-16.25h.075c.5 0 .9.4.9.9v5.675l4.837 2.875c.438.25.576.813.313 1.238-.25.425-.8.55-1.225.3l-5.188-3.113a1.238 1.238 0 01-.612-1.075v-5.9c0-.5.4-.9.9-.9z'
                  fill='#fff'
               />
            </mask>
            <g mask='url(#prefix__a)'>
               <path fill='#fff' d='M0 0h30v30H0z' />
            </g>
         </svg>
      )
   }
}

export default AlarmClockIcon
