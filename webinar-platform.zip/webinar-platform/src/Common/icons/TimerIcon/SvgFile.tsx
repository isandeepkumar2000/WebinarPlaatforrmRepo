import React from 'react'
import { withTheme } from 'styled-components'

function TimerIcon(props: any) {
   return (
      <svg
         xmlns='http://www.w3.org/2000/svg'
         width='12'
         height='12'
         fill='none'
         viewBox='0 0 12 12'
      >
         <path
            stroke={props.theme.primarySvgIconColor}
            strokeLinecap='round'
            strokeLinejoin='round'
            d='M6 3.78V6l1.667 1.665M11 6c0 .656-.13 1.306-.38 1.912a5.011 5.011 0 01-2.707 2.703 5.018 5.018 0 01-3.826 0 4.993 4.993 0 01-1.623-8.147 5.003 5.003 0 017.072 0A4.995 4.995 0 0111 6z'
         ></path>
      </svg>
   )
}

export default withTheme(TimerIcon)
