import React from 'react'

function SvgComponent() {
   return (
      <svg
         xmlns='http://www.w3.org/2000/svg'
         width='20'
         height='20'
         fill='none'
         viewBox='0 0 20 20'
      >
         <path
            stroke='#9AA5B1'
            d='M19.5 10c0 5.247-4.253 9.5-9.5 9.5S.5 15.247.5 10 4.753.5 10 .5s9.5 4.253 9.5 9.5z'
         ></path>
      </svg>
   )
}

export default SvgComponent
