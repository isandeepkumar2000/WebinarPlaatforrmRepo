import React from 'react'
import { withTheme } from 'styled-components'

function CalenderIcon(props: any) {
   return (
      <svg
         xmlns='http://www.w3.org/2000/svg'
         width='12'
         height='12'
         fill='none'
         viewBox='0 0 12 12'
      >
         <path
            stroke={props.theme.primarySvgIconColor}
            strokeLinecap='round'
            strokeLinejoin='round'
            d='M3.778 3.225v-2.22m4.444 2.22v-2.22m-5 4.44h5.556m-6.667 5.55H9.89a1.114 1.114 0 001.111-1.11v-6.66a1.111 1.111 0 00-1.111-1.11H2.11a1.114 1.114 0 00-1.111 1.11v6.66a1.11 1.11 0 001.111 1.11z'
         ></path>
      </svg>
   )
}

export default withTheme(CalenderIcon)
