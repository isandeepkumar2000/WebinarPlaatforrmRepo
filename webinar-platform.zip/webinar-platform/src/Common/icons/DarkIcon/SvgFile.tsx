import React, { Component } from 'react'

interface Props {
   width?: number
   height?: number
   fill?: string
   className?: string
}

class SvgComponent extends Component<Props> {
   static defaultProps = {
      width: 24,
      height: 24,
      fill: `#7B8794`
   }

   render() {
      const { width, height, fill } = this.props

      return (
         <svg
            xmlns='http://www.w3.org/2000/svg'
            width={height}
            height={width}
            fill='none'
            viewBox='0 0 24 24'
            {...this.props}
         >
            <path
               fill={fill}
               d='M17.11 15.719c-4.91 0-8.89-3.985-8.89-8.9 0-1.097.2-2.147.562-3.117.239-.638-.322-1.348-.939-1.059C4.391 4.263 2 7.773 2 11.843 2 17.453 6.542 22 12.145 22c4.103 0 7.635-2.44 9.232-5.948.283-.62-.434-1.173-1.07-.927-.992.383-2.07.594-3.197.594z'
            />
         </svg>
      )
   }
}

export default SvgComponent
