import React from 'react'

interface Props {
   width: number
   height: number
}

function CheckedIcon(props: Props) {
   const { height, width } = props
   return (
      <svg
         xmlns='http://www.w3.org/2000/svg'
         width={height}
         height={width}
         fill='none'
         viewBox='0 0 24 24'
      >
         <path
            fill='#36B37E'
            fillRule='evenodd'
            d='M12 24c6.627 0 12-5.373 12-12S18.627 0 12 0 0 5.373 0 12s5.373 12 12 12z'
            clipRule='evenodd'
            opacity='.15'
         />
         <path
            fill='#36B37E'
            d='M10.398 15.824l-3.261-3.242C7.046 12.491 7 12.374 7 12.23c0-.143.046-.26.137-.351l.722-.703c.092-.104.205-.156.342-.156.137 0 .257.052.361.156l2.188 2.187 4.688-4.687c.104-.104.224-.156.36-.156.137 0 .251.052.343.156l.722.703c.091.091.137.208.137.351 0 .144-.046.26-.137.352l-5.761 5.742c-.092.104-.209.156-.352.156s-.26-.052-.352-.156z'
         />
      </svg>
   )
}

CheckedIcon.defaultProps = {
   width: 24,
   height: 24
}

export default CheckedIcon
