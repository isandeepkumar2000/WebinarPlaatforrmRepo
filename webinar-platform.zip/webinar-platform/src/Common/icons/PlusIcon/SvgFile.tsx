import React from 'react'

export default function SvgComponent(props): JSX.Element {
   return (
      <svg
         xmlns='http://www.w3.org/2000/svg'
         width='16'
         height='17'
         fill='none'
         viewBox='0 0 16 17'
         {...props}
      >
         <path
            fill='#171F46'
            fillRule='evenodd'
            d='M7.25 7.426v-5.25h1.5v5.25H14v1.5H8.75v5.25h-1.5v-5.25H2v-1.5h5.25z'
            clipRule='evenodd'
         ></path>
      </svg>
   )
}
