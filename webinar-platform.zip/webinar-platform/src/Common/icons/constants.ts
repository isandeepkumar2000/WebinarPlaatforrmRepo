import ActivityIcon from './ActivityIcon'
import AddPeopleIcon from './AddPeopleIcon'
import BaseCheckBoxNormalIcon from './BaseCheckBoxNormalIcon'
import BaseCheckBoxSelectedIcon from './BaseCheckBoxSelectedIcon'
import BellIcon from './BellIcon'
import CheckBoxDisabled from './CheckBoxDisabled'
import CheckBoxSelectedDisabledIcon from './CheckBoxSelectedDisabledIcon'
import CloseIcon from './CloseIcon'
import CorrectIcon from './CorrectIcon'
import DeleteIcon from './DeleteIcon'
import EditIcon from './EditIcon'
import HamburgerTwoLineIcon from './HamburgerTwoLineIcon'
import HomeIcon from './HomeIcon'
import LinkIcon from './LinkIcon'
import MobileIcon from './MobileIcon'
import MoreIcon from './MoreIcon'
import NotesIcon from './NotesIcon'
import PlusIcon from './PlusIcon'
import RadioButtonDisabledIcon from './RadioButtonDisabledIcon'
import RadioButtonNormalIcon from './RadioButtonNormalIcon'
import RadioButtonSelectedDisabledIcon from './RadioButtonSelectedDisabledIcon'
import RadioButtonSelectedIcon from './RadioButtonSelectedIcon'
import ReactSelectDropDownArrow from './ReactSelectDropDownArrow'
import SortIcon from './SortIcon'
import ThickWorkBookIcon from './ThickWorkBookIcon'
import TickIcon from './TickIcon'
import WorkBookNormalIcon from './WorkBookNormalIcon'
import WorkBookSlantedIcon from './WorkBookSlantedIcon'

export const iconsList = [
   { label: 'Activity Icon', icon: ActivityIcon },
   { label: 'Add People Icon', icon: AddPeopleIcon },
   { label: 'Base CheckBox Normal Icon', icon: BaseCheckBoxNormalIcon },
   { label: 'Base CheckBox Selected Icon', icon: BaseCheckBoxSelectedIcon },
   { label: 'BellIcon', icon: BellIcon },
   { label: 'CheckBox Disabled', icon: CheckBoxDisabled },
   {
      label: 'CheckBox Selected Disabled Icon',
      icon: CheckBoxSelectedDisabledIcon
   },
   { label: 'CloseIcon', icon: CloseIcon },
   { label: 'CorrectIcon', icon: CorrectIcon },
   { label: 'DeleteIcon', icon: DeleteIcon },
   { label: 'EditIcon', icon: EditIcon },
   { label: 'Hamburger Two Line Icon', icon: HamburgerTwoLineIcon },
   { label: 'HomeIcon', icon: HomeIcon },
   { label: 'LinkIcon', icon: LinkIcon },
   { label: 'MobileIcon', icon: MobileIcon },
   { label: 'MoreIcon', icon: MoreIcon },
   { label: 'NotesIcon', icon: NotesIcon },
   { label: 'PlusIcon', icon: PlusIcon },
   { label: 'Radio Button Disabled Icon', icon: RadioButtonDisabledIcon },
   { label: 'Radio Button Normal Icon', icon: RadioButtonNormalIcon },
   {
      label: 'Radio Button Selected Disabled Icon',
      icon: RadioButtonSelectedDisabledIcon
   },
   {
      label: 'Radio Button Selected  Icon',
      icon: RadioButtonSelectedIcon
   },
   { label: 'React Select DropDown Arrow', icon: ReactSelectDropDownArrow },
   { label: 'SortIcon', icon: SortIcon },
   { label: 'ThickWorkBookIcon', icon: ThickWorkBookIcon },
   { label: 'TickIcon', icon: TickIcon },
   { label: 'WorkBook Normal Icon', icon: WorkBookNormalIcon },
   { label: 'WorkBook Slanted Icon', icon: WorkBookSlantedIcon }
]
