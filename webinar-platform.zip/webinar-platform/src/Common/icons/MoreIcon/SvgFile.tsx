import React from 'react'

export default function SvgComponent(props): JSX.Element {
   return (
      <svg
         xmlns='http://www.w3.org/2000/svg'
         width='16'
         height='17'
         fill='none'
         viewBox='0 0 16 17'
         {...props}
      >
         <path
            fill='#7E858E'
            fillRule='evenodd'
            d='M1 7.676a1.5 1.5 0 103.001-.001A1.5 1.5 0 001 7.676zm5.5 0a1.5 1.5 0 103.001-.001 1.5 1.5 0 00-3.001.001zm7 1.5a1.5 1.5 0 11.001-3.001 1.5 1.5 0 01-.001 3.001z'
            clipRule='evenodd'
         ></path>
      </svg>
   )
}
