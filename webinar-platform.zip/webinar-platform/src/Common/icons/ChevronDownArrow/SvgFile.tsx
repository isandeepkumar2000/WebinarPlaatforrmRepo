import React, { Component } from 'react'

interface Props {
   width?: number
   height?: number
   fill?: string
   className?: string
}

class SvgComponent extends Component<Props> {
   static defaultProps = {
      width: 20,
      height: 20
   }

   render() {
      const { width, height, fill } = this.props

      return (
         <svg
            xmlns='http://www.w3.org/2000/svg'
            width={width}
            height={height}
            fill={fill}
            {...this.props}
            viewBox='0 0 16 16'
         >
            <path
               fill={fill}
               fillRule='evenodd'
               d='M8 10.333c-.17 0-.341-.065-.471-.195L4.862 7.471c-.26-.26-.26-.682 0-.942.26-.261.682-.261.943 0l2.203 2.203 2.195-2.12c.266-.255.687-.248.943.017.256.264.249.687-.016.942l-2.667 2.575c-.13.125-.296.187-.463.187z'
               clipRule='evenodd'
            />
         </svg>
      )
   }
}

export default SvgComponent
