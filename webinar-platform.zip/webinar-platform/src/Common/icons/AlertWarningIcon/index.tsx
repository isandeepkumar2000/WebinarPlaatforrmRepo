import React from 'react'

interface Props {
   width: number
   height: number
}

function AlertWarningIcon(props: Props) {
   const { width, height } = props
   return (
      <svg
         xmlns='http://www.w3.org/2000/svg'
         width={width}
         height={height}
         fill='none'
         viewBox='0 0 85 85'
      >
         <mask
            id='mask0'
            width='69'
            height='61'
            x='8'
            y='12'
            maskUnits='userSpaceOnUse'
         >
            <path
               fill='#F8FAFC'
               fillRule='evenodd'
               d='M15.831 72.618c-5.454 0-8.854-5.915-6.127-10.625l26.669-46.078c2.727-4.71 9.527-4.71 12.254 0l26.669 46.078c2.727 4.71-.673 10.625-6.127 10.625H15.83zm53.338-7.084L42.5 19.457 15.831 65.534H69.17zm-30.21-28.333v7.083a3.552 3.552 0 003.541 3.542 3.552 3.552 0 003.542-3.542v-7.083a3.552 3.552 0 00-3.542-3.542 3.552 3.552 0 00-3.542 3.542zm7.083 24.791V54.91h-7.084v7.084h7.084z'
               clipRule='evenodd'
            ></path>
         </mask>
         <g mask='url(#mask0)'>
            <path fill='#F8FAFC' d='M0 0H85V85H0z'></path>
         </g>
      </svg>
   )
}

AlertWarningIcon.defaultProps = {
   width: 85,
   height: 85
}

export default AlertWarningIcon
