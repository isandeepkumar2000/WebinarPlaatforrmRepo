import React from 'react'
import { withTheme } from 'styled-components'

function RightArrowIcon(props: any) {
   return (
      <svg
         xmlns='http://www.w3.org/2000/svg'
         width='16'
         height='16'
         fill='none'
         viewBox='0 0 16 16'
      >
         <path
            fill={props.color ?? props.theme.secondaryActionColor}
            fillRule='evenodd'
            d='M3.333 8.667h7.91l-2.422 2.906a.666.666 0 101.025.854l3.333-4c.026-.032.039-.068.058-.103.016-.028.036-.052.048-.083a.652.652 0 00.048-.238v-.006a.652.652 0 00-.048-.238c-.012-.031-.032-.055-.048-.083-.019-.035-.032-.071-.058-.103l-3.333-4a.669.669 0 00-.939-.085.666.666 0 00-.086.939l2.422 2.906h-7.91a.667.667 0 000 1.334z'
            clipRule='evenodd'
         ></path>
      </svg>
   )
}

export default withTheme(RightArrowIcon)
