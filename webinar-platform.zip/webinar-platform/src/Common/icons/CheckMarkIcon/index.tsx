import React from 'react'

interface Props {
   width: number
   height: number
}

function CheckMarkIcon(props: Props) {
   const { height, width } = props
   return (
      <svg
         xmlns='http://www.w3.org/2000/svg'
         width={width}
         height={height}
         fill='none'
         viewBox='0 0 64 64'
      >
         <path
            fill='#27AB83'
            fillRule='evenodd'
            d='M43.455 25.615l-12.182 16a2.665 2.665 0 01-2.104 1.053h-.018c-.82 0-1.593-.379-2.1-1.024l-6.484-8.285a2.665 2.665 0 01.456-3.742 2.664 2.664 0 013.744.456l4.354 5.563 10.09-13.25a2.666 2.666 0 114.244 3.229zM32 5.335C17.273 5.335 5.334 17.273 5.334 32c0 14.726 11.94 26.667 26.667 26.667 14.728 0 26.667-11.941 26.667-26.667C58.668 17.273 46.729 5.335 32 5.335z'
            clipRule='evenodd'
         ></path>
      </svg>
   )
}

CheckMarkIcon.defaultProps = {
   width: 64,
   height: 64
}

export default CheckMarkIcon
