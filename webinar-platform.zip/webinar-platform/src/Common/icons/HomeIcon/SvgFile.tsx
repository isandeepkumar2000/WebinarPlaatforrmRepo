import React from 'react'

export default function SvgComponent(props): JSX.Element {
   return (
      <svg
         xmlns='http://www.w3.org/2000/svg'
         width='16'
         height='17'
         fill='none'
         viewBox='0 0 16 17'
         {...props}
      >
         <path
            fill='#171F46'
            d='M6.667 13.51v-4h2.666v4h3.334V8.175h2L8 2.176l-6.667 6h2v5.333h3.334z'
         ></path>
      </svg>
   )
}
