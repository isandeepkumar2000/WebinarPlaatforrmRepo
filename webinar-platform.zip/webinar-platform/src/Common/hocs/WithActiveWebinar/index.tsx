import { withActiveWebinar } from './WithActiveWebinar'
export default withActiveWebinar
