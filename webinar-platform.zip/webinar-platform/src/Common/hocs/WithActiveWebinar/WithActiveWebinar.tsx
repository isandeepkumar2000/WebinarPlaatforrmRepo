import React from 'react'
import { inject, observer } from 'mobx-react'
import { API_SUCCESS } from '@ib/api-constants'

import { ActiveWebinarsStore } from '../../../ContentManagement/stores/ActiveWebinarsStore/ActiveWebinarsStore'
import LoadingWrapperWithFailure from '../../components/LoadingWrapperWithFailure'
import MaintenancePage from '../../components/MaintenancePage'

interface WithActiveWebinarProps {} //eslint-disable-line
interface InjectedProps extends WithActiveWebinarProps {
   activeWebinarsStore: ActiveWebinarsStore
}

export const withActiveWebinar = (WrappedComponent): WithActiveWebinarProps => {
   @inject('activeWebinarsStore')
   @observer
   class EnhancedComponent extends React.Component {
      componentDidMount() {
         if (
            this.getActiveWebinarsStore().activeWebinarsAPIStatus !==
            API_SUCCESS
         ) {
            this.doNetworkCalls()
         }
      }

      getInjectedProps = (): InjectedProps => this.props as InjectedProps

      getActiveWebinarsStore = () => this.getInjectedProps().activeWebinarsStore

      doNetworkCalls = async () => {
         const {
            getActiveWebinarsAPI,
            setActiveWebinarId
         } = this.getActiveWebinarsStore()
         await getActiveWebinarsAPI()
         setActiveWebinarId()
      }

      renderWrappedComponent = () => <WrappedComponent {...this.props} />

      renderSuccessUI = observer(() => {
         const { maintenanceConfig } = this.getActiveWebinarsStore()
         if (maintenanceConfig) {
            return (
               <MaintenancePage
                  renderWrappedComponent={this.renderWrappedComponent}
               />
            )
         }
         return this.renderWrappedComponent()
      })

      render() {
         const {
            activeWebinarsAPIStatus,
            activeWebinarsAPIError
         } = this.getActiveWebinarsStore()

         return (
            <LoadingWrapperWithFailure
               apiStatus={activeWebinarsAPIStatus}
               apiError={activeWebinarsAPIError}
               onRetryClick={this.doNetworkCalls}
               renderSuccessUI={this.renderSuccessUI}
            />
         )
      }
   }
   return EnhancedComponent
}
