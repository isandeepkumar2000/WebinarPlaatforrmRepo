import React from 'react'
import { inject, observer } from 'mobx-react'

import { API_SUCCESS } from '@ib/api-constants'

import UserDetailsStore from '../../../UserProfile/stores/UserDetailsStore'

import LoadingWrapperWithFailure from '../../components/LoadingWrapperWithFailure'

interface Props {} //eslint-disable-line
interface InjectedProps extends Props {
   userDetailsStore: UserDetailsStore
}

export const withProfile = (WrappedComponent): Props => {
   @inject('userDetailsStore')
   @observer
   class EnhancedComponent extends React.Component {
      componentDidMount() {
         this.doNetworkCalls()
      }

      get injectedProps(): InjectedProps {
         return this.props as InjectedProps
      }
      get userDetailStore(): UserDetailsStore {
         return this.injectedProps.userDetailsStore
      }

      doNetworkCalls = (): void => {
         const { getProfileAPIStatus, getUserProfileAPI } = this.userDetailStore
         const doFetchUserProfileDetails = getProfileAPIStatus !== API_SUCCESS

         doFetchUserProfileDetails && getUserProfileAPI()
      }

      renderSuccessUI = observer(() => <WrappedComponent {...this.props} />)

      render() {
         const {
            getProfileAPIStatus,
            getProfileAPIError
         } = this.userDetailStore

         return (
            <LoadingWrapperWithFailure
               apiStatus={getProfileAPIStatus}
               apiError={getProfileAPIError}
               onRetryClick={this.doNetworkCalls}
               renderSuccessUI={this.renderSuccessUI}
            />
         )
      }
   }

   return EnhancedComponent
}
