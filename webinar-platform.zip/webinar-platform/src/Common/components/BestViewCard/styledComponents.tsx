import styled from 'styled-components'

import { Typo16BattleshipGreyHKGroteskSemiBold } from '../../styleGuide/Typos'
import { mobile, minDeviceWidth, desktop } from '../../utils/MixinUtils'

export const CardContainer = styled.div`
   height: fit-content;
   border-radius: 16px;
   background-color: ${props => props.theme.secondaryBackgroundColor};
   display: flex;
   justify-content: center;

   ${desktop} {
      width: 100%;
   }
   ${mobile} {
      justify-content: flex-start;
   }
   align-items: center;
   border: 1px solid ${props => props.theme.primaryBorderColor};
`

export const ViewText = styled(Typo16BattleshipGreyHKGroteskSemiBold)`
   line-height: 1.5;
   color: ${props => props.theme.primaryTextColor};
   ${minDeviceWidth(768)} {
      text-align: center;
   }
   margin: 25px 20px;
   ${mobile} {
      font-size: 14px;
      line-height: 1.71;
      font-weight: 500;
   }
`
