import React from 'react'
import { WithTranslation, withTranslation } from 'react-i18next' //eslint-disable-line

import { CardContainer, ViewText } from './styledComponents'

interface Props extends WithTranslation {} //eslint-disable-line

function BestViewCard(props: Props) {
   return (
      <CardContainer>
         <ViewText>
            For best experience watch the webinar on latest version of Google
            Chrome or Safari
         </ViewText>
      </CardContainer>
   )
}

export default withTranslation()(BestViewCard)
