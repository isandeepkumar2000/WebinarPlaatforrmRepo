export interface ValidationResponseType {
   errorMessage: string
   shouldShowError: boolean
}
