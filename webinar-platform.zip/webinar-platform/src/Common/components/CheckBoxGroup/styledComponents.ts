import styled from 'styled-components'

export const MainContainer = styled.div``

export const CheckBoxContainer = styled.div``
