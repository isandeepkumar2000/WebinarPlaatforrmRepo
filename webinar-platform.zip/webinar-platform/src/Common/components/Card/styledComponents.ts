import styled from 'styled-components'

export const CardContainer = styled('div')`
   border-radius: 0.278em;
   box-shadow: 2px 2px 2px 2px rgba(176, 203, 234, 0.24);
`
