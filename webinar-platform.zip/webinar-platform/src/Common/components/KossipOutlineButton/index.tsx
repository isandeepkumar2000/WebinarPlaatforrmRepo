import React, { Component } from 'react'

import Colors from '../../themes/Colors'

import Loader from '../Loader'
import { ButtonProps } from './types'

import { ButtonTextTypo, OutlineButton } from './styledComponents'
import './styles.scss'

class KossipOutlineButton extends Component<ButtonProps> {
   static defaultProps = OutlineButton.defaultProps

   renderLoader = (): React.ReactNode => (
      <Loader
         color={Colors.azulTwo}
         height={25}
         width={25}
         className='loaderStyles'
      />
   )

   render(): React.ReactNode {
      const { textTypo, ...otherProps } = this.props

      return (
         <OutlineButton
            textTypo={textTypo ? textTypo : ButtonTextTypo}
            renderLoader={this.renderLoader}
            {...otherProps}
         />
      )
   }
}

export default KossipOutlineButton
