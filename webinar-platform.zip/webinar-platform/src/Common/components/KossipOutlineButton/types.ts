import { APIStatus } from '@ib/api-constants'

export interface ButtonProps {
   text: string
   onClick: Function
   apiStatus: APIStatus
   className: string
   textTypo: React.ElementType
   textClassName?: string
   disabled: boolean
   renderLoader: Function
   id?: string
   renderRightIcon?: Function
   renderLeftIcon?: Function
   loaderSize?: number
}
