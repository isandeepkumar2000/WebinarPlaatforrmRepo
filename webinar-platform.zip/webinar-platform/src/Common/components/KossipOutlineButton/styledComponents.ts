import styled from 'styled-components'

import { Typo14WhiteHKGroteskMedium } from '../../styleGuide/Typos'
import Colors from '../../themes/Colors'

import Button from '../Button'

export const OutlineButton = styled(Button)`
   width: 218px;
   height: 34px;
   border-radius: 5.4px;
   border: solid 2px ${Colors.azulTwo};
   background-color: ${Colors.white};
   box-shadow: none !important;
`

export const ButtonTextTypo = styled(Typo14WhiteHKGroteskMedium)`
   color: ${Colors.azulTwo};
   font-weight: 500;
   letter-spacing: 0.5px;
   text-transform: uppercase;
`
