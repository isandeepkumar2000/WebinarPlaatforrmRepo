import React from 'react'
import { storiesOf } from '@storybook/react'

import NoActiveWebinarsView from '.'

storiesOf('NoActiveWebinarsView', module).add('NoActiveWebinarsView', () => (
   <NoActiveWebinarsView />
))
