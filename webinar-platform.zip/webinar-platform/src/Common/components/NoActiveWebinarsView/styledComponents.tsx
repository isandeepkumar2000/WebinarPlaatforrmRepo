import styled from 'styled-components'
import {
   Typo24GunMetalHKGroteskMedium,
   Typo28GunMetalHKGroteskMedium,
   Typo16PaleGreTwoHKGroteskSemiBold,
   Typo14WhiteHKGroteskSemiBold
} from '../../styleGuide/Typos'
import { mobile, minDeviceWidth, customDevice } from '../../utils/MixinUtils'
import Image from '../Image'
import colors from '../../themes/Colors'
import Button from '../Button'

export const Container = styled.div`
   border-radius: 4px;
   background-color: ${props => props.theme.primaryBackgroundColor};
   display: flex;
   flex-direction: column;
   align-items: center;
   width: 100%;
   height: auto;
   transition: all 0.25s linear;

   ${mobile} {
      padding: 32px 0;
   }

   ${minDeviceWidth(768)} {
      padding: 50px 0;
   }

   ${minDeviceWidth(1024)} {
      padding: 20px 0;
   }
   ${minDeviceWidth(1441)} {
      padding: 60px 0;
   }
`

export const SubmittedAnswerText = styled(Typo24GunMetalHKGroteskMedium)`
   line-height: 1.33;
   text-align: center;
   color: ${props => props.theme.primaryItemsSectionColor};
   ${mobile} {
      width: 250px;
      font-size: ${props => (props.isCustomText ? '24px' : '16px')};
      margin-top: 42px;
   }

   ${minDeviceWidth(768)} {
      width: 450px;
      font-weight: 600;
      padding-top: 42px;
      font-size: ${props => (props.isCustomText ? '22px' : '20px')};
      padding-top: 42px;
   }

   ${minDeviceWidth(1024)} {
      width: 614px;
      font-weight: bold;
      font-size: ${props => (props.isCustomText ? '28px' : '24x')};
      line-height: 1.2;
   }
`

export const NextQuestionText = styled(Typo28GunMetalHKGroteskMedium)`
   width: 221px;
   text-align: center;
   color: ${props => props.theme.secondaryItemsSectionColor};

   ${mobile} {
      width: 200px;
      font-size: ${props => (props.isCustomText ? '16px' : '22px')};

      padding-top: 16px;
      padding-bottom: 10px;
      line-height: 1.64;
   }

   ${minDeviceWidth(768)} {
      width: 330px;
      line-height: 1.33;
      padding-top: 24px;
      font-size: ${props => (props.isCustomText ? '16px' : '22px')};

      padding-bottom: 10px;
   }

   ${minDeviceWidth(1024)} {
      width: 560px;
      line-height: 1.33;
      margin-top: 18px;
      font-size: ${props => (props.isCustomText ? '20px' : '28px')};
      padding-top: 24px;
   }
`

export const DisplayText = styled.div`
   display: flex;
   flex-direction: column;
   align-items: center;

   ${mobile} {
      width: 85%;
      margin-top: 39px;
      margin-left: 24px;
      margin-right: 24px;
   }

   ${minDeviceWidth(768)} {
      line-height: 1.33;
      margin-top: 50px;
   }

   ${minDeviceWidth(1024)} {
      margin-top: 30px;
      padding-left: 40px;
      padding-right: 40px;
   }
   ${minDeviceWidth(1441)} {
      margin-top: 80px;
   }
`

export const NoWebinarsImage = styled(Image)`
   ${mobile} {
      height: 156px;
      width: 141px;
   }

   ${minDeviceWidth(768)} {
      height: 196px;
      width: 176px;
   }

   ${minDeviceWidth(1024)} {
      height: 218px;
      width: 196px;
   }
`
export const Header = styled.div`
   height: 72px;
   width: 100%;
   display: none;
   align-items: center;
   background-color: ${props => props.theme.headerBackgroundColor};
   ${mobile} {
      display: flex;
   }
`
export const AnchorElement = styled.a`
   display: flex;
   flex-wrap: wrap;
   color: ${props => props.theme.secondaryItemsSectionColor};
   width: 221px;
   justify-content: center;
   align-items: center;
   font-size: 20px;
   text-decoration: underline;
   ${customDevice(319, 1023)} {
      width: 200px;
      font-size: 16px;
   }
`
export const FreeTrailCard = styled.div`
   display: flex;
   flex-direction: column;
   align-items: center;
   width: 48%;
   ${minDeviceWidth(320)} {
      width: 89%;
   }
   ${minDeviceWidth(769)} {
      width: 362px;
   }
   ${minDeviceWidth(1024)} {
      width: 45%;
   }
   margin-top: 48px;
   border-radius: 12px;
   border: 1px solid ${colors.charcoalGrey};
   padding-bottom: 30px;
`
export const FreeTrailText = styled(Typo16PaleGreTwoHKGroteskSemiBold)`
   color: ${props => props.theme.primarySvgIconColor};
   line-height: 1.5;
   text-align: center;
   margin-top: 32px;
   max-width: 90%;
   font-size: 20px;
`
export const RegisterFullAccessButton = styled(Button)`
   height: 40px;
   margin-top: 24px;
`

export const ButtonText = styled(Typo14WhiteHKGroteskSemiBold)`
   line-height: 1.14;
   margin: 0px;
`
export const AnnouncementAnchorElement = styled.a`
   color: inherit;
`
