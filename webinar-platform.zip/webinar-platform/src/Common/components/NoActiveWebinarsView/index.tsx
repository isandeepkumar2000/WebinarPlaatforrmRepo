import React from 'react'

import { WithTranslation, withTranslation } from 'react-i18next' //eslint-disable-line
import { withTheme } from 'styled-components'

import { isMobile, isTabletOrMobile } from '../../utils/ResponsiveUtils'

import NoWebinarsIcon from '../../icons/NoWebinarsIcon/SvgFile'
import {
   Container,
   SubmittedAnswerText,
   NextQuestionText,
   DisplayText,
   AnchorElement,
   FreeTrailCard,
   FreeTrailText
} from './styledComponents'

interface NoActiveWebinarsViewProps extends WithTranslation {
   sessionText?: string
   keepWaitingText?: string
   url?: string
   showSpecialAnnouncement?: boolean
   handleRegisterButton?: Function
}

function NoActiveWebinarsView(props: NoActiveWebinarsViewProps) {
   const {
      t,
      sessionText,
      keepWaitingText,
      url,
      showSpecialAnnouncement
   } = props

   const getNoWebinarIconDimensions = () => {
      if (isMobile()) {
         return { width: '159', height: '162' }
      }
      if (isTabletOrMobile()) {
         return { width: '180', height: '200' }
      }
      return { width: '200', height: '250' }
   }
   return (
      <>
         <Container>
            <NoWebinarsIcon
               height={getNoWebinarIconDimensions()?.height}
               width={getNoWebinarIconDimensions()?.width}
            />
            {!showSpecialAnnouncement ? (
               <DisplayText>
                  <SubmittedAnswerText
                     isCustomText={sessionText ? true : false}
                  >
                     {sessionText ?? t('No active webinars at the moment!')}
                  </SubmittedAnswerText>
                  <NextQuestionText
                     isCustomText={keepWaitingText ? true : false}
                  >
                     {keepWaitingText ??
                        t('Keep checking this space for upcoming webinars')}
                  </NextQuestionText>
                  {url ? <AnchorElement href={url}>{url}</AnchorElement> : null}
               </DisplayText>
            ) : (
               <FreeTrailCard>
                  <FreeTrailText>
                     The webinar ‘Day of Win-Win-Win’ will be available here at
                     10:30 AM tomorrow (4th October)
                  </FreeTrailText>
               </FreeTrailCard>
            )}
         </Container>
      </>
   )
}

export default withTheme(withTranslation()(NoActiveWebinarsView))
