import React, { Component } from 'react'

import { PriorityContainer, StyledPriorityText } from './styledComponents'

interface PriorityTextProps {
   priorityContent
}

class PriorityText extends Component<PriorityTextProps> {
   render(): React.ReactNode {
      const { priorityContent } = this.props
      return (
         <PriorityContainer>
            <StyledPriorityText>{priorityContent}</StyledPriorityText>
         </PriorityContainer>
      )
   }
}

export default PriorityText
