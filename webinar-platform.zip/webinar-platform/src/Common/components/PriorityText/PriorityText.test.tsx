import React from 'react'
import { render } from '@testing-library/react'

import PriorityText from '.'

describe('PriorityText tests', () => {
   it('should test the content being displayed', () => {
      const { getByText } = render(<PriorityText priorityContent={1} />)
      expect(getByText('1')).toBeDefined()
   })
})
