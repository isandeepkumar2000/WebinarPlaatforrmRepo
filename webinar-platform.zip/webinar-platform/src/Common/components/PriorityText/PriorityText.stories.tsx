import React from 'react'
import { storiesOf } from '@storybook/react'
import { withKnobs, number } from '@storybook/addon-knobs'

import PriorityText from '.'

storiesOf('Labels and Badges/PriorityText', module)
   .addDecorator(withKnobs)
   .add('with priority content 1', () => (
      <PriorityText priorityContent={number('priorityNumber', 1)} />
   ))
