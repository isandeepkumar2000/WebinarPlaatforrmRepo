import styled from 'styled-components'

import { Typo12WhiteHKGroteskMedium } from '../../styleGuide/Typos'
import Colors from '../../themes/Colors'

export const PriorityContainer = styled.div`
   width: 16px;
   height: 16px;
   border-radius: 50%;
   background-color: ${Colors.darkBlueGrey};
   display: flex;
   justify-content: center;
   align-items: center;
`

export const StyledPriorityText = styled(Typo12WhiteHKGroteskMedium)``
