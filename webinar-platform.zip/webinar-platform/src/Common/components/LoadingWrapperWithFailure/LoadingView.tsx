import React from 'react'

import Loader from 'react-loader-spinner'

import { LoadingViewContainer } from './styledComponents'

interface LoadingViewProps {
   backgroundColor?: string
   width?: string
   height?: string
}
class LoadingView extends React.Component<LoadingViewProps> {
   render() {
      const { backgroundColor, width, height } = this.props
      return (
         <LoadingViewContainer
            height={height}
            backgroundColor={backgroundColor}
            width={width}
         >
            <Loader type='TailSpin' color='#0b69ff' height={100} width={100} />
         </LoadingViewContainer>
      )
   }
}

export default LoadingView
