import React from 'react'
import { observer } from 'mobx-react'
import { WithTranslation, withTranslation } from 'react-i18next' //eslint-disable-line
import 'styled-components/macro'

import Image from '../Image'
import RetryButton from '../Button'

import { FailureViewContainer, FailureViewMessage } from './styledComponents'
interface FailureViewPropType extends WithTranslation {
   onRetryClick: Function
   errorMessage: string
   height?: string | number
   backgroundColor?: string
   width?: string
   failureViewMessageCss?: React.CSSProperties
}
@observer
class FailureView extends React.Component<FailureViewPropType> {
   render() {
      const {
         onRetryClick,
         errorMessage,
         backgroundColor,
         width,
         height,
         failureViewMessageCss,
         t
      } = this.props

      return (
         <FailureViewContainer
            backgroundColor={backgroundColor}
            width={width}
            height={height}
         >
            <Image
               alt={`${t('Failure-image')}`}
               src={'/images/failureViewImage.png'}
            />
            <FailureViewMessage css={failureViewMessageCss}>
               {errorMessage}
            </FailureViewMessage>
            <RetryButton
               onClick={onRetryClick}
               variant={RetryButton.variants.primary}
            >
               {t('Retry')}
            </RetryButton>
         </FailureViewContainer>
      )
   }
}

export default withTranslation()(FailureView)
