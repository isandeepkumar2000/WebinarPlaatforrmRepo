import React from 'react'
import { observer } from 'mobx-react'

import {
   API_FETCHING,
   API_SUCCESS,
   API_FAILED,
   API_INITIAL
} from '@ib/api-constants'

import { getAPIErrorMessage } from '../../utils/APIUtils'

import LoadingView from './LoadingView'
import FailureView from './FailureView'

interface LoadingWrapperWithFailureProps {
   apiStatus: number
   renderSuccessUI: any
   onRetryClick: () => any
   apiError: any
   height?: string
   backgroundColor?: string
   width?: string
   renderFailureUI?: any
   failureViewMessageCss?: React.CSSProperties
}
@observer
class LoadingWrapperWithFailure extends React.Component<
   LoadingWrapperWithFailureProps
> {
   render() {
      const {
         apiStatus,
         renderSuccessUI: RenderSuccessUI,
         renderFailureUI: RenderFailureUI,
         onRetryClick,
         apiError,
         height,
         backgroundColor,
         width,
         failureViewMessageCss
      } = this.props
      const errorMessage = getAPIErrorMessage(apiError)

      switch (apiStatus) {
         case API_INITIAL:
         case API_FETCHING:
            return (
               <LoadingView
                  height={height}
                  backgroundColor={backgroundColor}
                  width={width}
               />
            )
         case API_SUCCESS:
            return <RenderSuccessUI />
         case API_FAILED:
            return RenderFailureUI ? (
               <RenderFailureUI />
            ) : (
               <FailureView
                  onRetryClick={onRetryClick}
                  errorMessage={errorMessage}
                  height={height}
                  backgroundColor={backgroundColor}
                  width={width}
                  failureViewMessageCss={failureViewMessageCss}
               />
            )
         default:
            return null
      }
   }
}

export default LoadingWrapperWithFailure
