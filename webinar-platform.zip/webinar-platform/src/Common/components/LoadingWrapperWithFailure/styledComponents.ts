import styled from 'styled-components'

import Colors from '../../themes/Colors'
import { Typo14BlackHKGroteskSemiBold } from '../../styleGuide/Typos'
type WrapperPropTypes = {
   height: string
}

interface ViewProps {
   backgroundColor: string
   width: string
}

export const LoadingViewContainer = styled.div`
   width: ${(props: ViewProps) => (props.width ? props.width : '100%')};
   height: 100%;
   display: flex;
   flex-direction: column;
   justify-content: center;
   align-items: center;
   height: ${props => (props.height ? props.height : '100vh')};
   background-color: ${props =>
      props.backgroundColor ? props.backgroundColor : 'inherit'};
`

export const FailureViewContainer = styled.div<WrapperPropTypes>`
   display: flex;
   flex-direction: column;
   justify-content: center;
   width: ${(props: ViewProps) => (props.width ? props.width : '100%')};
   align-items: center;
   height: ${props => (props.height ? props.height : '100vh')};
   background-color: ${(props: ViewProps) =>
      props.backgroundColor ? props.backgroundColor : Colors.white};
`

export const FailureViewMessage = styled(Typo14BlackHKGroteskSemiBold)`
   margin: 30px;
   text-align: center;
`

export const RetryButton = styled(Typo14BlackHKGroteskSemiBold)`
   margin: 0;
   padding: 5px;
   color: ${Colors.white};
`
