import styled, { css } from 'styled-components'

import {
   Typo32DodgerBlueThreeRobotoBold,
   Typo24SlateBlueRobotoMedium
} from '../../styleGuide/Typos'
import Colors from '../../themes/Colors'
import { mobile } from '../../utils/MixinUtils'

export const Container = styled.div`
   display: flex;
   align-items: center;
   justify-content: center;
   flex-direction: column;
   height: 100vh;
   background-color: ${Colors.veryLightBlue};
   ${mobile} {
      height: 100vh;
   }
`

export const GetBackTimerText = styled(Typo24SlateBlueRobotoMedium)`
   display: flex;
   margin-bottom: 21px;
   ${mobile} {
      font-size: 16px;
      flex-direction: column;
      align-items: center;
      margin-bottom: 4px;
   }
`

export const GetBackText = styled(Typo24SlateBlueRobotoMedium)`
   ${mobile} {
      font-size: 16px;
      margin-bottom: 12px;
   }
`

export const UnderMaintenanceText = styled(Typo32DodgerBlueThreeRobotoBold)`
   text-transform: uppercase;
   margin-bottom: 36px;
   margin-top: 48px;
   ${mobile} {
      font-size: 20px;
      margin-top: 36px;
   }
`

export const timerCSS = css`
   font-size: 48px;
   color: ${Colors.fadedBlueTwo};
   font-weight: bold;
   ${mobile} {
      font-size: 36px;
   }
`
