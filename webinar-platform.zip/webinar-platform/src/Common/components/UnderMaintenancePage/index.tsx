import React, { useState } from 'react'
import { observer } from 'mobx-react'
import { useTranslation } from 'react-i18next'

import { isMobile } from '../../utils/ResponsiveUtils'
import UnderMaintenanceIcon from '../../icons/UnderMaintenanceIcon'
import UnderMaintenanceIconMobile from '../../icons/UnderMaintenanceIconMobile'

import DecrementTimer from '../DecrementTimer'

import {
   Container,
   UnderMaintenanceText,
   GetBackTimerText,
   timerCSS,
   GetBackText
} from './styledComponents'

interface Props {
   timeForMaintenance: number
}

const UnderMaintenancePage = observer((props: Props) => {
   const { t } = useTranslation()
   const [timeLeft, setTimeLeft] = useState(props.timeForMaintenance)

   const onTimeUpdate = (time: number): void => {
      setTimeLeft(time)

      if (time === 0) {
         window.location.reload()
      }
   }

   const { timeForMaintenance } = props

   return (
      <Container>
         {!isMobile() ? (
            <UnderMaintenanceIcon />
         ) : (
            <UnderMaintenanceIconMobile />
         )}
         <UnderMaintenanceText>
            {t('common:underMaintenance.underMaintenance')}
         </UnderMaintenanceText>
         <GetBackTimerText>
            <GetBackText>
               {t('common:underMaintenance.underMaintenanceText')}
               {isMobile() ? '' : ','}
            </GetBackText>
            <GetBackText>
               {t('common:underMaintenance.getBackText')}
            </GetBackText>
         </GetBackTimerText>
         <DecrementTimer
            timeInSeconds={timeForMaintenance}
            onTimeUpdate={onTimeUpdate}
            containerCss={timerCSS}
            onComplete={() => {}}
            className=''
         />
      </Container>
   )
})

export default UnderMaintenancePage
