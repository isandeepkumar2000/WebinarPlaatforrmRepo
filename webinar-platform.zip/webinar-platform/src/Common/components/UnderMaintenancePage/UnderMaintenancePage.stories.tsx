import React from 'react'
import { storiesOf } from '@storybook/react'

import UnderMaintenancePage from '.'

storiesOf(
   'Under Maintenance Page',
   module
).add('UnderMaintenancePage with timer', () => (
   <UnderMaintenancePage timeForMaintenance={20} />
))
