import React, { Component } from 'react'
import { observer } from 'mobx-react'

import CloseIcon from '../../icons/CloseIcon'
import Colors from '../../themes/Colors'

import BaseModalContainer from '../BaseModalContainer'

import { CloseButton, FormWrapper, IframeForm } from './styledComponents'
import './styles.scss'

interface Props {
   url: string
   closeForm: () => void
   showCloseButton?: boolean
}

@observer
class OTGFormModal extends Component<Props> {
   static defaultProps = {
      showCloseButton: true
   }

   closeModal = (): void => {
      const { closeForm } = this.props

      closeForm()
   }

   isValidUrl(url: string): boolean {
      return url && url !== '' ? true : false
   }

   render() {
      const { url, showCloseButton } = this.props
      if (this.isValidUrl(url)) {
         return (
            <BaseModalContainer
               data-testid='otg-form'
               isOpen={true}
               className={'modalStyles'}
               overlayClassName={'overlayStyles'}
               ariaHideApp={false}
               hideCloseIcon
            >
               {showCloseButton ? (
                  <CloseButton
                     onClick={this.closeModal}
                     data-testid='otg-form-close'
                  >
                     <CloseIcon fill={Colors.blueGreyTwo} />
                  </CloseButton>
               ) : null}
               <FormWrapper>
                  <IframeForm src={url} />
               </FormWrapper>
            </BaseModalContainer>
         )
      }
      return null
   }
}

export default OTGFormModal
