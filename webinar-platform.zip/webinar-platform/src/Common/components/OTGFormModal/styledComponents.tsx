import styled from 'styled-components'

import { TYPE_FORM_MODAL_CLOSE_BUTTON_Z_INDEX } from '../../constants/ZIndexConstants'
import Colors from '../../themes/Colors'
import { mobile, tablet, customDevice } from '../../utils/MixinUtils'

export const CloseButton = styled.div`
   position: absolute;
   z-index: ${TYPE_FORM_MODAL_CLOSE_BUTTON_Z_INDEX};
   width: 25px;
   height: 25px;
   right: 20px;
   top: 20px;
   background-color: ${Colors.white};
   display: flex;
   align-items: center;
   justify-content: center;
   border-radius: 5px;
   cursor: pointer;
   :hover {
      background-color: ${Colors.orangeRed};
   }
`

export const FormWrapper = styled.div`
   width: 900px;
   height: 85vh;
   display: flex;
   flex-direction: column;
   justify-content: center;
   align-items: center;
   border-radius: 8px;
   ${mobile} {
      width: 320px;
   }
   ${tablet} {
      width: 700px;
   }
   ${customDevice(550, 767)} {
      width: 500px;
   }
   -webkit-overflow-scrolling: touch !important;
   overflow-y: auto !important;
`

export const IframeForm = styled.iframe`
   width: 100%;
   height: 100%;
   border: 0;
`

export const IframeWrapper = styled.div`
   width: 100%;
   height: 100%;
   border-radius: 8px;
`
