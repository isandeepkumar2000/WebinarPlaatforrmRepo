import { observer } from 'mobx-react'
import React, { useEffect } from 'react'

import { useStores } from '../../hooks/useStores'
import LoadingWrapperWithFailure from '../LoadingWrapperWithFailure'
import UnderMaintenancePage from '../UnderMaintenancePage'
import { getSecondsDiffBtwDateTimes } from '../../../ContentManagement/utils/DateUtils'

export interface MaintenancePageTypes {
   renderWrappedComponent: () => JSX.Element
}

export const MaintenancePage = observer((props: MaintenancePageTypes) => {
   const { renderWrappedComponent } = props
   const { networkTimerStore, activeWebinarsStore } = useStores()

   const isUnderMaintenance = (): boolean =>
      Boolean(
         activeWebinarsStore.maintenanceConfig?.isCurrentDateTimeIsInBtwMaintenanceTime(
            new Date(networkTimerStore.currentNetworkDateTime)
         )
      )

   const renderSuccessUI = () =>
      isUnderMaintenance() ? (
         <UnderMaintenancePage
            timeForMaintenance={getSecondsDiffBtwDateTimes(
               new Date(networkTimerStore.currentNetworkDateTime),
               activeWebinarsStore.maintenanceConfig?.endDateTime as Date
            )}
         />
      ) : (
         <>{renderWrappedComponent()}</>
      )

   return renderSuccessUI()
})
