import { MaintenancePage } from './MaintenancePage'
export default MaintenancePage
