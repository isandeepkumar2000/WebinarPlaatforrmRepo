import i18n from '../../i18n'

export const attendeesOptionsValue = {
   father: 'FATHER',
   mother: 'MOTHER',
   child: 'CHILD',
   guardianOrMentor: 'GUARDIAN_OR_MENTOR',
   others: 'OTHERS'
}

export function getAttendeesOptions() {
   return [
      {
         label: i18n.t('mother'),
         value: attendeesOptionsValue.mother
      },
      {
         label: i18n.t('father'),
         value: attendeesOptionsValue.father
      },
      {
         label: i18n.t('child'),
         value: attendeesOptionsValue.child
      },
      {
         label: i18n.t('guardianOrMentor'),
         value: attendeesOptionsValue.guardianOrMentor
      },
      {
         label: i18n.t('others'),
         value: attendeesOptionsValue.others
      }
   ]
}

export const others = 'OTHERS'
