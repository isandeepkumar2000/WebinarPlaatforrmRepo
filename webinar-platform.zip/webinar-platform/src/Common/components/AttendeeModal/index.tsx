import React, { Component } from 'react'
import { WithTranslation, withTranslation } from 'react-i18next' //eslint-disable-line
import { observable } from 'mobx'
import { withRouter } from 'react-router-dom'
import { observer, inject } from 'mobx-react'
import { withTheme } from 'styled-components'

import Webinar from '../../../ContentManagement/stores/models/Webinar'
import PreWebinarFormConfigModel from '../../../ContentManagement/stores/models/PreWebinarFormConfigModel'

import { WHO_IS_WATCHING_WEBINAR_EVENT } from '../../constants/SegmentConstants'
import { DARK_THEME } from '../../constants/ThemeConstants'
import ThemeStore from '../../stores/ThemeStore'
import { trackEvent } from '../../utils/SegmentUtils/SegmentUtils'
import { capitalizeFirstLetter } from '../../utils/OptionsUtils'
import { getNormalSpacedString } from '../../utils/StringUtils'
import { ErrorObject, validateEmpty } from '../../utils/ValidationUtils'
import { getIconDimensions } from '../../utils/LogoUtils'

import CheckboxGroup from '../CheckBoxGroup'
import DesktopLayout from '../DesktopLayout'

import { getAttendeesOptions, others, attendeesOptionsValue } from './constants'
import {
   AttendeeModalWrapper,
   AttendeeModel,
   UserTextInput,
   UserTextInputWrapper,
   AttendeeForm,
   AttendeeFormWrapper,
   ButtonWrapper,
   SubmitButton,
   CheckboxGroupWrapper,
   checkBoxTextCss,
   AttendeeText,
   FromHelpDescription
} from './styledComponents'
import './styles.scss'

interface AttendeeModalPropTypes extends WithTranslation {
   // TODO: define type for requestObject in services & also here
   onSubmitAttendeeForm: (requestObject: any) => Promise<void>
   webinarAttendeeFormId: string
   webinar?: Webinar
   preWebinarFormConfig: PreWebinarFormConfigModel
}

interface InjectedProps extends AttendeeModalPropTypes {
   themeStore: ThemeStore
}
@inject('themeStore')
@observer
class AttendeeModal extends Component<AttendeeModalPropTypes> {
   @observable attendeeCheckboxRef
   @observable selectedAttendees: Array<string>
   @observable shouldShowModal: boolean
   @observable shouldShowInputField: boolean
   @observable attendeeNameRef
   @observable attendeeName: string
   constructor(props) {
      super(props)
      this.attendeeCheckboxRef = React.createRef()
      this.selectedAttendees = []
      this.shouldShowModal = true
      this.shouldShowInputField = false
      this.attendeeNameRef = React.createRef()
      this.attendeeName = ''
   }

   getInjectedProps = (): InjectedProps => this.props as InjectedProps
   getThemeStore = () => this.getInjectedProps().themeStore

   getIndexOfCheckedValue = (value: string) =>
      this.selectedAttendees.indexOf(value)

   onChangeAttendees = (value: string) => {
      const index = this.getIndexOfCheckedValue(value)
      if (index === -1) {
         this.selectedAttendees.push(value)
      } else {
         this.selectedAttendees.splice(index, 1)
      }

      if (this.selectedAttendees.includes(others)) {
         this.shouldShowInputField = true
      } else {
         this.shouldShowInputField = false
      }
   }

   getWebinarAttendees = () => {
      const attendees = this.getCheckboxOptions()
      const webinarAttendees: any = []
      this.selectedAttendees.forEach(attendee => {
         attendees.forEach(eachAttendee => {
            if (eachAttendee.value === attendee) {
               webinarAttendees.push(eachAttendee)
            }
         })
      })

      return webinarAttendees
   }

   getFormattedWebinarAttendeesBasedOnConfig = () => {
      const options = this.getOptionsWithLabelsBasedOnConfig()

      let attendeesObject = {}
      let attendeesObjectKeys: Array<any> = []

      options.forEach(eachOption => {
         attendeesObject[eachOption.value.toLowerCase()] = false
         attendeesObjectKeys.push(eachOption.value.toLowerCase())
      })

      this.getWebinarAttendees().forEach(eachAttendee => {
         if (attendeesObjectKeys.includes(eachAttendee.value.toLowerCase())) {
            attendeesObject[eachAttendee.value.toLowerCase()] = true
         }
      })

      return attendeesObject
   }

   getFormattedWebinarAttendeesObject = () => {
      const { preWebinarFormConfig } = this.props

      if (preWebinarFormConfig) {
         return this.getFormattedWebinarAttendeesBasedOnConfig()
      }

      const attendeesObject = {
         mother: false,
         father: false,
         child: false,
         guardian_or_mentor: false
      }
      this.getWebinarAttendees().forEach(eachAttendee => {
         switch (eachAttendee.value) {
            case attendeesOptionsValue.mother: {
               attendeesObject.mother = true
               break
            }
            case attendeesOptionsValue.father: {
               attendeesObject.father = true
               break
            }
            case attendeesOptionsValue.child: {
               attendeesObject.child = true
               break
            }
            case attendeesOptionsValue.guardianOrMentor: {
               attendeesObject.guardian_or_mentor = true
               break
            }
         }
      })
      return attendeesObject
   }

   trackWhoIsWatchingWebinar = () => {
      const { webinar } = this.props
      if (webinar) {
         const { analyticsConfiguration } = webinar

         if (analyticsConfiguration.shouldTrackEvents)
            trackEvent(WHO_IS_WATCHING_WEBINAR_EVENT, {
               language: webinar.language,
               other: getNormalSpacedString(this.attendeeName),
               serial_number: analyticsConfiguration.serialNumber,
               webinar_category: analyticsConfiguration.webinarCategory,
               webinar_slug: webinar.webinarSlug,
               ...this.getFormattedWebinarAttendeesObject()
            })
      }
   }

   validate = () => {
      const {
         onSubmitAttendeeForm,
         webinar,
         webinarAttendeeFormId
      } = this.props
      this.onBlurAttendeeName()
      this.attendeeCheckboxRef?.current.onValidate()
      if (
         !this.attendeeCheckboxRef?.current.isError &&
         !this.attendeeNameRef?.current?.inputRef.current.isError()
      ) {
         const requestObject = {
            form_id: webinarAttendeeFormId,
            form_submission_data: JSON.stringify({
               whoWillAttendThisWebinar: this.getWebinarAttendees(),
               otherPersonWhoWillAttendThisWebinar: this.attendeeName,
               webinarId: webinar?.webinarId
            })
         }
         this.trackWhoIsWatchingWebinar()
         onSubmitAttendeeForm(requestObject)
         this.shouldShowModal = false
      }
   }

   validateCheckBox = () => {
      const { t } = this.props
      if (this.selectedAttendees.length === 0) {
         return {
            errorMessage: t('selectAtLeastOneErrorMessage'),
            shouldShowError: true
         }
      }
      return {
         errorMessage: '',
         shouldShowError: false
      }
   }

   validateAttendNameField = (): ErrorObject => validateEmpty(this.attendeeName)

   onChangeAttendeeName = event => {
      this.attendeeName = event.target.value
   }

   onBlurAttendeeName = (): void => {
      this.attendeeNameRef?.current?.onBlur()
   }

   getModalOverlayClassName = (): string => {
      const { selectedTheme } = this.getThemeStore()
      if (selectedTheme === DARK_THEME) {
         return 'attendeeDarkModalOverlayStyles'
      }
      return 'attendeeLightModalOverlayStyles'
   }
   getModalClassName = (): string => {
      const { selectedTheme } = this.getThemeStore()
      if (selectedTheme === DARK_THEME) {
         return 'attendeeDarkModalStyles'
      }

      return 'attendeesLightModalStyles'
   }

   getHeading = (): string => {
      const { preWebinarFormConfig, t } = this.props

      if (preWebinarFormConfig) {
         return preWebinarFormConfig.question
      } else {
         return t('attendees')
      }
   }

   getOptionsWithLabelsBasedOnConfig = () => {
      const { preWebinarFormConfig } = this.props
      const { options } = preWebinarFormConfig

      return options.map(eachOption => {
         return {
            label: capitalizeFirstLetter(eachOption),
            value: eachOption.toUpperCase()
         }
      })
   }

   getCheckboxOptions = () => {
      const { preWebinarFormConfig } = this.props

      if (preWebinarFormConfig) {
         return this.getOptionsWithLabelsBasedOnConfig()
      }
      return getAttendeesOptions()
   }

   render() {
      const { t } = this.props
      return this.shouldShowModal ? (
         <AttendeeModalWrapper>
            <AttendeeModel
               isOpen={true}
               hideCloseIcon
               theme={this.getThemeStore().selectedTheme}
               className={this.getModalClassName()}
               overlayClassName={this.getModalOverlayClassName()}
               ariaHideApp={false}
            >
               <DesktopLayout
                  {...getIconDimensions()}
                  hideBackButton={true}
                  changeTheme={this.getThemeStore().setTheme}
                  theme={this.getThemeStore().selectedTheme}
               ></DesktopLayout>
               <AttendeeFormWrapper>
                  <AttendeeForm>
                     <>
                        <AttendeeText>{this.getHeading()}</AttendeeText>
                        <FromHelpDescription>
                           ({t('selectMultipleOptions')})
                        </FromHelpDescription>
                        <CheckboxGroupWrapper>
                           <CheckboxGroup
                              ref={this.attendeeCheckboxRef}
                              options={this.getCheckboxOptions()}
                              onChange={this.onChangeAttendees}
                              selectedValues={this.selectedAttendees}
                              validate={this.validateCheckBox}
                              checkBoxTextCss={checkBoxTextCss}
                           />
                        </CheckboxGroupWrapper>
                     </>
                  </AttendeeForm>
                  {this.shouldShowInputField ? (
                     <UserTextInputWrapper>
                        <UserTextInput
                           data-testid={`attendeeName`}
                           ref={this.attendeeNameRef}
                           value={this.attendeeName}
                           onChange={this.onChangeAttendeeName}
                           onBlur={this.onBlurAttendeeName}
                           validate={this.validateAttendNameField}
                           placeholder={`${t('others')}`}
                        />
                     </UserTextInputWrapper>
                  ) : null}
                  <ButtonWrapper>
                     <SubmitButton id='submitButton' onClick={this.validate}>
                        {'Submit'}
                     </SubmitButton>
                  </ButtonWrapper>
               </AttendeeFormWrapper>
            </AttendeeModel>
         </AttendeeModalWrapper>
      ) : null
   }
}

export default withRouter(withTheme(withTranslation()(AttendeeModal)))
