import styled, { css } from 'styled-components'
import BaseModalContainer from '../BaseModalContainer'

import { Typo18CharcoalGreyHKGroteskMedium } from '../../styleGuide/Typos'
import Colors from '../../themes/Colors'
import { minDeviceWidth, mobile } from '../../utils/MixinUtils'
import TextInput from '../TextInput'
import Button from '../Button'

export const AttendeeModalWrapper = styled.div`
   height: ${window.innerHeight}px;
`

export const AttendeeModel = styled(BaseModalContainer)`
   width: 100%;
   display: flex;
   flex-direction: column;
   align-items: center;
   -webkit-backdrop-filter: blur(10px);
   backdrop-filter: blur(10px);
   transition: all 0.25s linear;
   outline: none;
   user-select: none;
   overflow: hidden;
`
export const UserTextInput = styled(TextInput)`
   -webkit-appearance: none;
   height: 40px;
   margin-top: 8px;
   background-color: transparent;
   color: ${props => props.theme.secondaryTextColor};
   border: 1px solid ${Colors.coolGrey};
   &:focus {
      border: solid 2px ${Colors.cerulean};
      outline: none;
      font-weight: bold;
   }
   width: 296px;
   ${minDeviceWidth(768)} {
      width: 356px;
   }
`
export const UserTextInputWrapper = styled.div`
   margin-bottom: 24px;
`

export const AttendeeForm = styled.div`
   display: flex;
   width: auto;
   height: auto;
   flex-direction: column;
   justify-content: center;
   align-items: center;
`

export const AttendeeFormWrapper = styled.div`
   display: flex;
   flex-direction: column;
   align-items: center;
   min-height: 392px;
   width: 100%;
   height: calc(100% - 76px);
   justify-content: center;
`
export const ButtonWrapper = styled.div`
   display: flex;
   justify-content: center;
   align-items: center;
   width: 100%;
`

export const SubmitButton = styled(Button)`
   height: 40px;
   width: 140px;
   background-color: ${Colors.cerulean};
`
export const CheckboxGroupWrapper = styled.div`
   display: flex;
   flex-direction: column;
   width: 100%;
   height: auto;
   margin-bottom: 20px;
   flex-wrap: wrap;
   min-width: 296px;
   ${minDeviceWidth(768)} {
      min-width: 356px;
   }
`
export const checkBoxTextCss = css`
   display: flex;
   flex-wrap: wrap;
   width: 100%;
   font-size: 18px;
   width: 260px;
   color: ${props => props.theme.primaryTextColor};
   ${mobile} {
      font-size: 16px;
   }
`
export const AttendeeText = styled(Typo18CharcoalGreyHKGroteskMedium)`
   display: flex;
   color: ${props => props.theme.tertiaryTextColorTwo};
   user-select: none;
   flex-wrap: wrap;
   word-break: break-word;
   width: 100%;
   font-size: 18px;
   ${mobile} {
      font-size: 16px;
   }
`
export const FromHelpDescription = styled(AttendeeText)`
   font-size: 14px;
   padding-top: 5px;
   ${mobile} {
      font-size: 12px;
   }
`
