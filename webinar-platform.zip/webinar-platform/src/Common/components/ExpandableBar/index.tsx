import { observable } from 'mobx'
import { observer } from 'mobx-react'
import React, { Component } from 'react'
import { withRouter } from 'react-router-dom'
import { WithTranslation, withTranslation } from 'react-i18next' //eslint-disable-line
import { withTheme } from 'styled-components'
import { Collapse } from 'react-collapse'

import './styles.css'

import ChevronDownArrow from '../../../Common/icons/ChevronDownArrow'

import {
   SectionTitle,
   CollapseHeadingContainer,
   CollapseMainContainer,
   WebinarsContainer,
   CollapsibleArrowIcon
} from './styledComponents'

interface ExpandableBarProps extends WithTranslation {
   sectionText: string
   renderWebinars: Function
   expandableArrowColor: string
   isSectionExpandedByDefault?: boolean
}

@observer
class ExpandableBar extends Component<ExpandableBarProps> {
   @observable isExpanded!: boolean

   constructor(props) {
      super(props)
      this.init()
   }

   init = () => {
      const { isSectionExpandedByDefault } = this.props
      this.isExpanded = isSectionExpandedByDefault
         ? isSectionExpandedByDefault
         : false
   }

   onClickExpandable = (): void => {
      this.isExpanded = !this.isExpanded
   }

   render() {
      const { sectionText, renderWebinars, expandableArrowColor } = this.props
      return (
         <CollapseMainContainer>
            <CollapseHeadingContainer onClick={this.onClickExpandable}>
               <SectionTitle>{sectionText}</SectionTitle>
               <CollapsibleArrowIcon isSectionSelected={this.isExpanded}>
                  <ChevronDownArrow fill={expandableArrowColor} />
               </CollapsibleArrowIcon>
            </CollapseHeadingContainer>
            <Collapse
               onClick={this.onClickExpandable}
               isOpened={this.isExpanded}
            >
               <WebinarsContainer>{renderWebinars()}</WebinarsContainer>
            </Collapse>
         </CollapseMainContainer>
      )
   }
}

export default withTheme(withRouter(withTranslation()(ExpandableBar)))
