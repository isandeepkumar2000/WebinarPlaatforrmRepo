import styled from 'styled-components'

import {
   minDeviceWidth,
   mobileOrTablet
} from '../../../Common/utils/MixinUtils'
import { Typo16SlateHKGroteskSemiBold } from '../../../Common/styleGuide/Typos'

export const CollapsibleArrowIcon = styled.div`
   transform: ${props =>
      props.isSectionSelected ? 'rotate(180deg)' : 'rotate(0deg)'};
   cursor: ${props => (!props.isSectionSelected ? 'pointer' : 'normal')};
   align-self: ${props => (!props.isSectionSelected ? 'none' : 'flex-start')};
   margin-left: 11px;
   fill: ${props => props.theme.secondaryTextColor};
   ${mobileOrTablet} {
      margin-right: 8px;
   }
`
export const SectionTitle = styled(Typo16SlateHKGroteskSemiBold)`
   height: 26px;
   display: flex;
   align-items: center;
   text-transform: uppercase;
   color: ${props => props.theme.secondaryTextColor};
   transition: all 0.25s linear;
`

export const CollapseHeadingContainer = styled.div`
   padding-left: 8px;
   margin: 0px 8px;
   display: flex;
   align-items: center;
   margin: 0px !important;
   cursor: pointer;
`
export const CollapseMainContainer = styled.div`
   display: flex;
   flex-direction: column;
   align-items: flex-start;
   width: 100%;
   margin-left: 16px;

   ${mobileOrTablet} {
      margin-top: 24px;
   }
`
export const WebinarsContainer = styled.div`
   display: flex;
   flex-direction: column;
   padding-left: 8px;

   ${minDeviceWidth(834)} {
      flex-direction: row;
      padding-left: 0px;
   }
`
