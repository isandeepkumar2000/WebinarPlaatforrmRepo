import styled from 'styled-components'

export const PopoverContainer = styled.div`
   outline: none;
`

export const TriggerContainer = styled.div`
   cursor: pointer;
   outline: none;
`

export const TargetContainer = styled.div``
