import React, { Component } from 'react'
import { observer, inject } from 'mobx-react'
import { reaction } from 'mobx'
import { withTranslation, WithTranslation } from 'react-i18next' //eslint-disable-line

import { API_FAILED } from '@ib/api-constants'

import { showFailureBottomCenterToast } from '../../../Common/utils/ToastUtils'

import AuthStore from '../../../UserProfile/stores/AuthStore'

interface Props extends WithTranslation {} //eslint-disable-line

interface InjectedProps extends Props {
   authStore: AuthStore
}

@inject('authStore')
@observer
class RefreshTokenReactionComponent extends Component<Props> {
   componentWillUnmount(): void {
      this.refreshTokenAPIFailureReaction()
   }

   refreshTokenAPIFailureReaction = reaction(
      () => {
         const { authStore } = this.injected
         return authStore.refreshAuthTokensAPIStatus === API_FAILED
      },
      isRefreshTokenAPIFailed => {
         if (isRefreshTokenAPIFailed) {
            this.logOutAndReloadApp()
         }
      }
   )

   get injected(): InjectedProps {
      return this.props as InjectedProps
   }

   clearAllStores = (): void => {
      const { authStore } = this.injected
      authStore.setRefreshAccessTokensError(undefined)
   }

   logOutAndReloadApp = (): void => {
      console.log('logOutAndReloadApp')
      const { t } = this.props
      showFailureBottomCenterToast(t('common:sessionExpiredMessage'))
      this.clearAllStores()
      //NOTE: Here setTimeOut is for showing toast. If we don't keep setTimeOut, reload is removing toast component by the toast shown to user
      window.location.reload(true)
   }

   render(): React.ReactNode {
      const { authStore } = this.injected
      if (authStore.refreshAuthTokensAPIStatus === API_FAILED) {
         this.logOutAndReloadApp()
      }
      return <div />
   }
}

export default withTranslation()(RefreshTokenReactionComponent)
