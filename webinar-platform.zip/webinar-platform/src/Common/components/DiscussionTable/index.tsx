import React from 'react'
import DiscussionTableProps from './indexProps'

export interface Course {
   date: string
   url: string
   name: string
   topic: string
   replies: number
}

const DiscussionTable = () => {
   const courses: Course[] = [
      {
         date: '2022-05-01',
         url: 'https://example.com/course-1',
         name: 'Course 1',
         topic: 'React.js',
         replies: 10
      },
      {
         date: '2022-06-01',
         url: 'https://example.com/course-2',
         name: 'Course 2',
         topic: 'Node.js',
         replies: 5
      },
      {
         date: '2022-07-01',
         url: 'https://example.com/course-3',
         name: 'Course 3',
         topic: 'MongoDB',
         replies: 15
      }
   ]

   return (
      <div>
         <DiscussionTableProps courses={courses} />
      </div>
   )
}

export default DiscussionTable
