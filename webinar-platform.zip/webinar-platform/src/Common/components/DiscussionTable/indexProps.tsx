import React from 'react'

interface Course {
   date: string
   url: string
   name: string
   topic: string
   replies: number
}

interface Props {
   courses: Course[]
}

const DiscussionTableProps = props => {
   return (
      <table>
         <thead>
            <tr>
               <th>CREATED DATE</th>
               <th>DISCUSSION URL</th>
               <th>NO OF REPLIES</th>
               <th>COURSE</th>
               <th>TOPIC</th>
            </tr>
         </thead>
         <tbody>
            {props.courses.map((course, index) => (
               <tr key={index}>
                  <td>{course.date}</td>
                  <td>{course.url}</td>
                  <td>{course.name}</td>
                  <td>{course.topic}</td>
                  <td>{course.replies}</td>
               </tr>
            ))}
         </tbody>
      </table>
   )
}

export default DiscussionTableProps
