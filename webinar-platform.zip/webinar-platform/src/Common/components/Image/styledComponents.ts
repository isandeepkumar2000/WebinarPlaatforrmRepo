import styled from 'styled-components'

export const ReactImage = styled.img`
   user-select: none;
`
