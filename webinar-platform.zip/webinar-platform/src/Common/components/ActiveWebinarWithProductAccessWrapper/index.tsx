import { observable, computed, action } from 'mobx'
import { observer } from 'mobx-react'
import React, { Component } from 'react'

import {
   APIStatus,
   API_FAILED,
   API_FETCHING,
   API_INITIAL,
   API_SUCCESS
} from '@ib/api-constants'

import { accessTypes } from '../../../ContentManagement/constants/BackendConstants'
import { ActiveWebinarsStore } from '../../../ContentManagement/stores/ActiveWebinarsStore/ActiveWebinarsStore'
import WebinarAccessConfiguration from '../../../ContentManagement/stores/models/WebinarAccessConfiguration'
import { openLinkInSameWindow } from '../../../LiveWebinar/utils/windowsUtils'

import { captureError } from '../../utils/DecoratorLogEntriesUtils'
import AppsAndSubscriptionsStore from '../../stores/AppsAndSubscriptionsStore'
import { NO_ACCESSIBLE_VIEW_REQUEST_LINK } from '../../constants/BackendConstants'
import { getUpdatedRegistrationLink } from '../../utils/WebinarRegistrationUtils'

import LoadingWrapperWithFailure from '../LoadingWrapperWithFailure'
import WebinarNotAccessibleView from '../WebinarNotAccessibleView'
import { DARK_THEME } from '../../constants/ThemeConstants'
import Colors from '../../themes/Colors'
import { failureViewMessageCss } from './styledComponents'

interface Props {
   activeWebinarsStore: ActiveWebinarsStore
   appsAndSubscriptionsStore: AppsAndSubscriptionsStore
   webinarAccessConfiguration: WebinarAccessConfiguration | null
   webinarIdsList: string[]

   renderWrappedComponent: any
   accessibleProducts: Array<string>
   theme: string
   registrationLink: string
}

@observer
class ActiveWebinarWithProductAccessWrapper extends Component<Props> {
   @observable mockAPIStatus!: APIStatus
   @observable isWebinarAccessible: boolean

   constructor(props: Props) {
      super(props)

      this.isWebinarAccessible = false
      this.setMockAPIStatus(API_INITIAL)
      this.doNetworkCallBasedOnAccessibility()
   }

   @computed get apiError(): Error | null {
      const {
         activeWebinarsStore,
         appsAndSubscriptionsStore,
         webinarAccessConfiguration
      } = this.props
      const { getWebinarsConfigDetailsAPIError } = activeWebinarsStore
      const { getAppsAndSubscriptionsAPIError } = appsAndSubscriptionsStore

      if (webinarAccessConfiguration) {
         const { accessType } = webinarAccessConfiguration
         return accessType === accessTypes.formsRegistration
            ? getWebinarsConfigDetailsAPIError
            : accessType === accessTypes.appsAndSubscriptions
            ? getAppsAndSubscriptionsAPIError
            : null
      }
      return null
   }

   getIsWebinarAccessibleWithAllProducts = (): boolean => {
      const { appsAndSubscriptionsStore, accessibleProducts } = this.props
      const { productCodeArray } = appsAndSubscriptionsStore

      return accessibleProducts?.every(eachProduct =>
         productCodeArray.includes(eachProduct)
      )
   }

   getIsWebinarAccessibleWithSingleProduct = (): boolean => {
      const { appsAndSubscriptionsStore, accessibleProducts } = this.props
      const { productCodeArray } = appsAndSubscriptionsStore

      return accessibleProducts?.some(eachProduct =>
         productCodeArray.includes(eachProduct)
      )
   }
   getIsWebinarAccessibleBasedOnConfig = (
      isOneProductAccessSufficient: boolean
   ): boolean =>
      isOneProductAccessSufficient
         ? this.getIsWebinarAccessibleWithSingleProduct()
         : this.getIsWebinarAccessibleWithAllProducts()

   setMockAPIStatus = (status: APIStatus): void => {
      this.mockAPIStatus = status
   }

   @action.bound
   @captureError('webinarAccessibilityMockAPI')
   onFailure(): void {
      this.setMockAPIStatus(API_FAILED)
   }

   onSuccessFetchAndCheckAppsAndSubscriptions = (): void => {
      const { webinarAccessConfiguration } = this.props

      let isOneProductAccessSufficient: boolean

      if (webinarAccessConfiguration)
         isOneProductAccessSufficient =
            webinarAccessConfiguration.isOneProductAccessSufficient
      else isOneProductAccessSufficient = false

      this.isWebinarAccessible = this.getIsWebinarAccessibleBasedOnConfig(
         isOneProductAccessSufficient
      )

      this.setMockAPIStatus(API_SUCCESS)
   }

   fetchAndCheckAppsAndSubscriptions = (): void => {
      const { appsAndSubscriptionsStore } = this.props

      appsAndSubscriptionsStore.getUserAppsAndSubscriptions(
         this.onSuccessFetchAndCheckAppsAndSubscriptions,
         this.onFailure
      )
   }

   onSuccessFetchAndCheckWebinarDetails = (): void => {
      const { activeWebinarsStore } = this.props

      this.isWebinarAccessible = activeWebinarsStore.webinarsConfigDetails.some(
         ({ isUserRegistered }) => isUserRegistered
      )
      this.setMockAPIStatus(API_SUCCESS)
   }

   fetchAndCheckWebinarDetails = (): void => {
      const { activeWebinarsStore, webinarIdsList } = this.props

      activeWebinarsStore.getWebinarsConfigDetails(
         { webinar_ids: webinarIdsList },
         this.onSuccessFetchAndCheckWebinarDetails,
         this.onFailure
      )
   }

   doNetworkCallBasedOnAccessibility = (): void => {
      const { accessibleProducts, webinarAccessConfiguration } = this.props

      this.setMockAPIStatus(API_FETCHING)
      switch (webinarAccessConfiguration?.accessType) {
         case accessTypes.formsRegistration:
            this.fetchAndCheckWebinarDetails()
            break

         case accessTypes.appsAndSubscriptions:
         default:
            if (accessibleProducts && accessibleProducts.length === 0) {
               this.setMockAPIStatus(API_SUCCESS)
               this.isWebinarAccessible = true
            } else {
               this.fetchAndCheckAppsAndSubscriptions()
            }
      }
   }

   renderWebinarInAccessibleView = (webinarAccessLink: string) => {
      const { theme, webinarAccessConfiguration } = this.props

      return (
         <WebinarNotAccessibleView
            key={theme}
            theme={theme}
            webinarAccessLink={webinarAccessLink}
            inaccessibleViewText={
               webinarAccessConfiguration?.webinarInaccessibleViewText
            }
         />
      )
   }

   navigateDirectlyForRegistration = (registrationLink: string) => {
      openLinkInSameWindow(registrationLink)
   }

   renderInaccessibleViewBasedOnConfig = () => {
      const { registrationLink, webinarAccessConfiguration } = this.props

      let updatedRegistrationLink

      if (registrationLink) {
         updatedRegistrationLink = getUpdatedRegistrationLink(registrationLink)
      }

      if (webinarAccessConfiguration) {
         const { shouldRedirectToWebinarDirectly } = webinarAccessConfiguration

         if (shouldRedirectToWebinarDirectly) {
            if (registrationLink) {
               this.navigateDirectlyForRegistration(updatedRegistrationLink)
            } else {
               return this.renderWebinarInAccessibleView(
                  NO_ACCESSIBLE_VIEW_REQUEST_LINK
               )
            }
         } else {
            const webinarAccessLink =
               registrationLink !== ''
                  ? updatedRegistrationLink
                  : NO_ACCESSIBLE_VIEW_REQUEST_LINK

            return this.renderWebinarInAccessibleView(webinarAccessLink)
         }
      } else {
         if (registrationLink) {
            this.navigateDirectlyForRegistration(updatedRegistrationLink)
         } else {
            return this.renderWebinarInAccessibleView(
               NO_ACCESSIBLE_VIEW_REQUEST_LINK
            )
         }
      }
   }

   renderSuccessUI = observer(() => {
      const { renderWrappedComponent } = this.props
      return this.isWebinarAccessible
         ? renderWrappedComponent()
         : this.renderInaccessibleViewBasedOnConfig()
   })

   render() {
      const { theme } = this.props
      const bgColor = theme === DARK_THEME ? Colors.darkTwo : 'transparent'

      return (
         <LoadingWrapperWithFailure
            apiStatus={this.mockAPIStatus}
            apiError={this.apiError}
            renderSuccessUI={this.renderSuccessUI}
            onRetryClick={this.doNetworkCallBasedOnAccessibility}
            height={'calc(100% - 72px)'}
            backgroundColor={bgColor}
            failureViewMessageCss={failureViewMessageCss}
         />
      )
   }
}

export default ActiveWebinarWithProductAccessWrapper
