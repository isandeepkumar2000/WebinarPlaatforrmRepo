import { css } from 'styled-components'

import { mobile, minDeviceWidth } from '../../utils/MixinUtils'

export const failureViewMessageCss = css`
   line-height: 1.33;
   text-align: center;
   color: ${props => props.theme.primaryItemsSectionColor};
   max-width: 70%;
   ${mobile} {
      font-size: 16px;
      line-height: 1.5;
   }

   ${minDeviceWidth(768)} {
      font-size: 24px;
      line-height: 1.5;
   }

   ${minDeviceWidth(1024)} {
      font-size: 32px;
   }
`
