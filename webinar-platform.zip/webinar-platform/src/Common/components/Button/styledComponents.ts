import styled from 'styled-components'

import { Typo14WhiteHKGroteskSemiBold } from '../../styleGuide/Typos'
import Colors from '../../themes/Colors'

import { variants, sizes, shapes } from './constants'

const { small } = sizes
const { primary, secondary, tertiary } = variants
const { square, pill, round } = shapes
type variant = 'PRIMARY' | 'SECONDARY' | 'TERTIARY'
type size = 'SMALL'
type shape = 'SQUARE' | 'PILL' | 'ROUND'

const getBtnSize = (size: size): string => {
   switch (size) {
      case small:
         return '4px 16px'
      default:
         return '8px 20px'
   }
}

const getBackgroundColor = (variant: variant): string => {
   switch (variant) {
      case primary:
         return Colors.blue
      case secondary:
         return Colors.white
      case tertiary:
         return 'transparent'
      default:
         return Colors.blue
   }
}

const getBorder = (variant: variant): string => {
   switch (variant) {
      case primary:
         return 'none'
      case secondary:
         return `1px solid ${Colors.lightBlueGrey}`
      case tertiary:
         return 'none'
      default:
         return 'none'
   }
}

const getColor = (variant: variant): string => {
   switch (variant) {
      case primary:
         return Colors.white
      case secondary:
         return Colors.darkBlueGrey
      case tertiary:
         return Colors.steel
      default:
         return Colors.white
   }
}

const getBorderRadius = (shape: shape): string => {
   switch (shape) {
      case pill:
         return '100px'
      case round:
         return '50%'
      case square:
         return 'none'
      default:
         return '4px'
   }
}

export const StyledButton = styled.button`
   border: none;
   padding: ${props => getBtnSize(props.size)};
   background-color: ${props => getBackgroundColor(props.variant)};
   border: ${props => getBorder(props.variant)};
   border-radius: ${props => getBorderRadius(props.shape)};
   color: ${props => getColor(props.variant)};
   cursor: ${props => (props.disabled ? 'not-allowed' : 'pointer')};
   opacity: ${props => (props.disabled ? '0.5' : 'none')};
   outline: 0;
   ::-moz-focus-inner {
      border: 0;
   }
`

export const ButtonText = styled(Typo14WhiteHKGroteskSemiBold)`
   line-height: 1.71;
   letter-spacing: normal;
`
