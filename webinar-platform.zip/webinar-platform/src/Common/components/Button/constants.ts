export const sizes = { small: 'SMALL' }

export const variants = {
   primary: 'PRIMARY',
   secondary: 'SECONDARY',
   tertiary: 'TERTIARY'
}

export const shapes = {
   round: 'ROUND',
   square: 'SQUARE',
   pill: 'PILL'
}
