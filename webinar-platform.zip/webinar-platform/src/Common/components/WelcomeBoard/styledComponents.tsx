import styled from 'styled-components'

import { mobile, minDeviceWidth } from '../../utils/MixinUtils'
import { Typo16CharcoalGreyHKGroteskSemiBold } from '../../styleGuide/Typos'
import Image from '../Image'

type Props = {
   height: number
   width: number
}

export const Container = styled.div`
   border-radius: 16px;
   background-color: ${props => props.theme.secondaryBackgroundColor};
   display: flex;
   flex-direction: column;
   align-items: center;
   padding: 32px 0;
   width: initial;
   height: auto;

   ${minDeviceWidth(1024)} {
      padding: 64px 0;
   }
   border: 1px solid ${props => props.theme.primaryBorderColor};
`

export const QuestionCominSoonText = styled(
   Typo16CharcoalGreyHKGroteskSemiBold
)`
   text-align: center;
   color: ${props => props.theme.primaryTextColor};

   ${mobile} {
      font-size: 18px;
      margin-top: 32px;
   }

   ${minDeviceWidth(768)} {
      font-size: 20px;
      font-weight: bold;
      line-height: 1.2;
      margin-top: 48px;
   }

   ${minDeviceWidth(1024)} {
      font-size: 20px;
      font-weight: bold;
      line-height: 1.2;
      margin-top: 32px;
      width: 80%;
   }
`
export const WelcomeImage = styled(Image)<{ props: any }>`
   height: ${props => props.height}px;
   width: ${props => props.width}px;
`
