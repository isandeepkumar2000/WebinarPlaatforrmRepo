import React from 'react'
import { storiesOf } from '@storybook/react'

import WelcomeBoard from '.'

storiesOf('WelcomeBoard', module).add('WelcomeBoard', () => <WelcomeBoard />)
