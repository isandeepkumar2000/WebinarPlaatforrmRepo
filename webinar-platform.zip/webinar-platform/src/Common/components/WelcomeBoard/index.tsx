import React from 'react'
import { WithTranslation, withTranslation } from 'react-i18next' //eslint-disable-line

import {
   isMobile,
   isDesktop,
   isTabletOrMobile
} from '../../utils/ResponsiveUtils'

import {
   Container,
   QuestionCominSoonText,
   WelcomeImage
} from './styledComponents'

function WelcomeBoard(props: WithTranslation) {
   const { t } = props

   const getMobileIconDimensions = () => {
      if (isMobile()) {
         return { width: 220, height: 152 }
      }
      if (isTabletOrMobile()) {
         return { width: 300, height: 208 }
      }
      if (isDesktop()) {
         return {
            width: 220,
            height: 152
         }
      }
      return
   }
   return (
      <Container>
         <WelcomeImage
            src={
               'https://live-interaction-media-static.s3.ap-south-1.amazonaws.com/website-static-images/welcome@3x.png'
            }
            alt={`${t('Failure-image')}`}
            {...getMobileIconDimensions()}
         />
         <QuestionCominSoonText>
            {t('Answer the questions here')}
         </QuestionCominSoonText>
      </Container>
   )
}

export default withTranslation()(WelcomeBoard)
