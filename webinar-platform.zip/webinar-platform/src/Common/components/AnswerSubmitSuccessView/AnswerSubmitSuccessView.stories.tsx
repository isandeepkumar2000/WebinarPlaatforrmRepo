import React from 'react'
import { storiesOf } from '@storybook/react'

import AnswerSubmitSuccessView from '.'

storiesOf('AnswerSubmitSuccessView', module).add(
   'AnswerSubmitSuccessView',
   () => <AnswerSubmitSuccessView />
)
