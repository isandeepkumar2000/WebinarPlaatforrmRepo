import styled from 'styled-components'

import {
   Typo18GunMetalHKGroteskMedium,
   Typo14BattleshipGreyHKGroteskMediumText
} from '../../styleGuide/Typos'
import { mobile, minDeviceWidth } from '../../utils/MixinUtils'

export const Container = styled.div`
   border-radius: 4px;
   border-radius: 16px;
   background-color: ${props => props.theme.secondaryBackgroundColor};
   display: flex;
   flex-direction: column;
   align-items: center;
   width: 100%;
   height: auto;
   ${mobile} {
      padding: 32px 0;
   }

   ${minDeviceWidth(768)} {
      padding: 100px 0;
   }

   ${minDeviceWidth(1024)} {
      padding: 64px 0;
   }
   border: 1px solid ${props => props.theme.primaryBorderColor};
`

export const SubmittedAnswerText = styled(Typo18GunMetalHKGroteskMedium)`
   line-height: 1.33;
   text-align: center;
   margin-top: 32px;
   color: ${props => props.theme.tertiaryTextColorTwo};

   ${mobile} {
      width: 184px;
      font-size: 18px;
      margin-top: 12px;
   }

   ${minDeviceWidth(768)} {
      width: 246px;
      font-size: 24px;
      font-weight: 600;
   }

   ${minDeviceWidth(1024)} {
      width: 205px;
      font-size: 20px;
      font-weight: bold;
      line-height: 1.2;
      margin-top: 32px;
   }
`

export const NextQuestionText = styled(Typo14BattleshipGreyHKGroteskMediumText)`
   width: 221px;
   line-height: 1.71;
   text-align: center;
   font-size: 18px;
   color: ${props => props.theme.tertiaryTextColorTwo};

   ${mobile} {
      width: 184px;
      font-size: 14px;
      margin-top: 36px;
   }

   ${minDeviceWidth(768)} {
      margin-top: 128px;
      line-height: 1.33;
   }

   ${minDeviceWidth(1024)} {
      width: 224px;
      line-height: 1.33;
      margin-top: 48px;
   }
`
