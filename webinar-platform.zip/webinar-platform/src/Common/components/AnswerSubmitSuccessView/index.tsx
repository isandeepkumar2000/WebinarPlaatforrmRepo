import React from 'react'

import { WithTranslation, withTranslation } from 'react-i18next' //eslint-disable-line
import { withTheme } from 'styled-components'

import CheckMarkIcon from '../../icons/CheckMarkIcon'
import { isMobile } from '../../utils/ResponsiveUtils'

import {
   Container,
   SubmittedAnswerText,
   NextQuestionText
} from './styledComponents'

function AnswerSubmitSuccessView(props: WithTranslation) {
   const { t } = props

   const getMobileIconDimesnsion = () => {
      if (isMobile()) {
         return { width: 48, height: 48 }
      }

      return null
   }

   return (
      <Container>
         <CheckMarkIcon {...getMobileIconDimesnsion()} />
         <SubmittedAnswerText>{t('Submitted')}</SubmittedAnswerText>
         <NextQuestionText>{t('Wait for the next question')}</NextQuestionText>
      </Container>
   )
}

export default withTheme(withTranslation()(AnswerSubmitSuccessView))
