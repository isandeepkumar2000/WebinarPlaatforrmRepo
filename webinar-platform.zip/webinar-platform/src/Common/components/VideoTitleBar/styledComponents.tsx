import styled from 'styled-components'

import {
   Typo20CharcoalGreyHKGroteskBold,
   Typo14CeruleanHKGroteskSemiBold
} from '../../styleGuide/Typos'
import { mobile, minDeviceWidth } from '../../utils/MixinUtils'
import { LIGHT_THEME } from '../../constants/ThemeConstants'
import { getSelectedTheme } from '../../utils/LocalStorageUtils'
import ChevronUpArrow from '../../icons/ChevronUpArrow'
import ChevronDownArrow from '../../icons/ChevronDownArrow'

interface VideoProps {
   isVideoOpen: boolean
}

export const Container = styled.div`
   width: auto;
   display: flex;
   align-items: center;
   justify-content: space-between;
   padding: 32px 0px;
   background-color: ${props => props.theme.tertiaryBackgroundColor};
   padding-left: 20px;
   padding-right: 9px;
   ${mobile} {
      width: auto;
      padding: 18px 8px;
   }
   ${minDeviceWidth(1025)} {
      width: ${props => (!props.isVideoOpen ? '100%' : 'auto')};
      border-bottom-left-radius: 12px;
      border-bottom-right-radius: 12px;
      border-top-left-radius: ${(props: VideoProps) =>
         props.isVideoOpen ? null : '12px'};
      border-top-right-radius: ${(props: VideoProps) =>
         props.isVideoOpen ? null : '12px'};
   }
   margin-top: ${props => (getSelectedTheme() === LIGHT_THEME ? '2px' : '0px')};
`

export const TitleText = styled(Typo20CharcoalGreyHKGroteskBold)`
   line-height: 1.2;
   width: 60%;
   overflow: hidden;
   text-overflow: ellipsis;
   white-space: nowrap;
   color: ${props => props.theme.tertiaryTextColor};
   ${mobile} {
      margin-left: 14px;
      font-size: 14px;
      width: 54%;
   }
`

export const ShowHideVideoText = styled(Typo14CeruleanHKGroteskSemiBold)`
   line-height: 1.14;
   white-space: nowrap;
   user-select: none;
   cursor: pointer;
   color: ${props => props.theme.secondaryActionColor};
`

export const ShowHideVideoTextContainer = styled.div`
   display: flex;
   padding: 10px;
   align-items: center;
`
export const UpArrow = styled(ChevronUpArrow)`
   margin-left: 4px;
   margin-top: 2px;
   width: 20px;
   height: 20px;
   fill: ${props => props.theme.secondaryActionColor};
`
export const DownArrow = styled(ChevronDownArrow)`
   margin-left: 4px;
   width: 20px;
   height: 20px;
   fill: ${props => props.theme.secondaryActionColor};
`
