export const videoTitleText =
   'Webinar on Getting high-paid jobs with OTG and CCBP Models'
