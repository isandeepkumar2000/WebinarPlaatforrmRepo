import React, { Component } from 'react'
import { observer } from 'mobx-react'
import { WithTranslation, withTranslation } from 'react-i18next' //eslint-disable-line
import { observable } from 'mobx'

import { videoTitleText } from './constants'
import {
   Container,
   TitleText,
   ShowHideVideoTextContainer,
   ShowHideVideoText,
   UpArrow,
   DownArrow
} from './styledComponents'

interface Props extends WithTranslation {
   onClickShowHideVideo: (showVideo: boolean) => void
   webinarTitle?: string | undefined
}

@observer
class VideoTitleBar extends Component<Props> {
   @observable showVideo: boolean

   constructor(props) {
      super(props)
      this.showVideo = true
   }

   toggleShowVideo = (): void => {
      const { onClickShowHideVideo } = this.props
      this.showVideo = !this.showVideo
      onClickShowHideVideo(this.showVideo)
   }

   renderVideoTitleView = (): React.ReactNode => {
      const { t, webinarTitle } = this.props

      return (
         <TitleText>
            {webinarTitle ??
               `${t(
                  'Webinar on Getting high-paid jobs with OTG and CCBP Models'
               )}`}
         </TitleText>
      )
   }

   getVideTitleText = (): React.ReactNode => {
      if (this.showVideo) {
         return videoTitleText
      }
      return videoTitleText
   }

   getShowHideVideoText = (): string => {
      const { t } = this.props
      if (this.showVideo) {
         return t('Hide Video')
      }
      return t('Show Video')
   }

   render(): React.ReactNode {
      return (
         <Container isVideoOpen={this.showVideo}>
            {this.renderVideoTitleView()}
            <ShowHideVideoTextContainer onClick={this.toggleShowVideo}>
               <ShowHideVideoText>
                  {this.getShowHideVideoText()}
               </ShowHideVideoText>
               {this.showVideo ? <UpArrow /> : <DownArrow />}
            </ShowHideVideoTextContainer>
         </Container>
      )
   }
}

export default withTranslation()(VideoTitleBar)
