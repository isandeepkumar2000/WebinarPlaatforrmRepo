import React from 'react'
import { storiesOf } from '@storybook/react'
import { action } from '@storybook/addon-actions'

import VideoTitleBar from '.'

storiesOf('VideoTitleBar', module).add('VideoTitleBar', () => (
   <VideoTitleBar onClickShowHideVideo={action('clicked')} />
))
