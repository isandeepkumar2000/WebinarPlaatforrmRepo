import styled from 'styled-components'

import { TYPE_FORM_MODAL_CLOSE_BUTTON_Z_INDEX } from '../../constants/ZIndexConstants'
import Colors from '../../themes/Colors'
import { mobile, tablet, customDevice } from '../../utils/MixinUtils'

export const CloseButton = styled.div`
   position: absolute;
   z-index: ${TYPE_FORM_MODAL_CLOSE_BUTTON_Z_INDEX};
   width: 25px;
   height: 25px;
   right: 20px;
   top: 20px;
   background-color: ${Colors.white};
   display: flex;
   align-items: center;
   justify-content: center;
   border-radius: 5px;
   cursor: pointer;
   :hover {
      background-color: ${Colors.orangeRed};
   }
`

export const TypeFormWrapper = styled.div`
   width: 900px;
   height: 600px;
   display: flex;
   flex-direction: column;
   justify-content: center;
   align-items: center;
   ${mobile} {
      width: 350px;
      height: 80vh;
   }
   ${tablet} {
      width: 700px;
      max-height: 80vh;
   }
   ${customDevice(550, 767)} {
      width: 500px;
      max-height: 80vh;
   }
`
