import React, { Component } from 'react'
import { observer } from 'mobx-react'

import CloseIcon from '../../icons/CloseIcon'
import Colors from '../../themes/Colors'

import BaseModalContainer from '../BaseModalContainer'
import TypeForm from '../TypeForm'

import { CloseButton, TypeFormWrapper } from './styledComponents'
import './styles.scss'

interface Props {
   url: string
   isEmbed?: boolean
   closeTypeForm: () => void
}

@observer
class TypeFormModal extends Component<Props> {
   closeModal = (): void => {
      const { closeTypeForm } = this.props

      closeTypeForm()
   }

   isValidUrl(url: string): boolean {
      return url && url !== '' ? true : false
   }

   render() {
      const { url, isEmbed } = this.props
      if (this.isValidUrl(url)) {
         return (
            <BaseModalContainer
               data-testid='type-form'
               isOpen={true}
               className={'modalStyles'}
               overlayClassName={'overlayStyles'}
               ariaHideApp={false}
               hideCloseIcon
            >
               <CloseButton
                  onClick={this.closeModal}
                  data-testid='type-form-close'
               >
                  <CloseIcon fill={Colors.blueGreyTwo} />
               </CloseButton>
               <TypeFormWrapper>
                  <TypeForm url={url} isEmbed={isEmbed} />
               </TypeFormWrapper>
            </BaseModalContainer>
         )
      }
      return null
   }
}

export default TypeFormModal
