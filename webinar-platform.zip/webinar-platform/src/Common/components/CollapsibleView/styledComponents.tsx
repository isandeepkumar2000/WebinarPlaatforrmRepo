import styled from 'styled-components'

export const CollapsibleViewContainer = styled.div`
   width: 100%;
`
