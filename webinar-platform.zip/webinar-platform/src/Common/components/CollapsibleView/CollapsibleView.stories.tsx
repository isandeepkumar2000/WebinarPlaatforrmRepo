import React from 'react'
import { storiesOf } from '@storybook/react'
import { css } from 'styled-components'
import { withKnobs, boolean, object } from '@storybook/addon-knobs'

import CollapsibleView from '.'

const containerCSS = css`
   background-color: #f1f4f8;
`

const DetailsView = (): React.ReactNode => (
   <div>
      <p>Details</p>
   </div>
)
const SummaryView = (): React.ReactNode => (
   <div>
      <p>Section</p>
   </div>
)

storiesOf('Behaviour/CollapsibleView', module)
   .addDecorator(withKnobs)
   .add('with Knobs View', () => (
      <CollapsibleView
         renderSummaryView={SummaryView}
         renderDetailsView={DetailsView}
         isOpen={boolean('isOpen', true)}
         containerCSS={object('containerCSS', containerCSS)}
      />
   ))
