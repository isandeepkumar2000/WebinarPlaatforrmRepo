import LoginForm from './LoginForm'
export default LoginForm
