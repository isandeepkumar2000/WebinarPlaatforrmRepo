import styled, { css } from 'styled-components'
import Select from 'react-select'
import BaseModalContainer from '../BaseModalContainer'

import {
   Typo12PinkishOrangeHKGrotesk,
   BaseHKGroteskMediumText,
   Typo30paleGreyHKGroteskBold,
   Typo12SteelHKGroteskSemiBold,
   Typo18CharcoalGreyHKGroteskMedium,
   Typo16SlateHKGroteskSemiBold,
   Typo14DarkBlueGreyHKGroteskSemiBold
} from '../../styleGuide/Typos'
import Colors from '../../themes/Colors'
import { DARK_THEME } from '../../constants/ThemeConstants'
import { minDeviceWidth, tablet, mobile, desktop } from '../../utils/MixinUtils'
import TextInput from '../TextInput'
import Button from '../Button'

export const LoginFormWrapper = styled.div``

export const RegistrationModel = styled(BaseModalContainer)`
   min-height: 1000px;
   width: 100%;
   display: flex;
   flex-direction: column;
   align-items: center;
   background-color: ${props =>
      props.theme === DARK_THEME ? Colors.darkBlur : Colors.whiteBlur};
   -webkit-backdrop-filter: blur(10px);
   backdrop-filter: blur(10px);
   transition: all 0.25s linear;
   outline: none;
   user-select: none;
   overflow: hidden;
`
export const ErrorMessage = styled(Typo12PinkishOrangeHKGrotesk)`
   display: ${props => (props.isHidden ? 'block' : 'none')};
   width: 100%;

   margin-bottom: 5px;
`
export const UserTextInput = styled(TextInput)`
   -webkit-appearance: none;
   height: 40px;
   margin-top: 8px;
   background-color: transparent;
   color: ${props => props.theme.secondaryTextColor};
   border: 1px solid ${Colors.coolGrey};
   &:focus {
      border: solid 2px ${Colors.cerulean};
      outline: none;
      font-weight: bold;
   }
   ${minDeviceWidth(1024)} {
      width: 348px;
   }
   ${tablet} {
      width: 356px;
   }
   ${mobile} {
      width: 296px;
   }
`
export const UserTextInputWrapper = styled.div`
   margin-bottom: 24px;
`

export const LoginText = styled(BaseHKGroteskMediumText)`
   display: flex;
   width: 90%;
   justify-content: center;
   align-items: center;
   text-align: center;
   color: ${props =>
      props.theme === DARK_THEME
         ? Colors.lightBlueGrey
         : Colors.battleshipGrey};
`
export const FormFooterNoteText = styled(BaseHKGroteskMediumText)`
   -webkit-font-smoothing: antialiased;
   display: flex;
   flex-wrap: wrap;
   font-size: 14px;
   ${desktop} {
      width: 350px;
   }
   ${mobile} {
      width: 260px;
   }
   ${tablet} {
      width: 350px;
   }
   color: ${props => props.theme.tertiaryTextColorTwo};
   a {
      color: ${props => props.theme.tertiaryTextColorTwo};
   }
`

export const LoginModalBody = styled.div`
   display: flex;
   width: auto;
   height: auto;
   flex-direction: column;
   justify-content: center;
   align-items: center;
`
export const LoginHeader = styled.div`
   display: flex;
   justify-content: center;
   align-items: center;
   margin-top: 16px;
   margin-bottom: 48px;
   width: 100%;
   flex-wrap: wrap;
   text-align: center;
`

export const LoginModalWrapper = styled.div`
   display: flex;
   flex-direction: column;
   margin-top: 30px;
   align-items: center;
   min-height: 392px;
   width: 620px;
   height: auto;
   ${tablet} {
      width: 420px;
      margin-top: 130px;
   }
   ${mobile} {
      width: 344px;
      margin-top: 40px;
   }
`

export const WelcomeText = styled(Typo30paleGreyHKGroteskBold)`
   text-transform: uppercase;
   color: ${props => props.theme.primaryTextColor};
`
export const FieldText = styled(Typo12SteelHKGroteskSemiBold)`
   display: flex;
   width: 100%;
   justify-content: flex-start;
   text-transform: uppercase;
`
export const ButtonWrapper = styled.div`
   display: flex;
   justify-content: center;
   align-items: center;
   width: 100%;
`

export const JoinWebinarButton = styled(Button)`
   height: 40px;
   width: 140px;
   background-color: ${Colors.cerulean};
`
export const CheckboxGroupWrapper = styled.div`
   display: flex;
   flex-direction: column;
   width: 100%;
   height: auto;
   margin-bottom: 20px;
   flex-wrap: wrap;
`
export const checkBoxTextCss = css`
   display: flex;
   flex-wrap: wrap;
   width: 100%;
   font-size: 14px;
   width: 260px;
   color: ${props => props.theme.primaryTextColor};
`
export const RemindMeText = styled(Typo18CharcoalGreyHKGroteskMedium)`
   display: flex;
   color: ${props => props.theme.tertiaryTextColorTwo};
   user-select: none;
   flex-wrap: wrap;
   word-break: break-word;
   width: 100%;
`
export const Dropdown = styled(Select)`
   outline: none;
   width: 100% !important;
   padding: 0px;
   align-items: center;
   justify-content: center;
   font-family: 'HKGrotesk';
   height: 40px;
   margin-top: 10px;
   margin-bottom: 8px;
`
export const radioItemCss = css`
   ${Typo16SlateHKGroteskSemiBold};
   margin-top: 24px;
   margin-bottom: 24px;
   color: ${props => props.theme.primaryTextColor};
`
export const RadioGroupWrapper = styled.div`
   display: flex;
   flex-direction: column;
   width: 100%;
   justify-content: flex-start;
`

export const LanguageDropdown = styled(Select)`
   outline: none;
   width: 100% !important;
   padding: 0px;
   align-items: center;
   justify-content: center;
   font-family: 'HKGrotesk';
   height: 40px;
   margin-top: 10px;
   margin-bottom: 8px;
`
export const ComingSoonText = styled(Typo14DarkBlueGreyHKGroteskSemiBold)`
   display: flex;
   width: 100%;
   justify-content: flex-start;
   color: ${props => props.theme.trialFeaturesColor};
   margin-bottom: 10px;
`
export const WhatsAppConsentWrapper = styled.div`
   width: 100%;
   margin-top: 0px;
   margin-bottom: 20px;
   padding-top: 8px;
`
export const FormFooterNoteTextWrapper = styled(WhatsAppConsentWrapper)`
   a {
      text-decoration: underline;
   }
`
