export const genderOptions = [
   {
      label: 'Male',
      value: 'MALE'
   },
   {
      label: 'Female',
      value: 'FEMALE'
   },
   {
      label: 'Transgender',
      value: 'TRANSGENDER'
   }
]
