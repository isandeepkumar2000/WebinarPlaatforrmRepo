import React, { Component } from 'react'
import { WithTranslation, withTranslation } from 'react-i18next' //eslint-disable-line
import { observable } from 'mobx'
import { withRouter } from 'react-router-dom'
import { observer, inject } from 'mobx-react'
import { History } from 'history'
import { withTheme } from 'styled-components'

import DesktopLayout from '../DesktopLayout'
import UserDetails from '../../../UserProfile/stores/UserDetailsStore'
import { ActiveWebinarsStore } from '../../../ContentManagement/stores/ActiveWebinarsStore/ActiveWebinarsStore'
import ThemeStore from '../../stores/ThemeStore'
import { goToHomePage } from '../../utils/NavigationUtils'
import { getIconDimensions } from '../../utils/LogoUtils'
import {
   setIsSyncedWithBackend,
   SYNCED_WITH_BACKEND,
   NOT_SYNCED_WITH_BACKEND,
   setUserName,
   setMobileNumber,
   setWhatsAppConsent,
   getWhatsAppConsent
} from '../../utils/LocalStorageUtils'
import { ErrorObject, validateEmpty } from '../../utils/ValidationUtils'
import { validateMiniumSixDigitsPhoneNumber } from '../../../UserProfile/utils/ValidationUtils'
import { getQueryStringValue } from '../../utils/RouteUtils/index'
import { validationTypes } from '../../constants/BackendConstants'
import { UTM_SOURCE } from '../../constants/NavigationConstants'
import BaseCheckBox from '../BaseCheckBox'

import {
   LoginFormWrapper,
   RegistrationModel,
   UserTextInput,
   UserTextInputWrapper,
   LoginText,
   LoginModalBody,
   LoginHeader,
   LoginModalWrapper,
   WelcomeText,
   FieldText,
   ButtonWrapper,
   JoinWebinarButton,
   checkBoxTextCss,
   RemindMeText,
   WhatsAppConsentWrapper
} from './styledComponents'

interface LoginFormPropTypes extends WithTranslation {
   history: History
   hideBackButton?: boolean
   submitButtonName: string
   onSubmit: Function
   handleLoginModal: Function
   validationType?: string
   theme: any
   headingText: string
   location: Location
   showWhatsAppConsent: boolean
}

interface InjectedProps extends LoginFormPropTypes {
   userDetailsStore: UserDetails
   themeStore: ThemeStore
   activeWebinarsStore: ActiveWebinarsStore
}
@inject('userDetailsStore', 'activeWebinarsStore', 'themeStore')
@observer
class LoginForm extends Component<LoginFormPropTypes> {
   static defaultProps = {
      hideBackButton: false,
      validationType: validationTypes.defaultValidation,
      showWhatsAppConsent: true
   }
   @observable phoneNumber!: string
   @observable username!: string
   @observable usernameRef
   @observable phoneNumberRef
   @observable showLoginModal = true
   @observable whatsAppConsent!: boolean

   constructor(props) {
      super(props)
      this.phoneNumber = ''
      this.username = ''
      this.usernameRef = React.createRef()
      this.phoneNumberRef = React.createRef()
      this.whatsAppConsent = this.getWhatsAppConsent()
   }

   componentDidMount() {
      const username = this.getUserProfileStore().getUsername()
      const phoneNumber = this.getUserProfileStore().getMobileNumber()
      if (this.shouldShowLoginModal()) {
         const { handleLoginModal } = this.props
         this.showLoginModal = false
         handleLoginModal(false)
      }
      if (username) {
         this.username = username
      }
      if (phoneNumber) {
         this.phoneNumber = phoneNumber
      }
   }

   getWhatsAppConsent = () => {
      const { showWhatsAppConsent } = this.props
      return getWhatsAppConsent(showWhatsAppConsent)
   }

   shouldShowLoginModal = () => {
      const { validationType } = this.props
      const username = this.getUserProfileStore().getUsername()
      const phoneNumber = this.getUserProfileStore().getMobileNumber()

      if (validationType === validationTypes.defaultValidation) {
         return username && phoneNumber
      } else if (validationType === validationTypes.dynamicDefaultWebinar) {
         return username && phoneNumber
      }
   }

   getInjectedProps = (): InjectedProps => this.props as InjectedProps
   getThemeStore = () => this.getInjectedProps().themeStore
   getUserProfileStore = () => this.getInjectedProps().userDetailsStore
   getActiveWebinarsStore = () => this.getInjectedProps().activeWebinarsStore
   getUtmSource = () => getQueryStringValue(this.props.location, UTM_SOURCE)

   onBlurUsername = (): void => {
      this.usernameRef.current.onBlur()
   }

   onBlurPhoneNumber = (): void => {
      this.phoneNumberRef.current.onBlur()
   }

   handleKeyPress = (event): void => {
      if (event.which === 13) {
         this.validate()
      }
   }

   storeUserDetailsLocally = (): void => {
      setUserName(this.username as string)
      setMobileNumber(this.phoneNumber as string)
      setWhatsAppConsent(this.whatsAppConsent.toString())
   }

   onSuccessEntry = (): void => {
      setIsSyncedWithBackend(SYNCED_WITH_BACKEND)
   }

   onFailureEntry = (error): void => {
      setIsSyncedWithBackend(NOT_SYNCED_WITH_BACKEND)
   }

   isReadyToLogin = (): boolean =>
      this.phoneNumberRef.current.inputRef.current.isError() ||
      this.usernameRef.current.inputRef.current.isError()

   isEligibleToGoToDynamicWebinar = (): boolean =>
      this.phoneNumberRef.current.inputRef.current.isError() ||
      this.usernameRef.current.inputRef.current.isError()

   validate = () => {
      const { validationType } = this.props
      if (validationType === validationTypes.defaultValidation) {
         this.doDefaultValidations()
      } else if (validationType === validationTypes.dynamicDefaultWebinar) {
         this.doDynamicWebinarsValidations()
      }
   }

   doDynamicWebinarsValidations = () => {
      this.validatePhoneAndUsernameFields()

      if (!this.isEligibleToGoToDynamicWebinar()) {
         const requestObject = {
            name: this.username,
            phone_number: this.phoneNumber,
            utm_source: this.getUtmSource() ?? '',
            whatsapp_consent: this.whatsAppConsent
         }
         this.submitUserDetails(requestObject, this.onSuccessEntry)
      }
   }

   validatePhoneAndUsernameFields = () => {
      this.onBlurPhoneNumber()
      this.onBlurUsername()
   }

   doDefaultValidations = (): void => {
      this.validatePhoneAndUsernameFields()

      if (!this.isReadyToLogin()) {
         const { remindMeWebinars } = this.getActiveWebinarsStore()
         const requestObject = {
            name: this.username,
            phone_number: this.phoneNumber,
            webinars_to_remind: remindMeWebinars,
            utm_source: this.getUtmSource() ?? '',
            whatsapp_consent: this.whatsAppConsent
         }
         this.getActiveWebinarsStore().setRemindMeWebinarsLocally()
         this.submitUserDetails(requestObject, this.onSuccessEntry)
      }
   }

   submitUserDetails = (requestObject, onSuccess) => {
      const { onSubmit } = this.props
      const { submitUserDetails } = this.getUserProfileStore()
      submitUserDetails(requestObject, onSuccess, this.onFailureEntry)
      this.storeUserDetailsLocally()
      if (onSubmit) {
         onSubmit()
      }
      const { handleLoginModal } = this.props
      handleLoginModal(false)
      this.showLoginModal = false
      if (window) {
         window.scrollTo(0, 0)
      }
   }
   onChangeUsername = (event): void => {
      this.username = event.target.value
   }
   onChangePhoneNumber = (event): void => {
      this.phoneNumber = event.target.value.trim()
   }

   validateUsernameField = (): ErrorObject => validateEmpty(this.username)
   validatePhoneNumberField = (): ErrorObject =>
      validateMiniumSixDigitsPhoneNumber(this.phoneNumber)

   navigateToHomeScreen = () => {
      const { history } = this.props
      goToHomePage(history, true)
   }

   closeModel = () => {
      this.navigateToHomeScreen()
   }

   onChangeWhatsAppConsent = event => {
      if (!this.whatsAppConsent) {
         this.whatsAppConsent = true
      } else {
         this.whatsAppConsent = false
      }
   }

   renderWhatsAppConcent = () => {
      const { t } = this.props
      return (
         <WhatsAppConsentWrapper>
            <RemindMeText>{t('Consent')}</RemindMeText>
            <BaseCheckBox
               onChange={this.onChangeWhatsAppConsent}
               checked={this.whatsAppConsent}
               label={'I want to receive updates directly on WhatsApp'}
               value={'checked'}
               checkBoxTextCss={checkBoxTextCss}
            />
         </WhatsAppConsentWrapper>
      )
   }

   render() {
      const {
         t,
         hideBackButton,
         submitButtonName,
         validationType,
         headingText,
         showWhatsAppConsent
      } = this.props

      return (
         <LoginFormWrapper>
            <RegistrationModel
               isOpen={this.showLoginModal}
               hideCloseIcon
               theme={this.getThemeStore().selectedTheme}
            >
               <DesktopLayout
                  {...getIconDimensions()}
                  hideBackButton={hideBackButton}
                  backToList={this.closeModel}
                  changeTheme={this.getThemeStore().setTheme}
                  theme={this.getThemeStore().selectedTheme}
               ></DesktopLayout>
               <LoginModalWrapper>
                  <WelcomeText>{t('welcome')}</WelcomeText>
                  <LoginHeader>
                     <LoginText>{headingText}</LoginText>
                  </LoginHeader>
                  <LoginModalBody>
                     <FieldText>{t('FULL NAME')}</FieldText>
                     <UserTextInputWrapper>
                        <UserTextInput
                           data-testid={`username`}
                           ref={this.usernameRef}
                           value={this.username}
                           onChange={this.onChangeUsername}
                           onBlur={this.onBlurUsername}
                           validate={this.validateUsernameField}
                           placeholder={`${t('Enter full name')}`}
                        />
                     </UserTextInputWrapper>
                     <FieldText>{t('PHONE NUMBER')}</FieldText>
                     <UserTextInputWrapper>
                        <UserTextInput
                           data-testid={`phoneNumberInput`}
                           ref={this.phoneNumberRef}
                           value={this.phoneNumber}
                           onBlur={this.onBlurPhoneNumber}
                           onChange={this.onChangePhoneNumber}
                           onKeyPress={this.handleKeyPress}
                           validate={this.validatePhoneNumberField}
                           placeholder={`${t(
                              'common:webinar.mobileNumberWithCountryCode'
                           )}`}
                        />
                     </UserTextInputWrapper>
                     {validationType ===
                        validationTypes.dynamicDefaultWebinar &&
                     showWhatsAppConsent
                        ? this.renderWhatsAppConcent()
                        : null}
                  </LoginModalBody>
                  <ButtonWrapper>
                     <JoinWebinarButton
                        id='JoinWebinarButton'
                        onClick={this.validate}
                     >
                        {submitButtonName}
                     </JoinWebinarButton>
                  </ButtonWrapper>
               </LoginModalWrapper>
            </RegistrationModel>
         </LoginFormWrapper>
      )
   }
}

export default withRouter(withTheme(withTranslation()(LoginForm)))
