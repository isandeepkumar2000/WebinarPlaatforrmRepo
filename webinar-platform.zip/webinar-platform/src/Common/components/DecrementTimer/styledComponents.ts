import styled from 'styled-components'

import { Typo26BlackHKGrotesk } from '../../styleGuide/Typos'

export const DecrementTimerContainer = styled(Typo26BlackHKGrotesk)`
   font-weight: bold;
`
