import React from 'react'

import LoadingView from '../LoadingWrapperWithFailure/LoadingView'

import { themeStore } from '../../stores'

export const SuspenseFallBackLoader = (): JSX.Element => {
   const { backgroundColor } = themeStore
   return <LoadingView backgroundColor={backgroundColor} />
}
