import styled from 'styled-components'

import { mobile } from '../../utils/MixinUtils'
import Colors from '../../themes/Colors'

import ImageWithPlaceHolder from '../Image'

import { WhatsAppButtonProps } from './types'

export const WhatsAppFloat = styled(ImageWithPlaceHolder)`
   max-width: 55px;
   height: auto;
   background-color: transparent;
`

export const WhatsAppChatWrapper = styled('a')<WhatsAppButtonProps>`
   position: fixed;
   height: 60px;
   bottom: ${props => props.bottomPosition};
   right: 20px;
   color: ${Colors.white};
   border-radius: 50px;
   text-align: center;
   font-size: 30px;
   z-index: 1035;
   display: flex;
   align-items: center;
   ${mobile} {
      bottom: ${props => props.mobileBottomPosition};
      right: 15px;
   }
`
