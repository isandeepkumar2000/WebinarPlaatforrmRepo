import * as React from 'react'

import { WhatsAppChatWrapper, WhatsAppFloat } from './styledComponents'
import { WhatsAppButtonProps } from './types'

const WhatsAppChatFloatButton = (props: WhatsAppButtonProps) => {
   const { mobileBottomPosition, bottomPosition, phoneNumber, message } = props

   return (
      <WhatsAppChatWrapper
         href={`https://api.whatsapp.com/send?phone=${phoneNumber}&text=${message}`}
         target='_blank'
         mobileBottomPosition={mobileBottomPosition}
         bottomPosition={bottomPosition}
      >
         <WhatsAppFloat src='https://ibhubs-media-files.s3-ap-southeast-1.amazonaws.com/WhatsAppLogo.svg' />
      </WhatsAppChatWrapper>
   )
}

WhatsAppChatFloatButton.defaultProps = {
   mobileBottomPosition: '15px',
   bottomPosition: '25px'
}

export default WhatsAppChatFloatButton
