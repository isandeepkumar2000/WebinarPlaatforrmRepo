import React, { Component } from 'react'
import { withTranslation, WithTranslation, Trans } from 'react-i18next' //eslint-disable-line

import { isMobile } from '../../utils/ResponsiveUtils'
import AlertWarningIcon from '../../icons/AlertWarningIcon'
import { captureSentryException } from '../../utils/SentryUtils'
import { checkIsChromeBrowser } from '../../utils/ReactDeviceDetectUtils'
import { showReportDialogErrorTypes } from '../../constants/SentryConstants'

import {
   Container,
   WarningInfoText,
   WarningInfoClickableText
} from './styledComponents'
import './styles.scss'

class AlertWarningBanner extends Component<WithTranslation> {
   getIconDimensions = () => {
      if (isMobile()) {
         return { height: 48, width: 48 }
      }
      return { height: 85, width: 85 }
   }

   showSentryUserFeedbackForm = (): void => {
      const { mediaSrcNotSupported } = showReportDialogErrorTypes
      captureSentryException(new Error(mediaSrcNotSupported))
   }

   renderContactSupportText = (): React.ReactNode => {
      const { t } = this.props
      return (
         <WarningInfoClickableText onClick={this.showSentryUserFeedbackForm}>
            {t('video.contactSupport')}
         </WarningInfoClickableText>
      )
   }

   renderWarningInfoChromeText = (): React.ReactNode => {
      const { t } = this.props
      const contactSupportText = this.renderContactSupportText()
      return (
         <Trans
            i18nKey={'video.videoNotSupportedChromeText'}
            ns={'common'}
            t={t}
         >
            {[
               `Your browser doesn't support playing this video. Open in the latest chrome browser. If the issue still persists `,
               contactSupportText
            ]}
         </Trans>
      )
   }

   render(): React.ReactNode {
      const { t } = this.props
      return (
         <Container>
            <AlertWarningIcon {...this.getIconDimensions()} />
            <WarningInfoText>
               {checkIsChromeBrowser()
                  ? this.renderWarningInfoChromeText()
                  : t('video.videoNotSupportedText')}
            </WarningInfoText>
         </Container>
      )
   }
}

export default withTranslation()(AlertWarningBanner)
