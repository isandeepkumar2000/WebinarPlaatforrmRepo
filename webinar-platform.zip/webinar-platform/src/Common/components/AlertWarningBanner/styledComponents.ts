import styled from 'styled-components'
import { Typo24PaleGrayTwoHKGroteskMedium } from '../../styleGuide/Typos'
import Colors from '../../themes/Colors'
import { mobile, tablet } from '../../utils/MixinUtils'

export const Container = styled.div`
   display: flex;
   flex-direction: column;
   justify-content: center;
   align-items: center;
   width: 100%;
   background-color: ${Colors.black46};
   height: 442px;
   ${mobile} {
      height: 300px;
   }
`

export const WarningInfoText = styled(Typo24PaleGrayTwoHKGroteskMedium)`
   letter-spacing: normal;
   text-align: center;
   width: 60%;
   margin-top: 24px;
   ${mobile} {
      font-size: 14px;
      margin-top: 16px;
      width: 90%;
   }
   ${tablet} {
      width: 75%;
   }
`

export const WarningInfoClickableText = styled(
   Typo24PaleGrayTwoHKGroteskMedium
)`
   cursor: pointer;
   text-decoration: underline;
   text-underline-position: under;
`
