import styled from 'styled-components'

export const ButtonContainer = styled.div`
   display: flex;
   justify-content: center;
   margin-top: 15px;
`
export const Container = styled.div``

export const Content = styled.div`
   display: flex;
   justify-content: center;
`
export const FailureText = styled.span`
   font-size: 20px;
   color: ${props => props.theme.tertiaryTextColorTwo};
`
