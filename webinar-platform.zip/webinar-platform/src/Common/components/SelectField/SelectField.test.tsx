import React from 'react'
import { render, fireEvent } from '@testing-library/react'

import SelectField from '.'

jest.mock('react-select', () => ({ options, value }): React.ReactNode => {
   function handleChange(event): void {
      options.find(option => option.value === event.currentTarget.value)
   }
   return (
      <select data-testid='select' value={value} onChange={handleChange}>
         {options.map(({ label, value }) => (
            <option key={value} value={value}>
               {label}
            </option>
         ))}
      </select>
   )
})

describe('SelectField component', () => {
   it('should render the SelectField UI component', () => {
      const { getByText, getByTestId } = render(
         <SelectField
            options={[
               { value: 'chocolate', label: 'Chocolate' },
               { value: 'strawberry', label: 'Strawberry' },
               { value: 'vanilla', label: 'Vanilla' }
            ]}
            data-testid={'select'}
         />
      )

      fireEvent.change(getByTestId('select'), {
         target: { value: 'strawberry' }
      })
      getByText('Strawberry')
   })
})
