import styled from 'styled-components'
import Select from 'react-select'

import Colors from '../../themes/Colors'

export const SelectFieldContainer = styled('div')`
   width: 100%;
`

export const StyledSelectField = styled(Select)`
   outline: none;
   width: 100% !important;
   height: 50px;
   padding: 0px;
   background-color: ${props =>
      props.isDisabled ? Colors.paleGreyFour : Colors.whiteTwo};
   border-radius: 5px;
   border: solid 1px
      ${props => {
         if (props.isDisabled) {
            return Colors.black32
         } else if (props.isValid) {
            return Colors.black32
         }
         return Colors.pinkishOrange
      }};
   align-items: center;
   justify-content: center;
   .Select-container {
      height: 48px;
   }
   .Select__control {
      height: 48px;
      border: solid 1px
         ${props => (props.isValid ? Colors.steel : Colors.pinkishOrange)};
      background-color: ${Colors.whiteTwo};
   }
   .Select__placeholder {
      font-family: 'HKGrotesk';
      color: ${props => props.isDisabled && Colors.darkGreyBlueTwoSix};
   }
   .Select__value-container {
      padding: 0 0 0 15px;
      display: flex;
      align-items: center;
      cursor: text;
   }
   .Select__single-value {
      margin: 0px;
      padding-left: 2px;
      font-family: 'HKGrotesk';
      font-size: 16px;
      line-height: 1.5;
      letter-spacing: 0.15px;
      color: ${props =>
         props.isDisabled ? Colors.darkGreyBlueTwoSix : Colors.darkBlueGrey};
   }
   .Select__indicator-separator {
      opacity: 0;
   }
   .Select__dropdown-indicator {
      padding: 0 10px 0 0;
      cursor: pointer;
      color: ${Colors.steel};
   }
   .Select__menu {
      margin-top: 5px !important;
      padding: 0px;
   }
   .Select__menu-list {
      padding: 0px;
      box-shadow: 2px 6px 10px 0 ${Colors.black12};
      border: solid 1px ${Colors.paleGrey};
      max-height: 150px;
   }
   .Select__option {
      font-family: 'HKGrotesk';
      padding: 13.5px 0px 13.5px 20px;
      cursor: pointer;
      color: ${Colors.dusk};
      background-color: ${Colors.whiteTwo};
   }
   .Select__option--is-focused {
      background-color: ${Colors.paleGrey};
      outline: none;
   }
   .Select__option--is-selected {
      background-color: ${Colors.paleGrey};
      outline: none;
   }
   .Select__control--is-disabled {
      border-width: 0px;
      border-color: ${Colors.black32};
      font-family: 'HKGrotesk';
      font-size: 14px;
      font-weight: 500;
      letter-spacing: 0.2px;
      color: ${Colors.darkGreyBlueTwoSix} !important;
   }
`
