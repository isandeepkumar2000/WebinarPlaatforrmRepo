export const dropdownStylesWithThemes = {
   control: (provided, state) => ({
      ...provided,
      backgroundColor: state.selectProps.selectedTheme.primaryDropdownColor,
      color: state.selectProps.selectedTheme.primaryTextColor,
      border: `1px solid ${state.selectProps.selectedTheme.primaryBorderColor}`,
      transition: 'all 0.25s linear'
   }),
   singleValue: (provided, state) => ({
      ...provided,

      color: state.selectProps.selectedTheme.primaryTextColor
   }),
   option: (provided, state) => ({
      ...provided,
      backgroundColor: state.isSelected
         ? state.isFocused
            ? state.selectProps.selectedTheme.primaryDropdownHoverColor
            : 'transparent'
         : 'transparent',
      color: state.selectProps.selectedTheme.primaryTextColor,
      ':hover': {
         backgroundColor:
            state.selectProps.selectedTheme.primaryDropdownHoverColor
      },
      ':active': {
         ...provided[':active'],
         backgroundColor:
            state.selectProps.selectedTheme.primaryDropdownHoverColor
      }
   }),
   menu: (provided, state) => ({
      ...provided,
      backgroundColor: state.selectProps.selectedTheme.primaryDropdownColor,
      color: state.selectProps.selectedTheme.primaryTextColor,
      border: `1px solid ${state.selectProps.selectedTheme.primaryBorderColor}`
   })
}
