import styled from 'styled-components'

export const VideoWrapper = styled.div`
   width: 100%;
`

export const VideoContainer = styled.div`
   width: 100%;
   margin: 0 auto;
   position: relative;
   .hide {
      display: none;
   }
   :hover .hide {
      display: unset;
   }
`

export const StyledVideo = styled.video``

export const OfflineConsentBannerWrapper = styled.div``
