export type VideoSource = {
   src: string
   type?: string
}

export interface MultiMediaSource {
   src: string
   type?: string
}

type VideoQuality = 'auto' | '1080p' | '720p' | '540p' | '360p' | '270p'

export type VideoQualityType = VideoQuality | string

type VideoSpeed = '0.5x' | '1x' | '1.5x' | '2x'

export type VideoSpeedType = VideoSpeed | string

export type SubtitlesLanguageType = 'ENGLISH' | string

export interface VideoUserPreferences {
   videoQuality: VideoQualityType
   videoSpeed: VideoSpeedType
   subtitlesEnabled: boolean
   subtitlesLanguage: SubtitlesLanguageType
}

export interface LocalPlaybackSettingsType {
   userId: string
   webinarId: string
   watchedDuration: number
   videoQuality: string
   playbackRate: string
   cumulativeOffset: number
}
export interface VideoWaterMarkOptionsType {
   elementId: string
   watermarkText: string
   changeDuration: number
   cssText: string
}
