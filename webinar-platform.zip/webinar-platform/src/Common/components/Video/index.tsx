import { observable, reaction } from 'mobx'
import { Observer, observer } from 'mobx-react'
import React, { Component } from 'react'
import uuid from 'uuid'
import ReactDOM from 'react-dom'
import * as workerTimers from 'worker-timers'
import videoJS from 'video.js'
import 'video.js/dist/video-js.min.css'
import 'videojs-seek-buttons/dist/videojs-seek-buttons.css'

import IbVideoConfigModel from '../../../ContentManagement/stores/models/IbVideoConfig'

import { TWO_MINUTES } from '../../constants/TimeConstants'
import {
   isIPhoneOrIPadDevice,
   isSafariBrowser,
   isSafariIPhoneOrIPad
} from '../../utils/PlatformUtils'
import { removeDynamicallyAddedChildElements } from '../../utils/DeviceUtils'
import { videoDataLayer } from '../../utils/GoogleAnalyticsUtils'
import GoogleAnalyticsModel from '../../stores/models/GoogleAnalyticsModel'
import { trackEvent } from '../../utils/SegmentUtils/SegmentUtils'
import { PLAY_BUTTON_CLICK_EVENT } from '../../constants/SegmentConstants'
import { isDeviceRealDesktop } from '../../utils/ReactDeviceDetectUtils'
import { getTimeDifferenceOfTwoDatesWithCeil } from '../../utils/TimeUtils'
import { getServerDateFormat } from '../../utils/DateUtils'
import {
   VIDEO_BEFORE_UNLOAD_EVENT,
   VIDEO_BUFFERING_TIME,
   VIDEO_INVALID_PLAYBACK_SPEED,
   VIDEO_MEDIA_SRC_NOT_SUPPORTED,
   VIDEO_PLAYER_ERROR,
   VIDEO_RESOLUTION_CHANGE,
   VIDEO_USER_WENT_OFFLINE
} from '../../constants/LogEntriesConstants'
import {
   sendLogEntriesObjectData,
   getBaseLogEntriesObject
} from '../../utils/LogEntriesUtils'
import { isUserOnline } from '../../utils/NetworkConnectionUtils'
import { getUserUUID } from '../../utils/LocalStorageUtils'
import Config from '../../constants/EnvironmentConstants'

import VJSOfflineBanner from './CustomComponents/OfflineConsentBanner/OfflineConsentBanner'
import VJSVideoOverlay from './CustomComponents/VideoOverlay/VideoOverlay'
import { VideoSource, VideoSpeedType, VideoUserPreferences } from './types'
import videoConfig from './config'
import VJSLoader from './CustomComponents/Loader/Loader'
import {
   getDynamicWatermarkConfig,
   getMultimediaSources,
   getVideoQuality,
   setUserPlaybackDetailsData
} from './utils'
import {
   OfflineConsentBannerWrapper,
   StyledVideo,
   VideoContainer,
   VideoWrapper
} from './styledComponents'
import LiveDisplay from './CustomComponents/LiveDisplay'
import { addDynamicWatermark } from './addWatermark'
import './video-overridden.scss'

import {
   controlBarChildNames,
   playerChildNames,
   playerClassNames,
   playerCustomComponentClassNames,
   playerCustomComponentNames,
   PLAYER_BASE_COMPONENT,
   subtitlesSupportedLanguages,
   videoErrorCodes,
   videoPreload,
   videoQuality,
   videoSpeed,
   videoTypes,
   VIDEO_BACKWARD_TIME_IN_SEC,
   VIDEO_FORWARD_TIME_IN_SEC,
   bandwidthConstants,
   MAX_VIDEO_BUFFERING_TIME_IN_SECONDS,
   beforeUnloadEventTypes,
   videoPlayBackRates
} from './constants'

require('videojs-contrib-quality-levels')
require('@ib/videojs-http-source-selector')
require('videojs-landscape-fullscreen')
require('videojs-seek-buttons')
require('videojs-hotkeys')

declare global {
   interface Window {
      bitmovin: any
   }
}

interface VideoProps {
   sources: VideoSource[]
   width: number
   height: number
   id: string
   userId: string
   videoMotomoTitle: string
   videoClassName: string
   videoContainerClassName: string
   fallbackURLs: string[]
   poster: string
   analyticsModel: GoogleAnalyticsModel
   isLive: boolean
   ref: any
   onLoadedMetadata: Function
   analyticsObject?: any
   videoDuration: number
   defaultVideoStartPosition: number | null
   ibVideoConfig: IbVideoConfigModel
   isOfflineExperienceSupported: boolean
   onClickOfflineRetry: Function
   webinarId: string
   pollTimeInSec: number
   webinarTitle: string
   webinarLanguage: string
   shouldPostAttendeeDetails?: Function
   setMediaNotSupported: () => void
   enableVideoWatermark: boolean
}

@observer
class Video extends Component<VideoProps> {
   videoPlayer!: videoJS.Player
   @observable videoSources: VideoSource[]
   @observable orderedFallbackURLs!: string[]
   @observable currentURL!: string
   @observable videoAttempts: number
   @observable sourceIndex: number
   @observable isPlaying: boolean
   isErrorHandled: boolean
   previousDuration: number
   userPreferences: VideoUserPreferences
   timerId!: any
   intervalUniqueId!: number
   timer: any
   @observable isEnded: boolean
   @observable isFirstPlay: boolean
   @observable isLiveCompleted: boolean
   @observable currentLiveVideoTime: number
   @observable autoStartVideo!: boolean
   @observable isOverlayChanged: boolean
   @observable availableQualityLevelHeights: Array<any>
   @observable shouldShowOfflineConsentBanner: boolean
   @observable isFullscreen: boolean
   @observable bufferingTime: number
   userSelectedQuality: string
   currentVideoQuality!: number
   isVideoBuffering: boolean
   videoBufferStartDate: any
   videoBufferEndDate: any
   isVideoPlayedAfterBuffering: boolean
   videoCurrentTimeAtBufferStart!: number
   videoCurrentTimeAtBufferEnd!: number
   bandwidthCountObject: any
   qualityLevels: any
   bufferingTimer!: any
   isUserAlreadyOffline: boolean
   lastPollTimeInSec: number
   currentVideoPosition: number
   currentPlayBackRate: string
   isMainSegmentError: boolean
   isAudioSegmentError: boolean
   isFailedToFetchSourceUrl: boolean

   static defaultProps = {
      width: 640,
      height: 360,
      id: 'video-player',
      testId: 'test-video-player',
      videoClassName: '',
      videoContainerClassName: '',
      videoMotomoTitle: '',
      autoStartVideo: false,
      isLive: false,
      isOfflineExperienceSupported: true,
      pollTimeInSec: 60,
      setMediaNotSupported: () => {}
   }

   constructor(props: VideoProps) {
      super(props)
      this.videoSources = props.sources
      this.orderedFallbackURLs = []
      this.currentURL = props.sources[0].src
      this.videoAttempts = 0
      this.sourceIndex = 0
      this.previousDuration = 0
      this.isErrorHandled = false
      this.isPlaying = false
      this.userPreferences = {
         videoQuality: videoQuality.auto,
         videoSpeed: videoSpeed.oneX,
         subtitlesEnabled: false,
         subtitlesLanguage: subtitlesSupportedLanguages.en
      }
      this.isPlaying = false
      this.isEnded = false
      this.isFirstPlay = true
      this.isLiveCompleted = false
      this.currentLiveVideoTime = 0
      this.isOverlayChanged = false
      this.isVideoBuffering = false
      this.userSelectedQuality = this.getDefaultVideoResolution()
      this.availableQualityLevelHeights = []
      this.shouldShowOfflineConsentBanner = false
      this.isFullscreen = false
      this.bufferingTime = 0
      this.isUserAlreadyOffline = false
      this.lastPollTimeInSec = 0
      this.currentVideoPosition = 0
      this.currentPlayBackRate = videoSpeed.oneX
      this.isVideoPlayedAfterBuffering = true
      this.isMainSegmentError = false
      this.isAudioSegmentError = false
      this.bandwidthCountObject = {
         low: 0,
         medium: 0,
         high: 0,
         very_high: 0
      }
      this.isFailedToFetchSourceUrl = false
   }

   componentDidMount() {
      this.setupVideoPlayer()
      this.orderValues()
      this.removeQualityChangeUIForAppleDevices()
      this.addEventListeners()
   }

   addEventListeners = () => {
      const { add } = beforeUnloadEventTypes
      try {
         window.addEventListener('beforeunload', () =>
            this.savePlaybackDetailsInLocalStorage()
         )
      } catch (e) {
         this.sendBeforeUnloadEventErrorLog(add, e)
      }
   }

   removeEventListeners = () => {
      const { remove } = beforeUnloadEventTypes
      try {
         window.removeEventListener('beforeunload', () =>
            this.savePlaybackDetailsInLocalStorage()
         )
      } catch (e) {
         this.sendBeforeUnloadEventErrorLog(remove, e)
      }
   }

   initializeBitMovIn = () => {
      const bitMovInLicenseKey = Config.BIT_MOV_IN_LICENSE_KEY
      if (bitMovInLicenseKey) {
         const {
            webinarId,
            webinarTitle,
            videoDuration,
            isLive,
            webinarLanguage
         } = this.props
         const analyticsConfig = {
            key: bitMovInLicenseKey,
            videoId: webinarId,
            title: webinarTitle,
            userId: getUserUUID(),
            videoDuration: videoDuration,
            isLive: isLive,
            customData1: webinarLanguage
         }
         try {
            new window.bitmovin.analytics.adapters.VideojsAdapter(
               analyticsConfig,
               this.videoPlayer
            )
         } catch (e) {
            // do nothing
         }
      }
   }

   sendBeforeUnloadEventErrorLog = (type: string, error: any) => {
      const logEntriesObjectData = {
         event_name: VIDEO_BEFORE_UNLOAD_EVENT,
         type: type,
         error: error
      }
      const finalLogEntriesObjectData = {
         ...logEntriesObjectData,
         ...getBaseLogEntriesObject()
      }
      sendLogEntriesObjectData(finalLogEntriesObjectData)
   }

   componentWillUnmount() {
      const { analyticsObject, analyticsModel } = this.props
      const { onVideoExitEvent } = analyticsModel
      this.qualityLevelsAddedReaction()
      this.savePlaybackDetailsInLocalStorage()
      this.removeEventListeners()
      if (analyticsObject) {
         const dataLayerAnalyticsObject = {
            event: 'videoUnmountEvent',
            ...analyticsObject
         }
         videoDataLayer(dataLayerAnalyticsObject)
      }
      onVideoExitEvent(this.currentVideoPosition)
      this.clearBufferingTimer()
      this.clearIntervalAndResetAllTimers()
      if (this.videoPlayer) {
         this.videoPlayer.dispose()
      }
   }

   clearBufferingTimer = (): void => {
      this.bufferingTime = 0
      if (this.bufferingTimer) {
         const bufferingTimerValue = this.bufferingTimer
         workerTimers.clearInterval(bufferingTimerValue)
         this.bufferingTimer = undefined
      }
   }

   savePlaybackDetailsInLocalStorage = () => {
      const { webinarId, analyticsModel } = this.props
      const { cumulativeOffset, resetCumulativeOffset } = analyticsModel

      const userId = getUserUUID()
      const playbackSettings = {
         userId: userId,
         webinarId: webinarId,
         watchedDuration: this.currentVideoPosition,
         videoQuality: this.userSelectedQuality,
         playbackRate: this.currentPlayBackRate,
         cumulativeOffset: cumulativeOffset
      }
      if (this.currentVideoPosition) {
         setUserPlaybackDetailsData(playbackSettings)
         resetCumulativeOffset()
      }
   }

   qualityLevelsAddedReaction = reaction(
      () => this.availableQualityLevelHeights.length,
      length => {
         if (length === 1) {
            this.initializeSourceSelector()
         }
      }
   )

   addQualityLevels = (quality: number): void => {
      this.availableQualityLevelHeights.push(quality.toString())
   }

   setupVideoPlayer = () => {
      const options = videoConfig
      const { id, isLive } = this.props

      this.videoPlayer = videoJS(id, options, () => {
         this.registerEvents()
      })
      this.addVideoLoader()
      this.addClassName(playerClassNames.waiting)
      this.initializePlugins()

      //@eslint-disable-next-line
      const thisReference = this
      //@ts-ignore
      const qualityLevels = this.videoPlayer.qualityLevels()
      this.qualityLevels = qualityLevels
      qualityLevels.on('addqualitylevel', function(event) {
         const qualityLevel = event.qualityLevel
         if (qualityLevel.height === 1080 || qualityLevel.height === 240) {
            qualityLevel.enabled = false
            qualityLevels.removeQualityLevel(qualityLevel)
         } else {
            thisReference.addQualityLevels(qualityLevel.height)
         }
      })

      this.customizeControlBar()
      if (isLive) this.doLiveSpecificUIChanges()
   }

   getActualVideoDuration = () => {
      const { videoDuration } = this.props
      return videoDuration
   }

   getVideoPlayBackRate = () => this.videoPlayer.playbackRate()

   getFormattedVideoPlaybackRate = () => {
      const playbackRate = this.getVideoPlayBackRate()
      return `${playbackRate.toString()}x`
   }

   doLiveSpecificUIChanges = () => {
      const { controlBar } = playerChildNames
      const {
         timeDivider,
         durationDisplay,
         playBackRate,
         liveDisplay
      } = controlBarChildNames

      const controlBarComponent = this.videoPlayer.getChild(controlBar)
      this.addLiveDisplay()
      if (controlBarComponent) {
         const timeDividerComponent = controlBarComponent.getChild(timeDivider)
         const durationDisplayComponent = controlBarComponent.getChild(
            durationDisplay
         )
         const playBackRateComponent = controlBarComponent.getChild(
            playBackRate
         )
         const liveDisplayComponent = controlBarComponent.getChild(liveDisplay)

         if (liveDisplayComponent) {
            liveDisplayComponent.addClass('display-vjs-live-display')
         }

         if (timeDividerComponent) {
            timeDividerComponent.addClass('displayNone')
         }
         if (durationDisplayComponent) {
            durationDisplayComponent.addClass('displayNone')
            durationDisplayComponent.addClass('widthZero')
         }
         if (playBackRateComponent) {
            playBackRateComponent.addClass('displayNone')
         }
      }
   }

   removeLiveSpecificUIChanges = () => {
      const { controlBar } = playerChildNames
      const {
         timeDivider,
         durationDisplay,
         playBackRate,
         liveDisplay
      } = controlBarChildNames

      if (!this.isLiveCompleted) {
         //@ts-ignore
         this.videoPlayer.seekButtons({
            forward: VIDEO_FORWARD_TIME_IN_SEC,
            back: VIDEO_BACKWARD_TIME_IN_SEC
         })
         const controlBarComponent = this.videoPlayer.getChild(controlBar)
         if (controlBarComponent) {
            const timeDividerComponent = controlBarComponent.getChild(
               timeDivider
            )
            const durationDisplayComponent = controlBarComponent.getChild(
               durationDisplay
            )
            const playBackRateComponent = controlBarComponent.getChild(
               playBackRate
            )
            const liveDisplayComponent = controlBarComponent.getChild(
               liveDisplay
            )

            if (timeDividerComponent) {
               timeDividerComponent.removeClass('displayNone')
            }
            if (durationDisplayComponent) {
               durationDisplayComponent.removeClass('displayNone')
            }
            if (playBackRateComponent) {
               playBackRateComponent.removeClass('displayNone')
            }
            if (liveDisplayComponent) {
               liveDisplayComponent.removeClass('display-vjs-live-display')
            }
         }
         this.isLiveCompleted = true
      }
   }

   getActualVideoDurationInSec = (): number =>
      Math.floor(this.getActualVideoDuration())

   changeOverlay = reaction(
      () => this.currentLiveVideoTime,
      currentTime => {
         const { isLive } = this.props
         const { overlay } = playerCustomComponentNames
         this.videoPlayer?.duration(currentTime)
         const overlayComponent = this.videoPlayer?.getChild(overlay)
         const videoCurrentRunningTime = this.currentVideoPosition
         if (this.autoStartVideo && videoCurrentRunningTime < 5) {
            this.playVideo()
            this.setAutoStartVideo(false)
         }
         if (this.currentLiveVideoTime >= this.getActualVideoDuration()) {
            if (videoCurrentRunningTime >= this.getActualVideoDurationInSec()) {
               this.setVideoToDefaultStartingPosition()
            } else {
               this.videoPlayer?.currentTime(videoCurrentRunningTime)
            }
            this.videoPlayer?.duration(this.getActualVideoDuration())
            workerTimers.clearInterval(this.timer)
            if (overlayComponent)
               this.videoPlayer?.removeChild(overlayComponent)
            this.videoPlayer?.addChild(overlay, {
               showForwardIcon: true,
               isLive: false
            })
            this.removeLiveSpecificUIChanges()
         } else if (
            !this.isFirstPlay &&
            overlayComponent &&
            !this.isOverlayChanged
         ) {
            if (currentTime - this.currentVideoPosition > 2) {
               this.isOverlayChanged = true
               this.videoPlayer?.removeChild(overlayComponent)
               this.videoPlayer?.addChild(overlay, {
                  showForwardIcon: true,
                  isLive: isLive
               })
            }
         } else if (
            !this.isFirstPlay &&
            overlayComponent &&
            currentTime - this.currentVideoPosition < 2 &&
            this.isOverlayChanged
         ) {
            this.isOverlayChanged = false
            this.videoPlayer?.removeChild(overlayComponent)
            this.videoPlayer?.addChild(overlay, {
               showForwardIcon: false,
               isLive: isLive
            })
         }
      }
   )

   setAutoStartVideo = (shouldStart: boolean): void => {
      this.autoStartVideo = shouldStart
   }

   playVideo = (): void => {
      try {
         if (!this.isPlaying && this.videoPlayer) {
            const promise = this.videoPlayer.play()
            if (promise !== undefined) {
               promise.then(_ => {}).catch(error => {}) //written to avoid DOM Exception error in console
            }
         }
      } catch (e) {
         videoJS.log(e)
      }
   }

   pauseVideo = (): void => {
      if (this.videoPlayer) {
         this.videoPlayer.pause()
      }
   }

   onClickLiveDisplay = () => {
      this.setVideoPlayerCurrentTime(this.currentLiveVideoTime)
   }

   addLiveDisplay = () => {
      const liveDisplayElement = document.getElementsByClassName(
         'vjs-live-display'
      )
      ReactDOM.render(
         <LiveDisplay onClickLiveDisplay={this.onClickLiveDisplay} />,
         liveDisplayElement[0]
      )
   }

   setVideoPlayerCurrentTime = (time: number) => {
      this.videoPlayer.currentTime(time)
   }

   setVideoToDefaultStartingPosition = () => {
      const { defaultVideoStartPosition } = this.props
      if (defaultVideoStartPosition) {
         this.videoPlayer?.currentTime(defaultVideoStartPosition)
      } else {
         this.videoPlayer?.currentTime(0)
      }
   }

   changeCurrentTimeAndPlay = (currentDuration: number) => {
      this.changeCurrentTime(currentDuration)
      this.playVideo()
   }

   changeCurrentTime(currentDuration: number) {
      const { isLive, defaultVideoStartPosition } = this.props
      if (isLive && !this.timer && currentDuration === 0) {
         this.startTimer(currentDuration)
      }
      if (currentDuration > 0) {
         if (isLive) this.startTimer(currentDuration)

         if (this.getActualVideoDuration() < currentDuration) {
            this.setVideoToDefaultStartingPosition()
         } else {
            if (isLive && !this.isLiveCompleted) {
               if (defaultVideoStartPosition) {
                  this.setVideoPlayerCurrentTime(defaultVideoStartPosition)
               } else {
                  this.setVideoPlayerCurrentTime(this.currentLiveVideoTime)
               }
            } else if (!isLive) {
               if (defaultVideoStartPosition) {
                  this.setVideoPlayerCurrentTime(defaultVideoStartPosition)
               }
            }
         }
      }
      //NOTE: Handled differently for Webinar compared to Kossip
   }

   startTimer = (currentDuration): void => {
      if (!this.timer) {
         this.currentLiveVideoTime = Math.floor(currentDuration)
         this.timer = workerTimers.setInterval(
            () => (this.currentLiveVideoTime = this.currentLiveVideoTime + 1),
            1000
         )
      }
   }

   orderValues = () => {
      const { fallbackURLs } = this.props
      const index = this.getCurrentURLIndex()
      if (index > 0) {
         this.orderedFallbackURLs = fallbackURLs
            .slice(index, fallbackURLs.length)
            .concat(fallbackURLs.slice(0, index))
      } else {
         this.orderedFallbackURLs = fallbackURLs
      }
   }

   getCurrentURLIndex = (): number => {
      const { fallbackURLs } = this.props
      let currentIndex = 0
      if (fallbackURLs)
         fallbackURLs.forEach((url, index) => {
            if (this.currentURL.includes(url)) {
               currentIndex = index
            }
         })
      return currentIndex
   }

   customizeControlBar = (): void => {
      const { customControlSpacer } = playerCustomComponentClassNames
      const spacer = document.createElement('div')
      const controlBar = document.getElementsByClassName(
         playerClassNames.controlBar
      )[0]
      const playbackRateE1 = document.getElementsByClassName(
         playerClassNames.playBackRate
      )[0]
      spacer.className = customControlSpacer
      controlBar.insertBefore(spacer, playbackRateE1)
   }

   setVideoPlaybackRate = (speed: VideoSpeedType): void => {
      switch (speed) {
         case videoSpeed.pointSevenFiveX:
            this.videoPlayer.playbackRate(0.75)
            break
         case videoSpeed.oneX:
            this.videoPlayer.playbackRate(1)
            break
         case videoSpeed.onePointTwoFiveX:
            this.videoPlayer.playbackRate(1.25)
            break
         case videoSpeed.onePointFiveX:
            this.videoPlayer.playbackRate(1.5)
            break
         case videoSpeed.twoX:
            this.videoPlayer.playbackRate(2)
            break
         default:
            this.videoPlayer.playbackRate(1)
      }
   }

   getDefaultVideoResolution = () => {
      const { ibVideoConfig } = this.props
      const qualityBasedOnConfig = isDeviceRealDesktop()
         ? ibVideoConfig.defaultDesktopResolution
         : ibVideoConfig.defaultMobileResolution
      return getVideoQuality(getUserUUID(), qualityBasedOnConfig)
   }

   initializeSourceSelector = (): void => {
      // enable quality selection
      //@ts-ignore
      this.videoPlayer.httpSourceSelector({
         // FIXME: below setting is not working
         default: this.getDefaultVideoResolution(),
         onClickItem: this.onClickCallBack
      })
   }

   initializePlugins = (): void => {
      const { isLive } = this.props

      if (!isLive) {
         //@ts-ignore
         this.videoPlayer.seekButtons({
            forward: VIDEO_FORWARD_TIME_IN_SEC,
            back: VIDEO_BACKWARD_TIME_IN_SEC
         })
      }

      // switch to landscape mode in mobile when pressed fullscreen
      if (!isSafariIPhoneOrIPad()) {
         //@ts-ignore
         this.videoPlayer.landscapeFullscreen()
      }
   }

   addVideoLoader = (): void => {
      const { loadingSpinner } = playerChildNames
      const { loader } = playerCustomComponentNames
      const vjsComponent = videoJS.getComponent(PLAYER_BASE_COMPONENT)
      const loadingSpinnerComponent = this.videoPlayer.getChild(loadingSpinner)
      vjsComponent.registerComponent(loader, VJSLoader)
      if (loadingSpinnerComponent) {
         loadingSpinnerComponent.addChild(loader, {})
      }
   }

   onTimeUpdateForEveryXSeconds = () => {
      this.savePlaybackDetailsInLocalStorage()
   }

   onTimeUpdate = () => {
      const { pollTimeInSec } = this.props
      this.updateBandwidthCountObject()
      const currentTimeInSec = this.getCurrentTimeInSec()
      this.currentVideoPosition = currentTimeInSec
      if (currentTimeInSec < this.lastPollTimeInSec) {
         this.lastPollTimeInSec = 0
      }
      const timeDiff = currentTimeInSec - this.lastPollTimeInSec
      if (timeDiff >= pollTimeInSec) {
         if (!this.videoPlayer.scrubbing()) {
            this.onTimeUpdateForEveryXSeconds()
         }
         this.lastPollTimeInSec = currentTimeInSec
      }
   }

   getUserSelectedVideoQualityAfterTimeout = () => {
      const userSelectedQualityPromise = new Promise(resolve =>
         workerTimers.setTimeout(() => {
            resolve(this.userSelectedQuality)
         }, 100)
      )
      return userSelectedQualityPromise
   }

   onQualityLevelChange = async () => {
      const previousQuality = this.currentVideoQuality
      const selectedIndex = this.qualityLevels.selectedIndex
      const selectedQuality = this.qualityLevels[selectedIndex]
      // @ts-ignore
      const latestBandwidth = this.getLatestBandwidth()

      if (selectedQuality && latestBandwidth && !this.isFirstPlay) {
         this.currentVideoQuality = selectedQuality.height

         let userSelectedVideoQuality

         await this.getUserSelectedVideoQualityAfterTimeout().then(
            quality => (userSelectedVideoQuality = quality)
         )

         const logEntriesObjectData = {
            event_name: VIDEO_RESOLUTION_CHANGE,
            previous_resolution: previousQuality,
            current_resolution: this.currentVideoQuality,
            user_selected_resolution: userSelectedVideoQuality,
            current_bandwidth: latestBandwidth
         }

         const finalLogEntriesObjectData = {
            ...logEntriesObjectData,
            ...getBaseLogEntriesObject()
         }

         sendLogEntriesObjectData(finalLogEntriesObjectData)
      }
   }

   onClickCallBack = (userSelectedQuality: string): void => {
      this.userSelectedQuality =
         userSelectedQuality === videoQuality.auto
            ? userSelectedQuality
            : userSelectedQuality.slice(0, -1)
   }

   getLatestBandwidth = () => {
      // @ts-ignore
      const bandwidth = this.videoPlayer.tech()?.vhs?.bandwidth
      return bandwidth
   }

   updateBandwidthCountObject = () => {
      const { LOW, MEDIUM, HIGH } = bandwidthConstants

      const bandwidth = this.getLatestBandwidth()
      switch (true) {
         case bandwidth < LOW:
            this.bandwidthCountObject.low++
            break
         case LOW < bandwidth && bandwidth < MEDIUM:
            this.bandwidthCountObject.medium++
            break
         case MEDIUM < bandwidth && bandwidth < HIGH:
            this.bandwidthCountObject.high++
            break
         case bandwidth > HIGH:
            this.bandwidthCountObject.very_high++
            break
      }
   }

   getLatestTimeStamp = () => getServerDateFormat(new Date())

   getIsUserOnlinePromise = () => {
      const isUserOnlinePromise = new Promise(resolve => {
         let isOnline = false
         isUserOnline(status => {
            isOnline = status
            resolve(isOnline)
         })
      })
      return isUserOnlinePromise
   }

   sendOfflineBannerLogEntries = (isBannerShown: boolean): void => {
      const latestBandwidth = this.getLatestBandwidth()

      const logEntriesObjectData = {
         event_name: VIDEO_USER_WENT_OFFLINE,
         current_bandwidth: latestBandwidth,
         is_banner_shown: isBannerShown
      }

      const finalLogEntriesObjectData = {
         ...logEntriesObjectData,
         ...getBaseLogEntriesObject()
      }

      sendLogEntriesObjectData(finalLogEntriesObjectData)
   }

   onVideoBuffering = async () => {
      let isOnline = false

      if (navigator.onLine) {
         await this.getIsUserOnlinePromise().then(
            status => (isOnline = status as boolean)
         )
      } else {
         isOnline = false
      }

      if (!isOnline) {
         this.setIsUserWentOffline()
      }

      this.bufferingTime++

      if (isOnline && this.isUserAlreadyOffline) {
         this.sendOfflineBannerLogEntries(false)
         this.onClickOfflineRetry()
      }

      if (this.bufferingTime >= MAX_VIDEO_BUFFERING_TIME_IN_SECONDS) {
         if (!isOnline) {
            this.clearBufferingTimer()
            this.pauseVideo()
            this.sendOfflineBannerLogEntries(true)
            this.shouldShowOfflineConsentBanner = true
         } else {
            this.clearBufferingTimer()
         }
      }
   }

   onWaiting = () => {
      const { isOfflineExperienceSupported } = this.props
      this.isVideoBuffering = true
      if (this.isVideoPlayedAfterBuffering)
         this.videoCurrentTimeAtBufferStart = this.currentVideoPosition

      if (isOfflineExperienceSupported && !this.bufferingTimer) {
         if (this.bufferingTime === 0) {
            this.bufferingTimer = workerTimers.setInterval(
               this.onVideoBuffering,
               1000
            )
         }
      }
      this.isVideoPlayedAfterBuffering = false
      this.videoBufferStartDate = new Date()
   }

   onPlaying = (): void => {
      this.isVideoPlayedAfterBuffering = true
      // @ts-ignore
      const latestBandwidth = this.getLatestBandwidth()
      this.clearBufferingTimer()
      this.videoCurrentTimeAtBufferEnd = this.currentVideoPosition

      if (this.isVideoBuffering && latestBandwidth) {
         this.videoBufferEndDate = new Date()
         const bufferingTime = getTimeDifferenceOfTwoDatesWithCeil(
            this.videoBufferEndDate,
            this.videoBufferStartDate
         )

         if (bufferingTime > 1) {
            const timeDifferenceBetweenPlayedSegments = Math.round(
               this.videoCurrentTimeAtBufferEnd -
                  this.videoCurrentTimeAtBufferStart
            )

            const logEntriesObjectData = {
               event_name: VIDEO_BUFFERING_TIME,
               buffering_time: bufferingTime,
               user_selected_resolution: this.userSelectedQuality,
               actual_video_resolution: this.currentVideoQuality,
               is_buffering_ended_normally:
                  timeDifferenceBetweenPlayedSegments > 0 &&
                  timeDifferenceBetweenPlayedSegments <= 1,
               buffering_start_time: this.videoCurrentTimeAtBufferStart,
               current_source_url: this.currentURL,
               current_video_time: this.videoCurrentTimeAtBufferEnd,
               bandwidth_count: this.bandwidthCountObject,
               latest_bandwidth: latestBandwidth,
               latest_timestamp: this.getLatestTimeStamp()
            }

            const finalLogEntriesObjectData = {
               ...logEntriesObjectData,
               ...getBaseLogEntriesObject()
            }

            sendLogEntriesObjectData(finalLogEntriesObjectData)
         }

         this.isVideoBuffering = false
      }
   }

   setIsUserWentOffline = () => {
      this.isUserAlreadyOffline = true
   }

   resetIsUserWentOffline = () => {
      this.isUserAlreadyOffline = false
   }

   onRetryPlaylist = () => {
      this.setIsUserWentOffline()
   }

   mainSegmentError = () => {
      this.isMainSegmentError = true
      this.setIsUserWentOffline()
   }

   mainSegmentProgress = () => {
      this.isMainSegmentError = false
      if (this.isUserAlreadyOffline && !this.isAudioSegmentError)
         this.resetIsUserWentOffline()
   }

   audioSegmentError = () => {
      this.isAudioSegmentError = true
      this.setIsUserWentOffline()
   }

   audioSegmentProgress = () => {
      this.isAudioSegmentError = false
      if (this.isUserAlreadyOffline && !this.isMainSegmentError)
         this.resetIsUserWentOffline()
   }

   registerUnRecommendedEvents = (): void => {
      // @ts-ignore
      this.videoPlayer.vhs.masterPlaylistController_.mainSegmentLoader_.on(
         'error',
         this.mainSegmentError
      )
      // @ts-ignore
      this.videoPlayer.vhs.masterPlaylistController_.mainSegmentLoader_.on(
         'progress',
         this.mainSegmentProgress
      )
      // @ts-ignore
      this.videoPlayer.vhs.masterPlaylistController_.audioSegmentLoader_.on(
         'error',
         this.audioSegmentError
      )

      // @ts-ignore
      this.videoPlayer.vhs.masterPlaylistController_.audioSegmentLoader_.on(
         'progress',
         this.audioSegmentProgress
      )
   }

   registerEvents = () => {
      this.videoPlayer.on('play', this.onPlay)
      this.videoPlayer.on('pause', this.onPause)
      this.videoPlayer.on('ended', this.onEnd)
      this.videoPlayer.on('fullscreenchange', this.onFullScreenChange)
      this.videoPlayer.on('error', this.onError)
      this.videoPlayer.on('loadedmetadata', this.onLoadedMetadata)
      this.videoPlayer.on('ready', this.onReadyVideoPlayer)
      this.videoPlayer.on('ratechange', this.onRateChange)
      this.videoPlayer.on('waiting', this.onWaiting)
      this.videoPlayer.on('playing', this.onPlaying)
      this.videoPlayer.on('timeupdate', this.onTimeUpdate)
      this.qualityLevels.on('change', this.onQualityLevelChange)
   }

   createNewIntervalUniqueId = () => {
      this.intervalUniqueId = uuid.v4()
   }

   trackFirstPlay = () => {
      const { analyticsModel } = this.props
      const { webinarDetails } = analyticsModel
      const { analyticsConfiguration, language, webinarSlug } = webinarDetails

      if (analyticsConfiguration.shouldTrackEvents)
         trackEvent(PLAY_BUTTON_CLICK_EVENT, {
            language,
            serial_number: analyticsConfiguration.serialNumber,
            webinar_category: analyticsConfiguration.webinarCategory,
            webinar_slug: webinarSlug
         })
   }

   onPlay = () => {
      const {
         analyticsModel,
         isLive,
         defaultVideoStartPosition,
         shouldPostAttendeeDetails
      } = this.props
      const { onVideoPlayEvent } = analyticsModel
      if (this.isFirstPlay) {
         this.trackFirstPlay()
         shouldPostAttendeeDetails && shouldPostAttendeeDetails()
      }
      onVideoPlayEvent(this.currentVideoPosition)
      this.clearTimeIntervalAndStartAgain()
      this.setIsPlayingStatus(true)
      this.setIsEndedStatus(false)
      this.isFirstPlay = false
      this.clearBufferingTimer()
   }

   onPause = () => {
      const { analyticsModel } = this.props
      this.setIsPlayingStatus(false)
      const { onVideoPauseEvent } = analyticsModel
      onVideoPauseEvent(this.currentVideoPosition)
      this.clearIntervalAndResetAllTimers()
      this.isVideoBuffering = false
   }

   onEnd = () => {
      const { analyticsModel, isLive } = this.props
      const { onVideoEndEvent } = analyticsModel
      this.setIsPlayingStatus(false)
      this.setIsEndedStatus(true)
      if (isLive) {
         if (this.timer) {
            workerTimers.clearInterval(this.timer)
         }
         this.removeLiveSpecificUIChanges()
      }
      onVideoEndEvent(this.currentVideoPosition)
      this.clearIntervalAndResetAllTimers()
   }

   onRateChange = () => {
      const { analyticsModel, isLive } = this.props
      const {
         onPlayBackRateChangeEvent,
         setOnPlayBackRateChangeValue,
         onVideoProgressEvent
      } = analyticsModel
      const currentRate = this.videoPlayer.playbackRate()
      const isPlaybackRateValid = videoPlayBackRates.includes(currentRate)
      const videoSpeed = `${currentRate}x`

      if (this.isPlaying) {
         onPlayBackRateChangeEvent(this.currentVideoPosition)
         onVideoProgressEvent(this.currentVideoPosition, this.intervalUniqueId)
         this.clearTimeIntervalAndStartAgain()
      } else {
         this.clearIntervalAndResetAllTimers()
      }
      this.currentPlayBackRate = this.getFormattedVideoPlaybackRate()
      setOnPlayBackRateChangeValue(this.getVideoPlayBackRate())

      if (!isPlaybackRateValid) {
         const logEntriesObjectData = {
            event_name: VIDEO_INVALID_PLAYBACK_SPEED,
            video_speed: videoSpeed,
            video_quality: this.userSelectedQuality,
            is_live: isLive,
            current_video_time: this.getCurrentTimeInSec(),
            current_source_url: this.currentURL
         }

         const finalLogEntriesObjectData = {
            ...logEntriesObjectData,
            ...getBaseLogEntriesObject()
         }

         sendLogEntriesObjectData(finalLogEntriesObjectData)
      }
   }

   triggerAnalyticsDataLayer = (): void => {
      const { analyticsObject } = this.props
      if (analyticsObject) {
         const dataLayerAnalyticsObject = {
            event: 'videoMountEvent',
            ...analyticsObject
         }
         videoDataLayer(dataLayerAnalyticsObject)
      }
   }

   startProgressEventTimer = () => {
      this.createNewIntervalUniqueId()
      const { analyticsModel } = this.props
      const { onVideoProgressEvent, setProgressEventDuration } = analyticsModel
      this.timerId = setInterval(() => {
         onVideoProgressEvent(this.currentVideoPosition, this.intervalUniqueId)
         setProgressEventDuration(new Date().getTime())
      }, TWO_MINUTES)
   }

   clearTimeIntervalAndStartAgain = () => {
      const { analyticsModel } = this.props
      const { setVideoStartTime, setProgressEventDuration } = analyticsModel
      this.clearIntervalAndResetAllTimers()
      this.startProgressEventTimer()
      setVideoStartTime(new Date().getTime())
      setProgressEventDuration(new Date().getTime())
   }

   clearIntervalAndResetAllTimers = () => {
      const { analyticsModel } = this.props
      const { setVideoStartTime, setProgressEventDuration } = analyticsModel
      clearInterval(this.timerId)
      setVideoStartTime(NaN)
      setProgressEventDuration(NaN)
   }

   onReadyVideoPlayer = (event): void => {
      const { analyticsModel, enableVideoWatermark, id, userId } = this.props
      const { onVideoEnteredEvent } = analyticsModel
      this.handleHotKeys(event)
      this.triggerAnalyticsDataLayer()
      onVideoEnteredEvent(this.currentVideoPosition)
      this.registerUnRecommendedEvents()
      this.initializeBitMovIn()
      if (enableVideoWatermark)
         addDynamicWatermark(
            this.videoPlayer,
            getDynamicWatermarkConfig(id, userId)
         )
   }

   handleHotKeys = e => {
      //@ts-ignore
      this.videoPlayer.hotkeys({
         volumeStep: 0.1,
         seekStep: 10,
         enableModifiersForNumbers: false,
         enableMute: false,
         enableFullscreen: false,
         enableNumbers: false,
         enableVolumeScroll: false
      })
   }

   onLoadedMetadata = (): void => {
      const { onLoadedMetadata } = this.props
      this.removeClassName(playerClassNames.waiting)
      this.addVideoOverlay()
      onLoadedMetadata()
   }

   removeQualityChangeUIForAppleDevices = (): void => {
      const { controlBar, sourceSelector } = playerClassNames
      if (isSafariBrowser() || isIPhoneOrIPadDevice()) {
         removeDynamicallyAddedChildElements(controlBar, sourceSelector)
      }
   }

   getCurrentTimeInSec = (): number => {
      const currentTime = Math.floor(this.videoPlayer?.currentTime())
      return currentTime
   }

   setErrorHandled = (status: boolean): void => {
      this.isErrorHandled = status
   }

   shouldChangeVideoSrc = (): boolean => {
      const { MEDIA_ERR_SRC_NOT_SUPPORTED, MEDIA_ERR_DECODE } = videoErrorCodes
      const error = this.videoPlayer.error()
      if (error) {
         const { code } = error
         return (
            (code === MEDIA_ERR_SRC_NOT_SUPPORTED ||
               code === MEDIA_ERR_DECODE) &&
            !this.isErrorHandled
         )
      }
      return false
   }

   isChunkFailure = (): boolean => {
      const { MEDIA_ERR_NETWORK } = videoErrorCodes
      const error = this.videoPlayer.error()
      if (error) {
         const { code } = error
         if (code === MEDIA_ERR_NETWORK) {
            this.videoAttempts = this.videoAttempts + 1
         }

         return code === MEDIA_ERR_NETWORK
      }
      return false
   }

   setMediaNotSupported = (): void => {
      const { setMediaNotSupported } = this.props
      setMediaNotSupported()
   }

   sendMediaNotSupportedLogEntry = (previousSourceUrl: string): void => {
      const { sources } = this.props

      const logEntriesObjectData = {
         event_name: VIDEO_MEDIA_SRC_NOT_SUPPORTED,
         current_video_time: this.getCurrentTimeInSec(),
         default_sources: sources,
         current_source_url: this.currentURL,
         previous_source_url: previousSourceUrl,
         is_failed_to_fetch_source_url: this.isFailedToFetchSourceUrl
      }

      const finalLogEntriesObjectData = {
         ...logEntriesObjectData,
         ...getBaseLogEntriesObject()
      }
      sendLogEntriesObjectData(finalLogEntriesObjectData)
   }

   sendErrorLogToLogEntries = (
      error: any,
      previousSourceUrl: string,
      tags: any
   ): void => {
      const { sources } = this.props

      const logEntriesObjectData = {
         event_name: VIDEO_PLAYER_ERROR,
         error_code: error?.code,
         default_sources: sources,
         current_source_url: this.currentURL,
         previous_source_url: previousSourceUrl,
         is_chunk_failure: tags.video_chunk_failure,
         is_media_error: tags.video_not_supported,
         is_decode_failure: tags.video_decode_failure
      }

      const finalLogEntriesObjectData = {
         ...logEntriesObjectData,
         ...getBaseLogEntriesObject()
      }

      sendLogEntriesObjectData(finalLogEntriesObjectData)
   }

   showMediaNotSupportedBanner = async (
      previousSourceUrl: string
   ): Promise<void> => {
      const { MEDIA_ERR_SRC_NOT_SUPPORTED, MEDIA_ERR_DECODE } = videoErrorCodes

      const error = this.videoPlayer.error()
      if (error) {
         const { code } = error

         let isOnline = false

         if (navigator.onLine) {
            await this.getIsUserOnlinePromise().then(
               status => (isOnline = status as boolean)
            )
         } else {
            isOnline = false
         }

         if (
            isOnline &&
            (code === MEDIA_ERR_SRC_NOT_SUPPORTED || code === MEDIA_ERR_DECODE)
         ) {
            await fetch(this.currentURL)
               .then(data => {
                  this.isFailedToFetchSourceUrl = false
               })
               .catch(err => {
                  this.isFailedToFetchSourceUrl = true
               })

            this.sendMediaNotSupportedLogEntry(previousSourceUrl)
            this.setMediaNotSupported()
         }
      }
   }

   onError = () => {
      const {
         MEDIA_ERR_SRC_NOT_SUPPORTED,
         MEDIA_ERR_DECODE,
         MEDIA_ERR_NETWORK
      } = videoErrorCodes

      const previousSourceUrl = this.currentURL
      const error = this.videoPlayer.error()
      const tags = {
         video_chunk_failure: error?.code === MEDIA_ERR_NETWORK,
         video_not_supported: error?.code === MEDIA_ERR_SRC_NOT_SUPPORTED,
         video_decode_failure: error?.code === MEDIA_ERR_DECODE
      }

      if (this.isChunkFailure()) {
         const currentTime = this.currentVideoPosition
         const src = this.currentURL.replace(
            this.orderedFallbackURLs[this.sourceIndex],
            this.orderedFallbackURLs[this.sourceIndex + 1]
         )
         this.currentURL = src
         this.videoAttempts = 0
         const updatedVideoSources = getMultimediaSources([
            {
               multimediaFormat: 'VIDEO',
               multimediaUrl: src
            }
         ])
         this.orderedFallbackURLs = [
            ...this.orderedFallbackURLs.slice(
               1,
               this.orderedFallbackURLs.length
            ),
            ...this.orderedFallbackURLs.slice(0, 1)
         ]
         this.videoSources = updatedVideoSources

         this.videoPlayer.src({
            src: src,
            type: this.videoPlayer.currentType()
         })
         this.videoPlayer.load()
         this.videoPlayer.on('loadedmetadata', () => this.videoPlayer.play())
         this.setVideoPlayerCurrentTime(currentTime)
         this.sendErrorLogToLogEntries(error, previousSourceUrl, tags)
      } else if (this.shouldChangeVideoSrc()) {
         this.sendErrorLogToLogEntries(error, previousSourceUrl, tags)
         this.showMediaNotSupportedBanner(previousSourceUrl)
         const { mp4Type } = videoTypes
         this.videoSources.forEach((source, index) => {
            const { src, type } = source
            if (type === mp4Type) {
               this.sourceIndex = index
               this.currentURL = src
               this.videoPlayer.src({ src, type })
               this.videoPlayer.load()
               this.setVideoPlayerCurrentTime(this.previousDuration)
               this.setErrorHandled(true)
               this.removeSourceSelectors()
            }
         })
      }
   }

   removeSourceSelectors = () => {
      const { controlBar, sourceSelector } = playerClassNames
      const controlBarElements = document.getElementsByClassName(controlBar)
      if (controlBarElements.length > 0) {
         const controlBarElement = controlBarElements[0]
         const sourceSelectors = controlBarElement.getElementsByClassName(
            sourceSelector
         )
         Array.from(sourceSelectors).forEach(element => {
            element.remove()
         })
      }
   }

   onFullScreenChange = (): void => {
      const isVideoInFullScreen = this.videoPlayer.isFullscreen()
      this.isFullscreen = isVideoInFullScreen

      if (!isVideoInFullScreen) {
         document.documentElement.style.overflow = 'scroll'
      }
   }

   addVideoOverlay = (): void => {
      const { isLive } = this.props
      const { overlay } = playerCustomComponentNames
      const vjsComponent = videoJS.getComponent(PLAYER_BASE_COMPONENT)
      vjsComponent.registerComponent(overlay, VJSVideoOverlay)
      this.videoPlayer.addChild(overlay, {
         showForwardIcon: this.isLiveCompleted ? true : !isLive,
         isLive: this.isLiveCompleted ? false : isLive
      })
   }

   setIsPlayingStatus = (status): void => {
      this.isPlaying = status
   }

   setIsEndedStatus = (status): void => {
      this.isEnded = status
   }

   addClassName = (className: string): void => {
      if (this.videoPlayer) {
         this.videoPlayer.addClass(className)
      }
   }

   removeClassName = (className: string): void => {
      if (this.videoPlayer) {
         this.videoPlayer.removeClass(className)
      }
   }

   onClickOfflineRetry = (): void => {
      const { onClickOfflineRetry } = this.props
      this.shouldShowOfflineConsentBanner = false
      this.savePlaybackDetailsInLocalStorage()
      onClickOfflineRetry && onClickOfflineRetry(this.currentVideoPosition)
   }

   addOfflineBannerDynamically = (): void => {
      const { offlineBanner } = playerCustomComponentNames
      const vjsComponent = videoJS.getComponent(PLAYER_BASE_COMPONENT)
      vjsComponent.registerComponent(offlineBanner, VJSOfflineBanner)
      this.videoPlayer.addChild(offlineBanner, {
         onClickOfflineRetry: this.onClickOfflineRetry,
         isVideoInFullScreen: this.isFullscreen
      })
   }

   removeOverlayDynamically = (): void => {
      const { loadingSpinner, bigPlayButton } = playerChildNames

      const { overlay } = playerCustomComponentNames
      const overlayComponent = this.videoPlayer?.getChild(overlay)
      const loadingSpinnerComponent = this.videoPlayer.getChild(loadingSpinner)

      if (overlayComponent) this.videoPlayer.removeChild(overlayComponent)
      if (loadingSpinnerComponent)
         this.videoPlayer.removeChild(loadingSpinnerComponent)
      this.removeClassName(playerClassNames.waiting)
      const bigPlayButtonElement = this.videoPlayer?.getChild(bigPlayButton)
      if (bigPlayButtonElement)
         this.videoPlayer.removeChild(bigPlayButtonElement)
   }

   renderOfflineConsentBanner = () => {
      this.removeOverlayDynamically()
      this.addOfflineBannerDynamically()
   }

   renderSources = (): React.ReactNode => (
      <Observer>
         {() => (
            <>
               {this.videoSources.map((source, index) => (
                  <source
                     src={source.src}
                     type={source.type}
                     key={source.src}
                  />
               ))}
            </>
         )}
      </Observer>
   )

   render(): React.ReactNode {
      const {
         width,
         height,
         id,
         videoClassName,
         videoContainerClassName,
         videoMotomoTitle,
         poster,
         analyticsObject,
         isOfflineExperienceSupported
      } = this.props
      const { video, defaultSkin, bigPlayCentered } = playerClassNames
      const { auto } = videoPreload
      const dataVideoId = (analyticsObject && analyticsObject.videoId) ?? ''
      return (
         <VideoWrapper>
            <VideoContainer
               className={videoContainerClassName}
               data-video-id={dataVideoId}
            >
               <OfflineConsentBannerWrapper>
                  {this.shouldShowOfflineConsentBanner &&
                  isOfflineExperienceSupported
                     ? this.renderOfflineConsentBanner()
                     : null}
               </OfflineConsentBannerWrapper>
               <StyledVideo
                  data-matomo-title={videoMotomoTitle}
                  alt={`${videoMotomoTitle} - video`}
                  className={`${video} ${defaultSkin} ${bigPlayCentered} ${videoClassName}`}
                  controls
                  preload={auto}
                  poster={poster}
                  id={id}
                  width={width}
                  height={height}
                  data-setup='{}'
                  playsInline
                  autoPlay={isIPhoneOrIPadDevice() ? true : false} //NOTE: This is added to fix a critical issue in iOS devices
               >
                  {this.renderSources()}
               </StyledVideo>
            </VideoContainer>
         </VideoWrapper>
      )
   }
}

export default Video
