/**
 * When `responsive` option set as true, some control bar components
 * will be hidden based on the breakpoint. Check the below source file
 * https://github.com/videojs/video.js/blob/master/src/css/components/_adaptive.scss#L1&L20
 */

import { isTabletOrMobile } from '../../utils/ResponsiveUtils'

import { videoPlayBackRates } from './constants'

const shouldEnableLogs = () => process.env.NODE_ENV === 'development'

const getOverlayInactivityTimeout = (): number => {
   return isTabletOrMobile() ? 2000 : 500
}

const config = {
   fluid: true,
   responsive: true,
   playbackRates: videoPlayBackRates,
   controlBar: {
      children: [
         'playToggle',
         'progressControl',
         'volumePanel',
         'currentTimeDisplay',
         'timeDivider',
         'durationDisplay',
         'liveDisplay',
         'playbackRateMenuButton',
         'fullscreenToggle'
      ]
   },
   inactivityTimeout: getOverlayInactivityTimeout(),
   errorDisplay: shouldEnableLogs(),
   html5: {
      vhs: {
         experimentalBufferBasedABR: true,
         useDevicePixelRatio: true,
         maxPlaylistRetries: 20
      }
   }
}

export default config
