import { getUniversalUniqueId } from '../../utils/UuidUtils'
import { isMobile, isTabletOrMobile } from '../../utils/ResponsiveUtils'

import { VideoWaterMarkOptionsType } from './types'

let uniqueId

const getPositionBuffer = (): number => {
   return isMobile() ? 20 : isTabletOrMobile() ? 50 : 100
}

const getUniqueId = (): string => {
   if (uniqueId) {
      return uniqueId
   } else {
      setUniqueId()
      return uniqueId
   }
}

const setUniqueId = (): void => {
   uniqueId = getUniversalUniqueId()
}

const applyCssStyles = (el: HTMLElement, options): void => {
   el.innerHTML = options.watermarkText
   el.style.cssText = options.cssText
}

const setPositionsWithCustomLogic = (element: HTMLElement, player): void => {
   const videoHeight = player.currentHeight()
   const videoWidth = player.currentWidth()
   const positionBuffer = getPositionBuffer()

   function setStartPosx() {
      let startPosX = Math.floor(Math.random() * videoWidth)

      if (
         startPosX > positionBuffer &&
         startPosX < videoWidth - positionBuffer
      ) {
         setStartPosx()
      } else if (
         startPosX > positionBuffer &&
         startPosX > videoWidth - positionBuffer
      ) {
         element.style.right = videoWidth - startPosX + 'px'
      } else {
         element.style.left = startPosX + 'px'
      }
   }
   setStartPosx()

   function setStartPosy() {
      let startPosY = Math.floor(Math.random() * videoHeight)

      element.style.top = startPosY + 'px'
   }
   setStartPosy()
}

const setRandomPosition = (
   player,
   element: HTMLElement,
   options: VideoWaterMarkOptionsType
): void => {
   setPositionsWithCustomLogic(element, player)

   const timeout = setTimeout(function() {
      const dynamicWatermarkElementId = `${options.elementId}-${getUniqueId()}`

      setUniqueId()

      let dynamicWatermarkEl: HTMLElement | null = document.getElementById(
         dynamicWatermarkElementId
      )

      if (dynamicWatermarkEl) {
         dynamicWatermarkEl.id = `${options.elementId}-${getUniqueId()}`
         applyCssStyles(dynamicWatermarkEl, options)
      } else {
         dynamicWatermarkEl = createDynamicWatermarkElement(
            options,
            getUniqueId()
         )
         player.el().appendChild(dynamicWatermarkEl)
      }

      setRandomPosition(player, dynamicWatermarkEl, options)
   }, options.changeDuration)

   player.on('dispose', () => {
      clearTimeout(timeout)
   })
}

const createDynamicWatermarkElement = (
   options: VideoWaterMarkOptionsType,
   uniqueId: string
) => {
   const el: HTMLElement = document.createElement('div')
   el.id = `${options.elementId}-${uniqueId}`

   applyCssStyles(el, options)
   return el
}

export const addDynamicWatermark = (
   player,
   options: VideoWaterMarkOptionsType
) => {
   const el = createDynamicWatermarkElement(options, getUniqueId())

   player.el().appendChild(el)
   setRandomPosition(player, el as HTMLElement, options)
}
