import React, { Component } from 'react'
import { withTranslation, WithTranslation } from 'react-i18next' //eslint-disable-line
import LiveDisplayIcon from '../../../../icons/LiveVideoIcon'

import {
   LiveDisplayWrapper,
   LiveDisplayText,
   LiveDisplayIconWrapper
} from './styledComponents'

interface LiveDisplayProps extends WithTranslation {
   onClickLiveDisplay: Function
}

class LiveDisplay extends Component<LiveDisplayProps> {
   render() {
      const { t, onClickLiveDisplay } = this.props
      return (
         <LiveDisplayWrapper onClick={onClickLiveDisplay}>
            <LiveDisplayText>
               {t('common:webinar.streamingNow')}
            </LiveDisplayText>
            <LiveDisplayIconWrapper>
               <LiveDisplayIcon />
            </LiveDisplayIconWrapper>
         </LiveDisplayWrapper>
      )
   }
}

export default withTranslation()(LiveDisplay)
