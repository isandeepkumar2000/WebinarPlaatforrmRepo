import styled from 'styled-components'

import { Typo12WhiteHKGroteskBold } from '../../../../styleGuide/Typos'
import { mobile } from '../../../../utils/MixinUtils'

export const LiveDisplayWrapper = styled.div`
   width: fit-content;
   display: flex;
   align-items: center;
   cursor: pointer;
`

export const LiveDisplayText = styled(Typo12WhiteHKGroteskBold)`
   margin-right: 8px;
   line-height: 2;
   ${mobile} {
      display: none;
   }
`

export const LiveDisplayIconWrapper = styled.div`
   display: flex;
   align-items: center;
   ${mobile} {
      margin-top: 4px;
   }
`
