import styled from 'styled-components'

import { VIDEO_OVERLAY_Z_INDEX } from '../../constants'

const HoverDiv = styled.div`
   cursor: pointer;
   :hover {
      opacity: 1;
   }
`

export const Container = styled.div`
   top: 0;
   right: 0;
   bottom: -2px;
   left: 0;
   position: absolute;
   background-color: rgba(0, 0, 0, 0.2);
   z-index: ${VIDEO_OVERLAY_Z_INDEX};
   visibility: visible;
`

export const PauseIconContainer = styled(HoverDiv)`
   position: absolute;
   top: 49.7%;
   left: 49.4%;
   margin-top: -2em;
   margin-left: -1.5em;
   opacity: 0.5;
`

export const BackwardButtonContainer = styled(HoverDiv)`
   position: absolute;
   top: 50%;
   left: 20%;
   margin-top: -2em;
   opacity: 0.5;
`

export const ForwardSeekButtonContainer = styled(HoverDiv)`
   position: absolute;
   top: 50%;
   right: 20%;
   opacity: 0.5;
   margin-top: -2em;
`

export const ReplayIconContainer = styled(HoverDiv)`
   opacity: 0.5;
`

export const Wrapper = styled.div`
   position: absolute;
   top: 0;
   left: 0;
   right: 0;
   bottom: 0;
   display: flex;
   align-items: center;
   justify-content: center;
`
