import React, { Component } from 'react'
import { observer } from 'mobx-react'

import BackwardIcon from '../../../../icons/BackwardSeekIcon'
import ForwardIcon from '../../../../icons/ForwardSeekIcon'
import VideoPauseButton from '../../../../icons/VideoPauseButton'
import ReplayIcon from '../../../../icons/ReplayIcon'

import {
   playerCustomComponentClassNames,
   VIDEO_FORWARD_TIME_IN_SEC,
   VIDEO_BACKWARD_TIME_IN_SEC
} from '../../constants'

import {
   Container,
   BackwardButtonContainer,
   ForwardSeekButtonContainer,
   PauseIconContainer,
   ReplayIconContainer,
   Wrapper
} from './styledComponents'
import './styles.scss'

interface Props {
   player: any
   showForwardIcon: boolean
   isLive: boolean
}

@observer
class VideoOverlay extends Component<Props> {
   constructor(props) {
      super(props)
      this.registerPlayerEvents()
      this.initializeUserActiveStatus()
   }

   initializeUserActiveStatus = (): void => {
      this.setUserActiveStatus(false)
   }

   registerPlayerEvents = (): void => {
      const { player } = this.props
      player.on('mouseleave', this.onMouseLeave)
   }

   onMouseLeave = (): void => {
      this.setUserActiveStatus(false)
   }

   setUserActiveStatus = (status: boolean): void => {
      const { player } = this.props
      if (player) {
         player.userActive(status)
      }
   }

   pauseVideo = (): void => {
      const { player } = this.props
      if (player) {
         player.pause()
      }
   }

   getCurrentTimeInSec = (): number => {
      const { player } = this.props
      const currentTime = Math.floor(player.currentTime())
      return currentTime
   }

   getDurationTimeInSec = (): number => {
      const { player } = this.props
      const currentDuration = Math.floor(player.duration())
      return currentDuration
   }

   changeCurrentTime = (time: number): void => {
      const { player } = this.props
      if (player) {
         player.currentTime(time)
      }
   }

   onClickBackIcon = (event): void => {
      event.stopPropagation()
      this.backwardTenSeconds()
   }

   onClickForwardIcon = (event): void => {
      const { isLive } = this.props
      event.stopPropagation()
      if (
         isLive &&
         this.getDurationTimeInSec() - this.getCurrentTimeInSec() < 10
      ) {
         this.changeCurrentTime(this.getDurationTimeInSec())
      } else {
         this.forwardTenSeconds()
      }
   }

   forwardTenSeconds = (): void => {
      this.changeCurrentTime(
         this.getCurrentTimeInSec() + VIDEO_FORWARD_TIME_IN_SEC
      )
   }

   backwardTenSeconds = (): void => {
      this.changeCurrentTime(
         this.getCurrentTimeInSec() - VIDEO_BACKWARD_TIME_IN_SEC
      )
   }

   replayVideo = (): void => {
      const { player } = this.props
      player.play()
   }

   renderForwardIcon = (): React.ReactNode => (
      <ForwardSeekButtonContainer
         onClick={this.onClickForwardIcon}
         data-testid={'forward-seek-button'}
      >
         <ForwardIcon />
      </ForwardSeekButtonContainer>
   )

   renderOverlay = (): React.ReactNode => {
      const { showForwardIcon } = this.props
      const { overlay, pauseIcon, replayIcon } = playerCustomComponentClassNames
      return (
         <>
            <Container className={overlay}>
               <BackwardButtonContainer
                  onClick={this.onClickBackIcon}
                  data-testid={'backward-seek-button'}
               >
                  <BackwardIcon />
               </BackwardButtonContainer>
               <PauseIconContainer
                  onClick={this.pauseVideo}
                  className={pauseIcon}
                  data-testid={'pause-button'}
               >
                  <VideoPauseButton />
               </PauseIconContainer>
               {showForwardIcon ? this.renderForwardIcon() : null}
            </Container>
            <Wrapper className={replayIcon}>
               <ReplayIconContainer onClick={this.replayVideo}>
                  <ReplayIcon />
               </ReplayIconContainer>
            </Wrapper>
         </>
      )
   }

   render(): React.ReactNode {
      return <>{this.renderOverlay()}</>
   }
}

export default VideoOverlay
