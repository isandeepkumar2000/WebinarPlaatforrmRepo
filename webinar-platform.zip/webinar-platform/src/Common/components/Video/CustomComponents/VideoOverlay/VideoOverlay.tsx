import React from 'react'
import ReactDom from 'react-dom'
import videoJS from 'video.js'

import {
   playerCustomComponentIds,
   PLAYER_BASE_COMPONENT
} from '../../constants'

import VideoOverlay from './index'

const vjsComponent = videoJS.getComponent(PLAYER_BASE_COMPONENT)
class VJSVideoOverlay extends vjsComponent {
   player
   options
   constructor(player, options) {
      super(player, options)
      const { overlayId } = playerCustomComponentIds
      this.player = player
      this.options = options
      player.ready(() => {
         this.mount()
      })
      this.on('dispose', () => {
         ReactDom.unmountComponentAtNode(this.el())
      })
      this.el().id = overlayId
   }

   mount = () => {
      ReactDom.render(
         <VideoOverlay player={this.player} {...this.options} />,
         this.el()
      )
   }
}

export default VJSVideoOverlay
