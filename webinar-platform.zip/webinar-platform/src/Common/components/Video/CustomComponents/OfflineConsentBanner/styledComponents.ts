import styled from 'styled-components'

import {
   VIDEO_OFFLINE_BANNER_FULL_SCREEN_Z_INDEX,
   VIDEO_OFFLINE_BANNER_Z_INDEX
} from '../../../../constants/ZIndexConstants'
import {
   Typo14WhiteHKGroteskMedium,
   Typo24PaleGrayTwoHKGroteskMedium
} from '../../../../styleGuide/Typos'
import Colors from '../../../../themes/Colors'
import { mobile } from '../../../../utils/MixinUtils'

import KossipOutlineButton from '../../../KossipOutlineButton'

export const OfflineBannerContainer = styled.div`
   display: flex;
   flex-direction: column;
   justify-content: center;
   align-items: center;
   background-color: rgba(0, 0, 0, 0.5);
   position: absolute;
   width: 100%;
   height: 100.1%;
   z-index: ${props =>
      props.isVideoInFullScreen
         ? VIDEO_OFFLINE_BANNER_FULL_SCREEN_Z_INDEX
         : VIDEO_OFFLINE_BANNER_Z_INDEX};
   top: 0px;
`

export const OfflineIconContainer = styled.div`
   margin-bottom: 24px;
   ${mobile} {
      margin-bottom: 8px;
   }
`

export const OfflineText = styled(Typo24PaleGrayTwoHKGroteskMedium)`
   width: 444px;
   margin-bottom: 32px;
   ${mobile} {
      font-size: 14px;
      width: 264px;
      margin-bottom: 16px;
   }
   text-align: center;
`

export const RetryButton = styled(KossipOutlineButton)`
   border: 2px solid ${Colors.white} !important;
   border-radius: 4px;
   text-transform: uppercase;
   width: 96px;
   height: 36px;
   background-color: transparent;
   display: flex !important;
   align-items: center;
   justify-content: center;
`

export const RetryButtonText = styled(Typo14WhiteHKGroteskMedium)`
   display: flex;
   align-items: center;
`

export const RetryIconContainer = styled.div`
   margin-right: 4px;
   display: flex;
   align-items: center;
`
