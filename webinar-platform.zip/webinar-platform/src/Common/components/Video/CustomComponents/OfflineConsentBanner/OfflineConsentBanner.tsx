import React from 'react'
import ReactDom from 'react-dom'
import videoJS from 'video.js'

import {
   playerCustomComponentClassNames,
   playerCustomComponentIds,
   PLAYER_BASE_COMPONENT
} from '../../constants'

import OfflineBanner from '.'

const vjsComponent = videoJS.getComponent(PLAYER_BASE_COMPONENT)

class VJSOfflineBanner extends vjsComponent {
   options
   constructor(player, options) {
      super(player, options)
      this.options = options
      const { offlineBanner } = playerCustomComponentClassNames
      const { offlineBannerId } = playerCustomComponentIds
      player.ready(() => {
         this.mount()
      })
      this.on('dispose', () => {
         ReactDom.unmountComponentAtNode(this.el())
      })
      this.el().id = offlineBannerId
      this.el().className = offlineBanner
   }

   mount = () => {
      ReactDom.render(
         <OfflineBanner
            onClickOfflineRetry={this.options.onClickOfflineRetry}
            isVideoInFullScreen={this.options.isVideoInFullScreen}
         />,
         this.el()
      )
   }
}

export default VJSOfflineBanner
