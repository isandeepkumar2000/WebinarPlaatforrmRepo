import React, { Component } from 'react'
import { WithTranslation, withTranslation } from 'react-i18next'

import ReplayIcon from '../../../../icons/ReplayIcon'
import OfflineIcon from '../../../../icons/OfflineIcon'
import { isMobile } from '../../../../utils/ResponsiveUtils'

import {
   OfflineBannerContainer,
   OfflineIconContainer,
   OfflineText,
   RetryButton,
   RetryButtonText,
   RetryIconContainer
} from './styledComponents'
import './styles.scss'

interface Props extends WithTranslation {
   onClickOfflineRetry: Function
   isVideoInFullScreen: boolean
}

class OfflineBanner extends Component<Props> {
   renderLeftIcon = () => (
      <RetryIconContainer>
         <ReplayIcon height={'16'} width={'16'} />
      </RetryIconContainer>
   )

   onClickOfflineRetry = (): void => {
      const { onClickOfflineRetry } = this.props
      onClickOfflineRetry && onClickOfflineRetry()
   }

   render() {
      const { t, isVideoInFullScreen } = this.props
      return (
         <OfflineBannerContainer
            id='offline-consent-banner'
            isVideoInFullScreen={isVideoInFullScreen}
         >
            <OfflineIconContainer>
               {isMobile() ? (
                  <OfflineIcon className={'offlineIconClassName'} />
               ) : (
                  <OfflineIcon className={'offlineIconClassName'} />
               )}
            </OfflineIconContainer>
            <OfflineText className={'offlineTextClassName'}>
               {t('common:video.offlineConsentMessage')}
            </OfflineText>
            <RetryButton
               textTypo={RetryButtonText}
               data-testid='offline-retry'
               onClick={this.onClickOfflineRetry}
               renderLeftIcon={this.renderLeftIcon}
            >
               {t('common:common.failureView.retry')}
            </RetryButton>
         </OfflineBannerContainer>
      )
   }
}

export default withTranslation()(OfflineBanner)
