import React, { Component } from 'react'

import {
   LoaderContainer,
   FirstBar,
   SecondBar,
   ThirdBar,
   FourthBar,
   FifthBar
} from './styledComponents'

class VideoLoader extends Component {
   render() {
      return (
         <LoaderContainer>
            <FirstBar />
            <SecondBar />
            <ThirdBar />
            <FourthBar />
            <FifthBar />
         </LoaderContainer>
      )
   }
}

export default VideoLoader
