import styled, { keyframes } from 'styled-components'

import Colors from '../../../../themes/Colors'

export const LoaderContainer = styled.div`
   width: 50px;
   height: 40px;
   text-align: center;
   font-size: 10px;
`

export const skStretchDelay = keyframes`
    0%,
    40%,
    100% {
        transform: scaleY(0.4);
        -webkit-transform: scaleY(0.4);
    }

    20% {
        transform: scaleY(1.0);
        -webkit-transform: scaleY(1.0);
    }
`

export const VerticalBar = styled.div`
   background-color: ${Colors.white};
   height: 100%;
   width: 4px;
   display: inline-block;
   margin-right: 3px;

   -webkit-animation: ${skStretchDelay} 1.2s infinite ease-in-out;
   animation: ${skStretchDelay} 1.2s infinite ease-in-out;
`

export const FirstBar = styled(VerticalBar)``

export const SecondBar = styled(VerticalBar)`
   -webkit-animation-delay: -1.1s;
   animation-delay: -1.1s;
`

export const ThirdBar = styled(VerticalBar)`
   -webkit-animation-delay: -1s;
   animation-delay: -1s;
`

export const FourthBar = styled(VerticalBar)`
   -webkit-animation-delay: -0.9s;
   animation-delay: -0.9s;
`

export const FifthBar = styled(VerticalBar)`
   -webkit-animation-delay: -0.8s;
   animation-delay: -0.8s;
`
