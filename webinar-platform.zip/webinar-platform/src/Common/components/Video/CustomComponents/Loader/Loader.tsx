import React from 'react'
import ReactDom from 'react-dom'
import videoJS from 'video.js'

import {
   playerCustomComponentClassNames,
   playerCustomComponentIds,
   PLAYER_BASE_COMPONENT
} from '../../constants'

import VideoLoader from '.'

const vjsComponent = videoJS.getComponent(PLAYER_BASE_COMPONENT)

class VJSLoader extends vjsComponent {
   constructor(player, options) {
      super(player, options)
      const { loader } = playerCustomComponentClassNames
      const { loaderId } = playerCustomComponentIds
      player.ready(() => {
         this.mount()
      })
      this.on('dispose', () => {
         ReactDom.unmountComponentAtNode(this.el())
      })
      this.el().id = loaderId
      this.el().className = loader
   }

   mount = () => {
      ReactDom.render(<VideoLoader />, this.el())
   }
}

export default VJSLoader
