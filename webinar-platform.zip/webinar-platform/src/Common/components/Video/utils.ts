import {
   getLocalPlaybackDetails,
   setLocalPlaybackDetails
} from '../../utils/LocalStorageUtils'
import { isSafariBrowser } from '../../utils/PlatformUtils'
import { isTabletOrMobile } from '../../utils/ResponsiveUtils'
import {
   extensionConstant,
   videoExtensions,
   videoQualityWithoutExtension,
   videoSpeed,
   videoTypes
} from './constants'
import {
   MultiMediaSource,
   VideoWaterMarkOptionsType,
   LocalPlaybackSettingsType
} from './types'

export function getSingleMultiMedia(multimediaUrl: any): MultiMediaSource[] {
   const multiMediaSources: MultiMediaSource[] = []

   const { hlsType, dashType } = videoTypes
   const { hlsExtension, dashExtension } = videoExtensions
   if (multimediaUrl.includes(extensionConstant)) {
      const hlsUrl = multimediaUrl.replace(extensionConstant, hlsExtension)
      const dashUrl = multimediaUrl.replace(extensionConstant, dashExtension)

      //NOTE: This order is important
      if (isSafariBrowser()) {
         multiMediaSources.push({ src: hlsUrl, type: hlsType })
         multiMediaSources.push({ src: dashUrl, type: dashType })
      } else {
         multiMediaSources.push({ src: dashUrl, type: dashType })
         multiMediaSources.push({ src: hlsUrl, type: hlsType })
      }
   }
   return multiMediaSources
}

export function getMultimediaSources(multimediaUrl): MultiMediaSource[] {
   if (multimediaUrl) {
      return getSingleMultiMedia(multimediaUrl)
   }
   return []
}

export function getVideoPlayBackRate(userId: string) {
   const playbackDetailsArray = getLocalPlaybackDetails()
   let playbackRate = videoSpeed.oneX
   if (playbackDetailsArray && playbackDetailsArray.length > 0) {
      playbackDetailsArray.forEach(eachUserObject => {
         if (eachUserObject.user_id === userId) {
            playbackRate = eachUserObject.playback_rate
         }
      })
   }
   return playbackRate
}

export function getVideoQuality(
   userId: string,
   qualityBasedOnConfig: string = videoQualityWithoutExtension.sevenTwenty
) {
   const playbackDetailsArray = getLocalPlaybackDetails()
   let videoQuality = qualityBasedOnConfig
   if (playbackDetailsArray && playbackDetailsArray.length > 0) {
      playbackDetailsArray.forEach(eachUserObject => {
         if (eachUserObject.user_id === userId) {
            videoQuality = eachUserObject.video_quality
         }
      })
   }
   return videoQuality
}

export function getWebinarWatchedDurationData(
   userId: string,
   webinarId: string
) {
   const playbackDetailsArray = getLocalPlaybackDetails()
   let watchedDuration = undefined
   if (playbackDetailsArray && playbackDetailsArray.length > 0) {
      const activeUserObject = playbackDetailsArray.find(
         eachUserObject => eachUserObject.user_id === userId
      )
      if (activeUserObject) {
         if (
            activeUserObject.webinar_details &&
            activeUserObject.webinar_details.length > 0
         ) {
            const activeWebinarObject = activeUserObject.webinar_details.find(
               eachWebinarObject => eachWebinarObject.webinar_id === webinarId
            )
            if (activeWebinarObject) {
               watchedDuration = activeWebinarObject.watched_duration
            }
         }
      }
   }
   return watchedDuration
}

export function getCumulativeWatchedDuration(
   userId: string,
   webinarId: string
) {
   const playbackDetailsArray = getLocalPlaybackDetails()
   let cumulativeWatchedDuration = 0
   if (playbackDetailsArray && playbackDetailsArray.length > 0) {
      const activeUserObject = playbackDetailsArray.find(
         eachUserObject => eachUserObject.user_id === userId
      )
      if (activeUserObject) {
         if (
            activeUserObject.webinar_details &&
            activeUserObject.webinar_details.length > 0
         ) {
            const activeWebinarObject = activeUserObject.webinar_details.find(
               eachWebinarObject => eachWebinarObject.webinar_id === webinarId
            )
            if (activeWebinarObject) {
               if (activeWebinarObject.cumulative_watched_duration >= 0) {
                  cumulativeWatchedDuration =
                     activeWebinarObject.cumulative_watched_duration
               }
            }
         }
      }
   }
   return cumulativeWatchedDuration
}

function getWebinarDetailsObject(
   webinarId: string,
   watchedDuration: number,
   cumulativeOffset: number
) {
   return {
      webinar_id: webinarId,
      watched_duration: watchedDuration,
      cumulative_watched_duration: cumulativeOffset
   }
}

function getUserObject(playbackSettings: LocalPlaybackSettingsType) {
   const {
      userId,
      webinarId,
      watchedDuration,
      videoQuality,
      playbackRate,
      cumulativeOffset
   } = playbackSettings

   return {
      user_id: userId,
      webinar_details: [
         getWebinarDetailsObject(webinarId, watchedDuration, cumulativeOffset)
      ],
      video_quality: videoQuality,
      playback_rate: playbackRate
   }
}

function updateWebinarObject(
   eachUserObject,
   playbackSettings: LocalPlaybackSettingsType
) {
   const {
      userId,
      webinarId,
      watchedDuration,
      cumulativeOffset
   } = playbackSettings
   if (eachUserObject.user_id === userId) {
      if (
         eachUserObject.webinar_details.some(
            eachWebinarObject => eachWebinarObject.webinar_id === webinarId
         )
      ) {
         const updatedWebinarDetailsArray = eachUserObject.webinar_details.map(
            eachWebinarObject => {
               if (eachWebinarObject.webinar_id === webinarId) {
                  eachWebinarObject.watched_duration = watchedDuration
                  if (eachWebinarObject.cumulative_watched_duration)
                     eachWebinarObject.cumulative_watched_duration += cumulativeOffset
                  else
                     eachWebinarObject.cumulative_watched_duration = cumulativeOffset //TODO: This is added for backward compatibility
                  return eachWebinarObject
               }
               return eachWebinarObject
            }
         )
         eachUserObject.webinar_details = updatedWebinarDetailsArray
         return eachUserObject
      }
      eachUserObject.webinar_details.push(
         getWebinarDetailsObject(webinarId, watchedDuration, cumulativeOffset)
      )
      return eachUserObject
   }
   return eachUserObject
}

export function setUserPlaybackDetailsData(
   playbackSettings: LocalPlaybackSettingsType
) {
   const { userId, videoQuality, playbackRate } = playbackSettings

   const playbackDetailsArray = getLocalPlaybackDetails()

   let updatedPlaybackDetailsArray

   if (playbackDetailsArray && playbackDetailsArray.length > 0) {
      if (
         playbackDetailsArray.some(
            eachUserObject => eachUserObject.user_id === userId
         )
      ) {
         updatedPlaybackDetailsArray = playbackDetailsArray.map(
            eachUserObject => {
               const updatedUserObject = updateWebinarObject(
                  eachUserObject,
                  playbackSettings
               )
               updatedUserObject.video_quality = videoQuality
               updatedUserObject.playback_rate = playbackRate
               return updatedUserObject
            }
         )
         setLocalPlaybackDetails(updatedPlaybackDetailsArray)
      } else {
         const userDetailsObject = getUserObject(playbackSettings)
         playbackDetailsArray.push(userDetailsObject)
         setLocalPlaybackDetails(playbackDetailsArray)
      }
   } else {
      updatedPlaybackDetailsArray = [getUserObject(playbackSettings)]
      setLocalPlaybackDetails(updatedPlaybackDetailsArray)
   }
}

const getWatermarkStringFromUserId = (userId): string => {
   const watermarkString = userId
      .slice(9, 16)
      .split('-')
      .join('')

   return watermarkString
}

export const getDynamicWatermarkConfig = (
   videoId: string,
   userId: string
): VideoWaterMarkOptionsType => {
   return {
      elementId: `video_dynamic_water_mark_${videoId}`,
      watermarkText: getWatermarkStringFromUserId(userId),
      changeDuration: 6000,
      cssText: `display: flex; color: rgba(128,128,128,0.5); background-color: rgba(255, 255, 255, 0.1); font-size: ${
         isTabletOrMobile() ? '10px' : '13px'
      }; z-index: 100; position: absolute; line-height: normal`
   }
}
