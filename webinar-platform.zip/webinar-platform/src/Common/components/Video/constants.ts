export const playerClassNames = {
   waiting: 'vjs-waiting',
   controlBar: 'vjs-control-bar',
   playBackRate: 'vjs-playback-rate',
   sourceSelector: 'vjs-http-source-selector',
   defaultSkin: 'vjs-default-skin',
   bigPlayCentered: 'vjs-big-play-centered',
   video: 'video-js'
}

export const videoPreload = {
   auto: 'auto',
   metadata: 'metadata',
   none: 'none'
}

export const videoTypes = {
   hlsType: 'application/x-mpegURL',
   dashType: 'application/dash+xml',
   mp4Type: 'video/mp4'
}

export const videoExtensions = {
   hlsExtension: '.m3u8',
   dashExtension: '.mpd'
}

export const extensionConstant = '__extension__'

export const HIDE_BIG_PLAY_BUTTON_CLASSNAME = 'vjs-hide-big-play-button'

export const videoPlayBackRates = [0.75, 1, 1.25, 1.5, 2]

export const playerChildNames = {
   loadingSpinner: 'loadingSpinner',
   controlBar: 'controlBar',
   bigPlayButton: 'BigPlayButton'
}

export const controlBarChildNames = {
   progressControl: 'progressControl',
   timeDivider: 'timeDivider',
   durationDisplay: 'durationDisplay',
   playToggle: 'playToggle',
   playBackRate: 'playbackRateMenuButton',
   liveDisplay: 'liveDisplay'
}

export const playerCustomComponentNames = {
   loader: 'vjsLoader',
   overlay: 'vjsOverlay',
   offlineBanner: 'vjsOfflineBanner'
}

export const playerCustomComponentClassNames = {
   loader: 'vjs-custom-loader',
   overlay: 'vjs-overlay',
   pauseIcon: 'vjs-pause-icon',
   replayIcon: 'vjs-replay-icon',
   customControlSpacer: 'vjs-custom-control-spacer vjs-spacer',
   offlineBanner: 'vjs-offline-banner'
}

export const playerCustomComponentIds = {
   loaderId: 'vjs-custom-loader-id',
   overlayId: 'vjs-overlay-id',
   offlineBannerId: 'vjs-offline-consent-banner-id'
}

export const PLAYER_BASE_COMPONENT = 'Component'

export const VIDEO_FORWARD_TIME_IN_SEC = 10

export const VIDEO_BACKWARD_TIME_IN_SEC = 10

export const VIDEO_OVERLAY_Z_INDEX = 101

export const videoQuality = {
   auto: 'auto',
   '1080p': '1080p',
   '720p': '720p',
   '540p': '540p',
   '360p': '360p',
   '270p': '270p'
}

export const videoQualityWithoutExtension = {
   sevenTwenty: '720',
   fourEighty: '480'
}

export const videoSpeed = {
   pointSevenFiveX: '0.75x',
   oneX: '1x',
   onePointTwoFiveX: '1.25x',
   onePointFiveX: '1.5x',
   twoX: '2x'
}

export const subtitlesSupportedLanguages = {
   en: 'ENGLISH'
}

export const videoErrorCodes = {
   MEDIA_ERR_CUSTOM: 0,
   MEDIA_ERR_ABORTED: 1,
   MEDIA_ERR_NETWORK: 2,
   MEDIA_ERR_DECODE: 3,
   MEDIA_ERR_SRC_NOT_SUPPORTED: 4,
   MEDIA_ERR_ENCRYPTED: 5
}

export const bandwidthConstants = {
   LOW: 250000,
   MEDIUM: 500000,
   HIGH: 1000000
}

export const MAX_VIDEO_BUFFERING_TIME_IN_SECONDS = 10

export const beforeUnloadEventTypes = {
   add: 'ADD',
   remove: 'REMOVE'
}
