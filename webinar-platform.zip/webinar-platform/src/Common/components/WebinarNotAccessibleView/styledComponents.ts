import styled from 'styled-components'
import { Typo32WhiteHKGroteskMedium } from '../../styleGuide/Typos'
import Colors from '../../themes/Colors'
import { minDeviceWidth, mobile } from '../../utils/MixinUtils'
import Button from '../Button'

export const Container = styled.div`
   border-radius: 4px;
   background-color: ${props => props.theme.primaryBackgroundColor};
   display: flex;
   flex-direction: column;
   align-items: center;
   justify-content: center;
   width: 100%;
   transition: all 0.25s linear;
   height: 100%;
`

export const NoAccessWebinarMessage = styled(Typo32WhiteHKGroteskMedium)`
   line-height: 1.33;
   text-align: center;
   color: ${props => props.theme.primaryItemsSectionColor};
   ${mobile} {
      font-size: 16px;
      line-height: 1.5;
   }

   ${minDeviceWidth(768)} {
      font-size: 24px;
      line-height: 1.5;
   }

   ${minDeviceWidth(1024)} {
      font-size: 32px;
      max-width: 900px;
   }
   white-space: pre-wrap;
`

export const ToGetAccess = styled(Typo32WhiteHKGroteskMedium)`
   color: ${props => props.theme.primaryItemsSectionColor};
   font-size: 16px;
   margin-top: 24px;
   ${mobile} {
      margin-top: 0px;
   }
`

export const MessageWrapper = styled.div`
   display: flex;
   margin-top: 32px;
   flex-direction: column;
   ${mobile} {
      flex-direction: row;
      width: 256px;
   }
`

export const RequestHere = styled(Button)`
   height: 40px;
   width: 140px;
   margin-top: 16px;
   ${minDeviceWidth(1024)} {
      margin-top: 32px;
   }
   background-color: ${Colors.cerulean};
`

export const ToGetAccessWrapper = styled.div`
   display: flex;
   justify-content: center;
   ${mobile} {
      margin-bottom: 8px;
   }
`
