import React, { Component } from 'react'
import { observer } from 'mobx-react'
import { WithTranslation, withTranslation } from 'react-i18next' //eslint-disable-line

import { openLinkInNewWindowWithQueryParams } from '../../../LiveWebinar/utils/windowsUtils'

import NoAccessibleMobileView from '../../icons/NoAccessibleMobileViewIcon'
import NoAccessibleTabletView from '../../icons/NoAccessibleTabletViewIcon'
import NoAccessibleDesktopView from '../../icons/NoAccessibleDesktopView'
import NoAccessibleMobileBlackView from '../../icons/NoAccessibleMobileViewBlack'
import NoAccessibleTabletBlackView from '../../icons/NoAccessibleTabletViewBlack'
import NoAccessibleDesktopBlackView from '../../icons/NoAccessibleDesktopViewBlack'

import { DARK_THEME } from '../../constants/ThemeConstants'
import { isMobile, isTabletOrMobile } from '../../utils/ResponsiveUtils'
import { NO_ACCESSIBLE_VIEW_REQUEST_LINK } from '../../constants/BackendConstants'

import {
   Container,
   NoAccessWebinarMessage,
   ToGetAccess,
   MessageWrapper,
   RequestHere,
   ToGetAccessWrapper
} from './styledComponents'

interface Props extends WithTranslation {
   theme: string
   webinarAccessLink: string
   inaccessibleViewText: string | undefined
}

@observer
class WebinarNotAccessibleView extends Component<Props> {
   getNoAccessibleView = () => {
      const { theme } = this.props
      if (theme === DARK_THEME) {
         if (isMobile()) {
            return <NoAccessibleMobileBlackView />
         } else if (isTabletOrMobile()) {
            return <NoAccessibleTabletBlackView />
         }
         return <NoAccessibleDesktopBlackView />
      }
      if (isMobile()) {
         return <NoAccessibleMobileView />
      } else if (isTabletOrMobile()) {
         return <NoAccessibleTabletView />
      }
      return <NoAccessibleDesktopView />
   }

   onClickRequestHere = () => {
      const { webinarAccessLink } = this.props
      const accessLink =
         webinarAccessLink !== ''
            ? webinarAccessLink
            : NO_ACCESSIBLE_VIEW_REQUEST_LINK

      openLinkInNewWindowWithQueryParams(accessLink)
   }

   render() {
      const { t, inaccessibleViewText } = this.props
      return (
         <Container>
            <div>{this.getNoAccessibleView()}</div>
            <MessageWrapper>
               {isMobile() ? (
                  <NoAccessWebinarMessage>
                     {inaccessibleViewText ??
                        t('notAccessibleWebinarWithTOGetAccess')}
                  </NoAccessWebinarMessage>
               ) : (
                  <>
                     <NoAccessWebinarMessage>
                        {inaccessibleViewText ?? t('notAccessibleWebinar')}
                     </NoAccessWebinarMessage>
                  </>
               )}
            </MessageWrapper>
            <RequestHere onClick={this.onClickRequestHere}>
               {t('requestHere')}
            </RequestHere>
         </Container>
      )
   }
}

export default withTranslation()(WebinarNotAccessibleView)
