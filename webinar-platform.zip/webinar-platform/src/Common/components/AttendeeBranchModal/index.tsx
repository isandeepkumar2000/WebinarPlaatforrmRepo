import React, { Component } from 'react'
import { observable } from 'mobx'
import { withRouter } from 'react-router-dom'
import { WithTranslation, withTranslation } from 'react-i18next' //eslint-disable-line
import { observer } from 'mobx-react'
import { withTheme } from 'styled-components'

import Webinar from '../../../ContentManagement/stores/models/Webinar'
import { getQuestionOption } from '../../../ContentManagement/utils/McqQuestionUtils'
import { getAttendeeBranchOptions } from '../../../ContentManagement/constants/Aug16WebinarConstants'

import ThemeStore from '../../stores/ThemeStore'
import { LabelValueType } from '../../stores/types'
import { getUserUUID } from '../../utils/LocalStorageUtils'
import { DARK_THEME } from '../../constants/ThemeConstants'
import { getNormalSpacedString } from '../../utils/StringUtils'
import { trackEvent } from '../../utils/SegmentUtils/SegmentUtils'
import { ErrorObject, validateEmpty } from '../../utils/ValidationUtils'
import { attendeeBranchConstants } from '../../constants/BackendConstants'
import { WEBINAR_ATTENDEE_BRANCH_EVENT } from '../../constants/SegmentConstants'
import { getIconDimensions } from '../../utils/LogoUtils'

import RadioGroup from '../RadioGroup'
import DesktopLayout from '../DesktopLayout'

import {
   AttendeeBranchForm,
   AttendeeBranchFormWrapper,
   AttendeeBranchModalWrapper,
   AttendeeBranchModel,
   AttendeeBranchText,
   OptionsWrapper,
   radioItemCss,
   UserTextInputWrapper,
   UserTextInput,
   ButtonWrapper,
   SubmitButton
} from './styledComponents'
import './styles.scss'

interface AttendeeBranchModalProps extends WithTranslation {
   themeStore: ThemeStore
   webinar?: Webinar
   onSubmitAttendeeForm: (requestObject: any) => Promise<void>
}

@observer
class AttendeeBranchModal extends Component<AttendeeBranchModalProps> {
   @observable shouldShowModal: boolean
   @observable selectedAttendeeBranch: string
   @observable otherAttendeeBranchName: string
   @observable shouldShowInputField: boolean
   otherAttendeeBranchNameRef
   attendeeBranchRadioGroupRef

   constructor(props) {
      super(props)
      this.shouldShowModal = true
      this.selectedAttendeeBranch = ''
      this.otherAttendeeBranchName = ''
      this.shouldShowInputField = false
      this.otherAttendeeBranchNameRef = React.createRef()
      this.attendeeBranchRadioGroupRef = React.createRef()
   }

   getModalOverlayClassName = (): string => {
      const {
         themeStore: { selectedTheme }
      } = this.props
      if (selectedTheme === DARK_THEME) {
         return 'attendeeBranchModalOverlayStyles'
      }
      return 'attendeeBranchModalOverlayStyles attendeeBranchLightModalOverlayStyles'
   }

   getModalClassName = (): string => {
      const {
         themeStore: { selectedTheme }
      } = this.props
      if (selectedTheme === DARK_THEME) {
         return 'branchModalStyles attendeeBranchDarkModalStyles'
      }
      return 'branchModalStyles'
   }

   getAttendeeBranchOptionsList = (): Array<LabelValueType> => {
      let options: Array<LabelValueType> = []
      getAttendeeBranchOptions().forEach(
         option =>
            (options = [
               ...options,
               getQuestionOption(option.optionContent, option.optionId)
            ])
      )
      return options
   }

   trackWebinarAttendeeBranch = (): void => {
      const { webinar } = this.props
      if (webinar) {
         const { analyticsConfiguration } = webinar

         if (analyticsConfiguration.shouldTrackEvents)
            trackEvent(WEBINAR_ATTENDEE_BRANCH_EVENT, {
               language: webinar.language,
               other: getNormalSpacedString(this.otherAttendeeBranchName),
               serial_number: analyticsConfiguration.serialNumber,
               webinar_category: analyticsConfiguration.webinarCategory,
               webinar_slug: webinar.webinarSlug,
               branch: this.getSelectedAttendeeBranchName()
            })
      }
   }

   validateRadioGroup = (): ErrorObject => {
      const { t } = this.props
      if (this.selectedAttendeeBranch) {
         return {
            errorMessage: '',
            shouldShowError: false
         }
      }
      return {
         errorMessage: t('selectAtLeastOneErrorMessage'),
         shouldShowError: true
      }
   }

   getSelectedAttendeeBranchName = (): string => {
      const options = this.getAttendeeBranchOptionsList()
      const selectedAttendeeBranchName: Array<LabelValueType> = options.filter(
         eachOption => eachOption.value === this.selectedAttendeeBranch
      )
      return selectedAttendeeBranchName[0].label
   }

   validateOtherAttendeeBranchNameField = (): ErrorObject =>
      validateEmpty(this.otherAttendeeBranchName)

   validate = (): void => {
      const { onSubmitAttendeeForm, webinar } = this.props
      this.onBlurOtherAttendeeBranchName()
      this.attendeeBranchRadioGroupRef?.current.onValidate()
      if (
         !this.attendeeBranchRadioGroupRef?.current.isError &&
         !this.otherAttendeeBranchNameRef?.current?.inputRef.current.isError()
      ) {
         const requestObject = {
            user_id: getUserUUID(),
            webinar_id: webinar?.webinarId,
            branch_name: this.isSelectedAttendeeBranchNameOther()
               ? this.otherAttendeeBranchName
               : this.getSelectedAttendeeBranchName()
         }
         this.trackWebinarAttendeeBranch()
         onSubmitAttendeeForm(requestObject)
         this.shouldShowModal = false
      }
   }

   onChangeOtherAttendeeBranchName = (event): void => {
      this.otherAttendeeBranchName = event.target.value
   }

   onBlurOtherAttendeeBranchName = (): void => {
      this.otherAttendeeBranchNameRef?.current?.onBlur()
   }

   isSelectedAttendeeBranchNameOther = (): boolean =>
      this.selectedAttendeeBranch === attendeeBranchConstants.other

   handleSelectedOption = (value): void => {
      const options = this.getAttendeeBranchOptionsList()
      options.forEach(eachOption => {
         if (eachOption.value.toString() === value) {
            this.selectedAttendeeBranch = eachOption.value
         }
      })
      if (this.isSelectedAttendeeBranchNameOther()) {
         this.shouldShowInputField = true
      } else {
         this.shouldShowInputField = false
      }
   }

   renderOtherTextInputField = (): React.ReactNode => {
      const { t } = this.props
      return this.shouldShowInputField ? (
         <UserTextInputWrapper>
            <UserTextInput
               data-testid={`branchName`}
               ref={this.otherAttendeeBranchNameRef}
               value={this.otherAttendeeBranchName}
               onChange={this.onChangeOtherAttendeeBranchName}
               onBlur={this.onBlurOtherAttendeeBranchName}
               validate={this.validateOtherAttendeeBranchNameField}
               placeholder={`${t('others')}`}
            />
         </UserTextInputWrapper>
      ) : null
   }

   renderAttendeeBranchForm = (): React.ReactElement => {
      const { t } = this.props
      return (
         <AttendeeBranchForm>
            <AttendeeBranchText>{t('branch')}</AttendeeBranchText>
            <OptionsWrapper>
               <RadioGroup
                  ref={this.attendeeBranchRadioGroupRef}
                  options={this.getAttendeeBranchOptionsList()}
                  onSelectOption={this.handleSelectedOption}
                  radioItemCss={radioItemCss}
                  radioImageSize={20}
                  selectedValue={this.selectedAttendeeBranch}
                  validate={this.validateRadioGroup}
               />
            </OptionsWrapper>
         </AttendeeBranchForm>
      )
   }

   render(): React.ReactNode {
      const {
         themeStore: { selectedTheme, setTheme }
      } = this.props

      return this.shouldShowModal ? (
         <AttendeeBranchModalWrapper>
            <AttendeeBranchModel
               isOpen={true}
               hideCloseIcon
               theme={selectedTheme}
               className={this.getModalClassName()}
               overlayClassName={this.getModalOverlayClassName()}
               ariaHideApp={false}
            >
               <DesktopLayout
                  {...getIconDimensions()}
                  hideBackButton={true}
                  changeTheme={setTheme}
                  theme={selectedTheme}
               />
               <AttendeeBranchFormWrapper>
                  {this.renderAttendeeBranchForm()}
                  {this.renderOtherTextInputField()}
                  <ButtonWrapper>
                     <SubmitButton id='submitButton' onClick={this.validate}>
                        {'Submit'}
                     </SubmitButton>
                  </ButtonWrapper>
               </AttendeeBranchFormWrapper>
            </AttendeeBranchModel>
         </AttendeeBranchModalWrapper>
      ) : null
   }
}

export default withRouter(withTheme(withTranslation()(AttendeeBranchModal)))
