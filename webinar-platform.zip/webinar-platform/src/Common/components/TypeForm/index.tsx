import React, { Component } from 'react'
import { observer } from 'mobx-react'
import { ReactTypeformEmbed } from 'react-typeform-embed'

type TypeFormProps = {
   url: string
   onSubmit?: () => void
   isEmbed?: boolean
}

@observer
class TypeForm extends Component<TypeFormProps> {
   render() {
      const { url, onSubmit, isEmbed } = this.props
      return isEmbed ? (
         <embed src={url} width='100%' height='100%' />
      ) : (
         <ReactTypeformEmbed url={url} onSubmit={onSubmit} />
      )
   }
}

export default TypeForm
