import React, { Component } from 'react'
import { withTheme } from 'styled-components'
import { withRouter } from 'react-router-dom'
import { History } from 'history'

import { CCBP_REGISTRATION_URL } from '../../../ContentManagement/constants/NavigationConstants'
import { openLinkInNewWindowWithQueryParams } from '../../../LiveWebinar/utils/windowsUtils'

import { DARK_THEME } from '../../constants/ThemeConstants'
import Colors from '../../themes/Colors'
import { getLogo } from '../../utils/LogoUtils'

import {
   LayoutContainer,
   Header,
   LogoWrapperWithBackButton,
   DesktopLayoutBody,
   BackArrowConatiner,
   LightingIconContainer,
   DarkThemeIconContainer,
   NavItemsWrapper,
   RegisterButton
} from './styledComponents'

interface DesktopLayoutProps {
   children: React.ReactNode
   height?: string
   width?: string
   hideBackButton?: boolean
   backToList: any
   changeTheme?: any
   theme?: string
   showMindsetSection?: boolean
   history: History
}

class DesktopLayout extends Component<DesktopLayoutProps> {
   static defaultProps = {
      hideBackButton: true,
      changeTheme: () => {},
      showMindsetSection: false
   }
   navigateToCcbpPage = () => {
      openLinkInNewWindowWithQueryParams(CCBP_REGISTRATION_URL)
   }
   renderHeaderButton = () => {
      if (this.props.showMindsetSection) {
         return (
            <RegisterButton onClick={this.navigateToCcbpPage}>
               Register
            </RegisterButton>
         )
      }
   }

   getLogoBasedOnDomain = (): React.ReactNode => {
      const { theme, height, width } = this.props
      const logoDetails = {
         height,
         width,
         theme
      }
      return getLogo(logoDetails)
   }

   render() {
      const {
         children,
         backToList,
         hideBackButton,
         changeTheme,
         theme
      } = this.props
      const backgroundColor =
         theme === DARK_THEME ? Colors.darkTwo : 'transparent'
      return (
         <LayoutContainer backgroundColor={backgroundColor}>
            <Header>
               <LogoWrapperWithBackButton>
                  {hideBackButton ? null : (
                     <div onClick={backToList}>
                        <BackArrowConatiner />
                     </div>
                  )}
                  {this.getLogoBasedOnDomain()}
               </LogoWrapperWithBackButton>
               <NavItemsWrapper>
                  {this.renderHeaderButton()}
                  <div onClick={changeTheme}>
                     {theme === DARK_THEME ? (
                        <LightingIconContainer />
                     ) : (
                        <DarkThemeIconContainer />
                     )}
                  </div>
               </NavItemsWrapper>
            </Header>
            <DesktopLayoutBody>{children}</DesktopLayoutBody>
         </LayoutContainer>
      )
   }
}

export default withRouter(withTheme(DesktopLayout))
