import styled from 'styled-components'

import { mobile, customDevice } from '../../utils/MixinUtils'
import BackArrow from '../../icons/BackArrow'
import LightingIcon from '../../icons/LightingIcon'
import DarkThemeIcon from '../../icons/DarkIcon'
import Button from '../Button'

export const LayoutContainer = styled.div`
   width: 100%;
   background-color: ${props => props.backgroundColor};
`

export const DesktopLayoutBody = styled.section`
   position: relative;
`
export const Header = styled.div`
   width: auto;
   height: 72px;
   display: flex;
   align-items: center;
   justify-content: space-between;
   padding-left: 9%;
   padding-right: 10%;
   background-color: ${props => props.theme.headerBackgroundColor};
   -webkit-backdrop-filter: blur(80px);
   backdrop-filter: blur(80px);
   ${mobile} {
      padding-left: 6.7%;
      padding-right: 6%;
   }
   transition: all 0.25s linear;
`

export const IbhubsLogo = styled.img`
   cursor: pointer;
   height: 23.6px;
   object-fit: contain;
   ${mobile} {
      height: 0px;
   }
`

export const LogoWrapperWithBackButton = styled.div`
   display: flex;
   align-items: center;
`

export const BackArrowConatiner = styled(BackArrow)`
   margin-right: 10px;
   padding: 10px;
   padding-right: 14px;
   cursor: pointer;
`

export const LightingIconContainer = styled(LightingIcon)`
   cursor: pointer;
   padding: 10px 0px 10px 20px;
   ${customDevice(250, 360)} {
      padding: 10px 0px 10px 8px;
   }
`

export const DarkThemeIconContainer = styled(DarkThemeIcon)`
   cursor: pointer;
   padding: 10px 0px 10px 20px;
   ${customDevice(250, 360)} {
      padding: 10px 0px 10px 8px;
   }
`

export const NavItemsWrapper = styled.div`
   display: flex;
   flex-direction: row;
   align-items: center;
`
export const RegisterButton = styled(Button)`
   height: 38px;
`
