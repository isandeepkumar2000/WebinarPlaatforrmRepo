import React from 'react'
import { observer } from 'mobx-react'

import AnalyticsConfiguration from '../../../ContentManagement/stores/models/AnalyticsConfiguration'

import { pageEvent } from '../../utils/SegmentUtils/SegmentUtils'

interface PageEventOptionsObjectType {
   name: string
}
interface TrackAnalyticsDataWrapperProps {
   analyticsConfiguration?: AnalyticsConfiguration
   pageEventOptions: PageEventOptionsObjectType
   renderComponent: () => JSX.Element
}

@observer
class TrackAnalyticsDataWrapper extends React.Component<
   TrackAnalyticsDataWrapperProps
> {
   componentDidMount() {
      const { analyticsConfiguration, pageEventOptions } = this.props
      if (analyticsConfiguration?.shouldTrackPage) {
         const { name } = pageEventOptions
         pageEvent(name)
      }
   }

   render() {
      const { renderComponent } = this.props
      return renderComponent()
   }
}

export default TrackAnalyticsDataWrapper
