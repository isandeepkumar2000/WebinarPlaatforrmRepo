import React, { Component } from 'react'
import 'styled-components/macro'

import { LabelValueType } from '../../stores/types'

import { TabBarContainer, TabTextContainer } from './styledComponents'

interface TabBarProps {
   tabsList: Array<LabelValueType>
   defaultSelectedTab?: string
   onClickTab: Function
   containerCSS?: React.CSSProperties
   itemCSS?: React.CSSProperties
}

interface State {
   selectedTab: string
}

class TabBar extends Component<TabBarProps, State> {
   constructor(props: TabBarProps) {
      super(props)
      const { tabsList, defaultSelectedTab } = this.props
      this.state = {
         selectedTab: defaultSelectedTab
            ? defaultSelectedTab
            : tabsList[0].value
      }
   }

   onClickTab = (value: string): void => {
      const { onClickTab } = this.props
      this.setState({ selectedTab: value })
      onClickTab(value)
   }

   isActive = (value: string): boolean => {
      const { selectedTab } = this.state
      return value === selectedTab
   }

   renderTabs = (): React.ReactNode => {
      const { tabsList, itemCSS } = this.props
      return tabsList.map(tab => {
         const onClickTabItem = (): void => this.onClickTab(tab.value)
         return (
            <TabTextContainer
               key={tab.value}
               onClick={onClickTabItem}
               isActive={this.isActive(tab.value)}
               css={itemCSS}
               data-testid={tab.value}
            >
               {tab.label}
            </TabTextContainer>
         )
      })
   }

   render(): React.ReactNode {
      const { containerCSS } = this.props
      return (
         <TabBarContainer css={containerCSS}>
            {this.renderTabs()}
         </TabBarContainer>
      )
   }
}

export default TabBar
