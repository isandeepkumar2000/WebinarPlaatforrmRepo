import styled from 'styled-components'

import Colors from '../../themes/Colors'
import { Typo12Steel60HKGroteskSemiBold } from '../../styleGuide/Typos'

export const TabBarContainer = styled.div`
   width: 100%;
   border-bottom: solid 1px ${Colors.darkBlueGrey16};
   height: 24px;
   display: flex;
   box-sizing: border-box;
`

export const TabTextContainer = styled(Typo12Steel60HKGroteskSemiBold)`
   line-height: 1.33;
   letter-spacing: 0.12px;
   color: ${(props): string => props.isActive && Colors.darkBlueGrey};
   border-bottom: solid 1px transparent;
   border-bottom-color: ${(props): string =>
      props.isActive && Colors.brightBlue};
   padding-bottom: 8px;
   margin-right: 47px;
   text-transform: uppercase;
`
