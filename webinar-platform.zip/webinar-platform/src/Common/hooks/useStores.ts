import { useContext } from 'react'
import { MobXProviderContext } from 'mobx-react'

import { ActiveWebinarsStore } from '../../ContentManagement/stores/ActiveWebinarsStore/ActiveWebinarsStore'

import NetworkTimerStore from '../stores/NetworkTimerStore'

export interface StoresTypes {
   activeWebinarsStore: ActiveWebinarsStore
   networkTimerStore: NetworkTimerStore
}

export function useStores(): StoresTypes {
   const stores = useContext(MobXProviderContext)
   const { activeWebinarsStore, networkTimerStore } = stores

   return {
      activeWebinarsStore,
      networkTimerStore
   }
}
