import React from 'react'
import {
   BrowserRouter as Router,
   Switch,
   Route,
   Redirect
} from 'react-router-dom'

import { AuthRoute } from '@ib/auth-sdk'
import {
   NOT_FOUND_PAGE_PATH,
   NOT_FOUND_PAGE,
   WEBINAR_PATH
} from '../constants/NavigationConstants'
import PageNotFound404 from '../../Common/components/PageNotFound404'
import userProfileRoutes from '../../UserProfile/routes'
import aug16WebinarRoutes from '../../ContentManagement/routes'

import { HomeScreenRoute } from '../../LiveWebinar/routes/HomeScreenRoute'
import Aug16WebinarRoute from '../../ContentManagement/routes/Aug16WebinarRoute'

import { STUDENT_AMBASSADOR_PATH } from '../../ContentManagement/constants/NavigationConstants'
import StudentAmbassadorRoute from '../../LiveWebinar/routes/StudentAmbassadorRoute'
import DynamicWebinarsDetails from '../../ContentManagement/stores/models/DynamicWebinarsDetails'
import DynamicWebinarsDashboardRoute from '../../LiveWebinar/routes/DynamicWebinarsDashboardRoute'

import { withProfile } from '../hocs/withProfile'
import { ReactRoute } from '../utils/RouteUtils'
import { getPathByAttachingQueryParams } from '../utils/NavigationUtils'

function getDynamicSSOWebinarsRoutes(
   dynamicRoutes: Array<DynamicWebinarsDetails>
) {
   const ssoWebinarRoutes: any = []
   const routes = [...dynamicRoutes]
   routes.sort(function(eachRoute) {
      if (eachRoute.ssoRequired) return -1
      else if (!eachRoute.ssoRequired) return 1
      return 0
   })

   routes.forEach(eachRoute => {
      if (eachRoute.ssoRequired && eachRoute.isActive) {
         ssoWebinarRoutes.push(
            <AuthRoute
               exact
               path={eachRoute.path}
               component={withProfile(DynamicWebinarsDashboardRoute)}
               routeComponent={Route}
            />
         )
      } else if (!eachRoute.ssoRequired && eachRoute.isActive) {
         ssoWebinarRoutes.push(
            <ReactRoute
               exact
               path={eachRoute.path}
               key={eachRoute.localId}
               component={DynamicWebinarsDashboardRoute}
            />
         )
      }
   })
   return ssoWebinarRoutes
}

export const routes = dynamicRoutes => (
   <Router>
      <Switch>
         <Redirect
            from='/:url*(/+)'
            to={getPathByAttachingQueryParams(
               window.location.pathname.slice(0, -1)
            )}
         />
         {userProfileRoutes}

         <AuthRoute
            exact
            path={STUDENT_AMBASSADOR_PATH}
            component={StudentAmbassadorRoute}
            routeComponent={Route}
         />
         <AuthRoute
            path={WEBINAR_PATH}
            component={withProfile(Aug16WebinarRoute)}
            routeComponent={Route}
         />

         {getDynamicSSOWebinarsRoutes(dynamicRoutes)}
         {aug16WebinarRoutes}
         <Route path='/' component={HomeScreenRoute} />
         <Route
            path={NOT_FOUND_PAGE_PATH}
            key={NOT_FOUND_PAGE}
            component={PageNotFound404}
         />
      </Switch>
   </Router>
)
