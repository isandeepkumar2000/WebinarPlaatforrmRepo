import styled from 'styled-components'

export const CrashViewContainer = styled('div')`
   text-align: center;
   display: flex;
   flex-direction: column;
   align-items: center;
   justify-content: center;
   height: 100vh;
`

export const LoadingWrapper = styled.div`
   display: flex;
   justify-content: center;
   align-items: center;
   width: 100%;
   min-height: 100vh;
`
