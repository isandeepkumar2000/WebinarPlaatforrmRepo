import React, { Component } from 'react'
import { ToastContainer } from 'react-toastify'
import { Provider, observer } from 'mobx-react'
import { init } from '@ib/auth-sdk'
import { ThemeProvider } from 'styled-components'
import {
   I18nextProvider,
   //eslint-disable-next-line
   WithTranslation,
   withTranslation
   //eslint-disable-next-line
} from 'react-i18next'
import { observable } from 'mobx'
import * as firebase from 'firebase/app'
import 'firebase/database'

import {
   captureSentryException,
   initializeSentry
} from '../../utils/SentryUtils'
import { getAllQueryParams } from '../../utils/RouteUtils'
import i18n from '../../i18n'
import stores, { themeStore } from '../../stores'

import FailureView from '../../components/LoadingWrapper/FailureView'
import Config from '../../constants/EnvironmentConstants'

import Routes from '../index'

import { initializeGoogleTracker } from '../../utils/GoogleAnalyticsUtils'
import {
   initializeLogEntries,
   captureLogEntriesExceptionWithScope,
   sendLogEntriesObjectData
} from '../../utils/LogEntriesUtils'
import { getUserAgentObject } from '../../utils/DeviceUtils'
import { themes } from '../../themes/Colors'
import { getAccessToken } from '../../../UserProfile/utils/StorageUtils'
import RefreshTokenReactionComponent from '../../components/ReactionsComponent/RefreshTokenReactionComponent'
import { initializeFacebookPixelAnalytics } from '../../utils/FbPixelAnalyticsUtils'
import { initializeLinkedInAnalytics } from '../../utils/LinkedInAnalyticsUtils'
import {
   logEntriesTypes,
   LogEntryPriorityEnum
} from '../../constants/LogEntriesConstants'

import { isProdEnvironment } from '../../utils/EnvironmentUtils'
import LoadingView from '../../components/LoadingWrapperWithFailure/LoadingView'
import LoadingWrapperWithFailure from '../../components/LoadingWrapperWithFailure'

import { CrashViewContainer, LoadingWrapper } from './styledComponents'

initializeSentry()
initializeLogEntries()
interface Props extends WithTranslation {
   children?: any
}

@observer
class App extends Component<Props> {
   @observable error

   constructor(props) {
      super(props)
      this.initFirebase()
      this.error = null
      const { t } = this.props
      const { authStore } = stores
      const { backgroundColor } = themeStore
      init({
         clientId: Config.ACCOUNTS_CLIENT_ID,
         baseUrl: Config.AUTH_SDK_BASE_URL,
         mode: 'otp',
         onAuthCodeReceived: authStore.loginWithAuthCodeAPI,
         getAccessToken: getAccessToken,
         onLoginStatusChanged: () => {},
         login: authStore.loginWithAuthCodeAPI,
         onLogout: () => Promise.resolve(),
         errorView: () => (
            <LoadingWrapper>
               <FailureView
                  failureText={t('common.fallbackUI.failureText')}
                  onRetry={this.onClickRetry}
               />
            </LoadingWrapper>
         ),
         loadingView: () => <LoadingView backgroundColor={backgroundColor} />
      })
      if (isProdEnvironment()) {
         initializeFacebookPixelAnalytics()
         initializeLinkedInAnalytics()
      }
   }

   componentDidMount() {
      const { activeWebinarsStore } = stores
      sendLogEntriesObjectData(getUserAgentObject())
      try {
         const queryParams = getAllQueryParams(window.location.search)
         activeWebinarsStore.setAdditionalInformation(queryParams)
      } catch (error) {
         console.log(error)
      }
      this.getNetworkTime()
   }

   initFirebase = () => {
      const config = {
         apiKey: process.env.REACT_APP_FIREBASE_API_KEY,
         authDomain: process.env.REACT_APP_FIREBASE_AUTH_DOMAIN,
         databaseURL: process.env.REACT_APP_FIREBASE_DATABASE_URL,
         projectId: process.env.REACT_APP_FIREBASE_PROJECT_ID,
         storageBucket: process.env.REACT_APP_FIREBASE_STORAGE_BUCKET,
         messagingSenderId: process.env.REACT_APP_FIREBASE_MESSAGING_SENDER_ID,
         appId: process.env.REACT_APP_FIREBASE_APP_ID
      }
      if (firebase.apps.length <= 0) {
         return firebase.initializeApp(config)
      }
   }
   //NOTE: Didnt removed this comments for future use of this code
   // componentDidMount() {
   //    const isPreviousUser = isIdentifiedUser()
   //    if (isPreviousUser) {
   //       const submitUserDetailsRequest = {
   //          name: getUsername(),
   //          phone_number: getMobileNumber()
   //       }
   //       stores.userDetailsStore.submitUserDetails(
   //          submitUserDetailsRequest as UserDetailsRequest,
   //          () => {},
   //          () => {}
   //       )
   //    }
   // }

   componentDidCatch(error, errorInfo) {
      this.setError(error)
      captureSentryException(error, errorInfo)
      captureLogEntriesExceptionWithScope(
         'APP_CRASHED',
         error,
         logEntriesTypes.errors,
         LogEntryPriorityEnum.MEDIUM
      )
   }

   getNetworkTime = () => {
      const {
         networkTimerStore: { getCurrentNetworkDateTimeAPI }
      } = stores
      getCurrentNetworkDateTimeAPI()
   }

   setError = (error): void => {
      this.error = error
   }

   onClickRetry = (): void => {
      window.history.back()
      setTimeout(() => {
         window.location.reload()
      }, 500)
   }

   UNSAFE_componentWillMount() {
      initializeGoogleTracker()
   }

   renderSuccessUI = (): React.ReactNode => <Routes />

   renderRoutes = (): React.ReactNode => {
      const {
         networkTimerStore: {
            getCurrentNetworkDateTimeAPIError,
            getCurrentNetworkDateTimeAPIStatus
         }
      } = stores
      return (
         <LoadingWrapperWithFailure
            apiStatus={getCurrentNetworkDateTimeAPIStatus}
            apiError={getCurrentNetworkDateTimeAPIError}
            onRetryClick={this.getNetworkTime}
            renderSuccessUI={this.renderSuccessUI}
         />
      )
   }

   render(): React.ReactNode {
      const { t } = this.props
      const selectedTheme = themeStore.selectedTheme

      if (this.error) {
         return (
            <CrashViewContainer>
               <ThemeProvider theme={themes[selectedTheme]}>
                  <FailureView
                     failureText={t('common.fallbackUI.failureText')}
                     onRetry={this.onClickRetry}
                  />
               </ThemeProvider>
            </CrashViewContainer>
         )
      }
      return (
         <Provider {...stores} themeStore={themeStore}>
            <I18nextProvider i18n={i18n}>
               <RefreshTokenReactionComponent />
               <ThemeProvider theme={themes[selectedTheme]}>
                  {this.renderRoutes()}
               </ThemeProvider>
               <ToastContainer
                  position='top-right'
                  autoClose={1000}
                  hideProgressBar={true}
                  newestOnTop={true}
                  closeOnClick
                  rtl={false}
                  draggable
                  pauseOnHover
               />
            </I18nextProvider>
         </Provider>
      )
   }
}

export default withTranslation()(App)
