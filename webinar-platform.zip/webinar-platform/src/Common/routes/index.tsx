import React, { Component } from 'react'
import { inject, observer } from 'mobx-react'
import hoistStatics from 'hoist-non-react-statics'

import { ActiveWebinarsStore } from '../../ContentManagement/stores/ActiveWebinarsStore/ActiveWebinarsStore'
import withActiveWebinar from '../hocs/WithActiveWebinar'
import { routes } from './config'

interface Props {}

interface InjectedProps extends Props {
   activeWebinarsStore: ActiveWebinarsStore
}

@inject('activeWebinarsStore')
@observer
class Routes extends Component<Props> {
   getInjectedProps = (): InjectedProps => this.props as InjectedProps

   getActiveWebinarsStore = () => this.getInjectedProps().activeWebinarsStore
   render() {
      const { dynamicRoutes } = this.getActiveWebinarsStore()
      return <div>{routes(dynamicRoutes)}</div>
   }
}

export default hoistStatics(withActiveWebinar(Routes), Routes)
