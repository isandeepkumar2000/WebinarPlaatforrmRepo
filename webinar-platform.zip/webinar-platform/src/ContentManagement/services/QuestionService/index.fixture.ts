import { resolveWithTimeout } from '../../../Common/utils/TestUtils'

import { SubmitRequestObjectType } from '../../stores/types'
import listenToActiveQuestion from '../../fixtures/getQuestionDetails.json'

import QuestionService from '.'

class QuestionFixture implements QuestionService {
   getQuestion() {
      return resolveWithTimeout(listenToActiveQuestion)
   }

   submitQuestionAnswer(requestObject: SubmitRequestObjectType) {
      return resolveWithTimeout({})
   }
}

export default QuestionFixture
