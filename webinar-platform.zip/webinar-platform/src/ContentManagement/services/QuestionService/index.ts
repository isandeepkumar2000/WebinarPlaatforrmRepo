import { QuestionType, SubmitRequestObjectType } from '../../stores/types'

interface QuestionService {
   getQuestion: () => Promise<Array<QuestionType>>

   submitQuestionAnswer: (requestObject: SubmitRequestObjectType) => Promise<{}>
}

export default QuestionService
