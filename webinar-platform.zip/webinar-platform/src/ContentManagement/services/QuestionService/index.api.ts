import { create } from 'apisauce'

import { apiMethods } from '../../../Common/constants/APIConstants'
import Config from '../../../Common/constants/EnvironmentConstants'

import { SubmitRequestObjectType } from '../../stores/types'

import endpoints from '../endpoints'

import QuestionService from '.'

const AUTH_URL = `${Config.BASE_URL}/` //Need to change
const SUBMIT_URL = `${Config.SUBMIT_BASE_URL}/`

class QuestionAPI implements QuestionService {
   api: Record<string, any>
   networkCallWithAPISauce: Function
   submitAPI: Record<string, any>
   constructor(networkCallWithAPISauce: Function) {
      this.api = create({ baseURL: AUTH_URL })
      this.submitAPI = create({ baseURL: SUBMIT_URL })
      this.networkCallWithAPISauce = networkCallWithAPISauce
   }

   getQuestion() {
      return this.networkCallWithAPISauce(
         this.api,
         endpoints.questions,
         {},
         apiMethods.get
      )
   }

   submitQuestionAnswer(requestObject: SubmitRequestObjectType) {
      return this.networkCallWithAPISauce(
         this.submitAPI,
         endpoints.submitQuestionAnswer,
         requestObject,
         apiMethods.post
      )
   }
}

export default QuestionAPI
