import { resolveWithTimeout } from '../../../Common/utils/TestUtils'

import activeWebinarsList from '../../fixtures/activeWebinars.json'

import {
   GetWebinarsConfigDetailsAPIRequest,
   GetWebinarsConfigDetailsAPIResponse
} from '../../stores/types'
import ActiveWebinarsService from '.'

// FIXME: need to update the response json files

class ActiveWebinarsFixtureService implements ActiveWebinarsService {
   getActiveWebinarsAPI = () => resolveWithTimeout(activeWebinarsList as any)
   postUserActiveWebinarsPageAPI = requestObject =>
      resolveWithTimeout({} as any)
   webinarAttendeesAPI = requestObject => resolveWithTimeout({})

   userWebinarEventsAPI = requestObject => resolveWithTimeout({})

   getWebinarsConfigDetailsAPI = (
      requestObject: GetWebinarsConfigDetailsAPIRequest
   ): Promise<GetWebinarsConfigDetailsAPIResponse> => {
      const response = {
         user_webinars: requestObject.webinar_ids.map((id, index) => ({
            webinar_id: id,
            is_user_registered: index % 2 === 0
         }))
      }
      return resolveWithTimeout(response)
   }
}
export default ActiveWebinarsFixtureService
