import {
   ActiveWebinarsListObjectType,
   ActiveUserWebinarPageObjectType,
   GetWebinarsConfigDetailsAPIRequest,
   GetWebinarsConfigDetailsAPIResponse
} from '../../stores/types'

interface ActiveWebinarsService {
   getActiveWebinarsAPI: () => Promise<Array<ActiveWebinarsListObjectType>>

   // TODO: need to define type for `postUserActiveWebinarsPageAPI` requestObject and use the same type in `AttendeeModal Component`
   postUserActiveWebinarsPageAPI: (
      requestObject
   ) => Promise<Array<ActiveUserWebinarPageObjectType>>

   webinarAttendeesAPI: (requestObject) => Promise<{}>

   userWebinarEventsAPI: (requestObject) => Promise<{}>

   getWebinarsConfigDetailsAPI: (
      requestObject: GetWebinarsConfigDetailsAPIRequest
   ) => Promise<GetWebinarsConfigDetailsAPIResponse>
}

export default ActiveWebinarsService
