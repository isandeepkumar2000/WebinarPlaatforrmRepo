import { create } from 'apisauce'
import { action } from 'mobx'

import { apiMethods } from '../../../Common/constants/APIConstants'
import Config from '../../../Common/constants/EnvironmentConstants'
import { networkCallWithFetch } from '../../../Common/utils/APIUtils'
import { getAccessToken } from '../../../UserProfile/utils/StorageUtils'
import { getWebinarApiEndpointName } from '../../../Common/utils/WebinarClientUrlUtils'

import endpoints from '../endpoints'

import ActiveWebinarsService from '.'

const AUTH_URL = `${Config.BASE_URL}/`
const WEBINAR_CLIENT_URL = `${
   Config.WEBINAR_CLIENT_BASE_URL
}${getWebinarApiEndpointName()}`

const WEBINARS_JSON_URL = `${Config.WEBINARS_BASE_URL}`

class ActiveWebinarsAPI implements ActiveWebinarsService {
   networkCallWithApiSauce

   api: Record<string, any>
   webinarAPI: Record<string, any>

   constructor(networkCallWithApiSauce) {
      this.api = create({ baseURL: AUTH_URL })
      this.webinarAPI = create({ baseURL: WEBINAR_CLIENT_URL })

      this.networkCallWithApiSauce = networkCallWithApiSauce
   }

   getActiveWebinarsAPI() {
      const uniqueId = Date.now()

      return networkCallWithFetch(
         `${WEBINARS_JSON_URL}?time=${uniqueId}`
      ) as any
   }

   postUserActiveWebinarsPageAPI(requestObject) {
      return this.networkCallWithApiSauce(
         this.api,
         endpoints.userActiveWebinarPage,
         requestObject,
         apiMethods.post,
         { getAccessToken: getAccessToken },
         false
      )
   }

   webinarAttendeesAPI(requestObject) {
      return this.networkCallWithApiSauce(
         this.webinarAPI,
         endpoints.webinarAttendeeSubmissions,
         requestObject,
         apiMethods.post,
         { getAccessToken: getAccessToken },
         true
      )
   }

   userWebinarEventsAPI(requestObject) {
      return this.networkCallWithApiSauce(
         this.api,
         endpoints.userWebinarEvents,
         requestObject,
         apiMethods.post,
         { getAccessToken: getAccessToken },
         false
      )
   }

   @action.bound
   getWebinarsConfigDetailsAPI(requestObject) {
      return this.networkCallWithApiSauce(
         this.webinarAPI,
         endpoints.getWebinarsConfigDetails,
         requestObject,
         apiMethods.post,
         { getAccessToken: getAccessToken },
         true
      )
   }
}

export default ActiveWebinarsAPI
