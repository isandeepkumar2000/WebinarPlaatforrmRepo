const endpoints = {
   questions: 'questions/v1/',
   submitQuestionAnswer: 'submissions/',
   userActiveWebinarPage: 'webinar/attendees/v1/',
   webinarAttendeeSubmissions: 'create_ib_form_submission/v1/',
   getNetworkTime: 'network_time/',

   // NOTE: webinar_core
   getWebinarsConfigDetails: 'user/webinars/v1/',
   userWebinarEvents: 'user/webinar/event/v1/'
}

export default endpoints
