import { NetworkTimeObjectType } from '../../stores/types'

interface NetworkTimeService {
   getCurrentNetworkDateTimeAPI: () => Promise<NetworkTimeObjectType>
}

export default NetworkTimeService
