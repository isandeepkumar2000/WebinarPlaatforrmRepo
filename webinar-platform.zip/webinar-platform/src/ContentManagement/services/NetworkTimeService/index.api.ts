import { create } from 'apisauce'

import { apiMethods } from '../../../Common/constants/APIConstants'
import Config from '../../../Common/constants/EnvironmentConstants'

import { NetworkTimeObjectType } from '../../stores/types'

import endpoints from '../endpoints'

import NetworkTimeService from '.'

const NETWORK_TIME_URL = `${Config.NETWORK_TIME_BASE_URL}/`

class NetworkTimeAPI implements NetworkTimeService {
   api: Record<string, any>
   networkCallWithApiSauce

   constructor(networkCallWithApiSauce) {
      this.api = create({ baseURL: NETWORK_TIME_URL })
      this.networkCallWithApiSauce = networkCallWithApiSauce
   }

   getCurrentNetworkDateTimeAPI(): Promise<NetworkTimeObjectType> {
      return this.networkCallWithApiSauce(
         this.api,
         endpoints.getNetworkTime,
         {},
         apiMethods.get
      )
   }
}

export default NetworkTimeAPI
