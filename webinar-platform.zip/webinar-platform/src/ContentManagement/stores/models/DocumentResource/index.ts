import { DocumentResourceType } from '../../types'

import BaseResource from '../BaseResource'

class DocumentResource extends BaseResource {
   documentURL

   constructor(resource: DocumentResourceType) {
      const { document_url: documentURL, ...resourceDetails } = resource
      super(resourceDetails)
      this.documentURL = documentURL
   }
}

export default DocumentResource
