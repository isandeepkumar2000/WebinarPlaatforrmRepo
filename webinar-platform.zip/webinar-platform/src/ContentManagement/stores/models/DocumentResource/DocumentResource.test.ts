import DocumentResource from '.'

const resource = {
   title: 'This is title',
   description: 'This is description',
   resource_type: 'This is resourceType',
   document_url: 'https://sample.mp4'
}

describe('DocumentResource model test cases', () => {
   it('should initialize resource details in the constructor', () => {
      const documentResource = new DocumentResource(resource)
      expect(documentResource.title).toBe(resource.title)
      expect(documentResource.description).toBe(resource.description)
      expect(documentResource.resourceType).toBe(resource.resource_type)
      expect(documentResource.documentURL).toBe(resource.document_url)
   })
})
