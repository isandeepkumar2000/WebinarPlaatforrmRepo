import { observable } from 'mobx'
import uuid from 'uuid'

class CtaDetails {
   @observable ctaButtonText!: string
   @observable ctaUrl!: string
   @observable ctaType!: string
   @observable buttonStyle!: string
   localUUID = uuid.v4()
   constructor(ctaDetails) {
      this.ctaButtonText = ctaDetails.button_text
      this.ctaUrl = ctaDetails.redirection_url
      this.ctaType = ctaDetails.type
      this.buttonStyle = ctaDetails.button_style
   }
}

export default CtaDetails
