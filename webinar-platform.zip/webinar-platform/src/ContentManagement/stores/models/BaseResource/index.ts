import { BaseResourceType } from '../../types'

class BaseResource {
   title: string
   description: string
   resourceType: string

   constructor(resource: BaseResourceType) {
      const { title, description, resource_type: resourceType } = resource
      this.title = title
      this.description = description
      this.resourceType = resourceType
   }
}

export default BaseResource
