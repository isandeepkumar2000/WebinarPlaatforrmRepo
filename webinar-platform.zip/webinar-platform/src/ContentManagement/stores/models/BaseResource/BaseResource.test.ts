import BaseResource from '.'

const resource = {
   title: 'This is title',
   description: 'This is description',
   resource_type: 'This is resourceType'
}

describe('BaseResource model test cases', () => {
   it('should initialize resource details in the constructor', () => {
      const baseResource = new BaseResource(resource)
      expect(baseResource.title).toBe(resource.title)
      expect(baseResource.description).toBe(resource.description)
      expect(baseResource.resourceType).toBe(resource.resource_type)
   })
})
