import { action, computed, observable } from 'mobx'
import uuid from 'uuid'

import { RouteDetailsType } from '../../types'
import BaseRouteDetails from '../BaseRouteDetails'
import Webinar from '../Webinar'

class DynamicWebinarsDetails extends BaseRouteDetails {
   @observable ssoWebinars!: Array<Webinar>
   localId!: string
   shouldShowExpandable: boolean
   service

   constructor(routeDetails: RouteDetailsType, webinars, service) {
      super(routeDetails)
      this.init()
      this.shouldShowExpandable = routeDetails.should_show_expandable
         ? routeDetails.should_show_expandable
         : false
      this.service = service
      this.ssoWebinars = webinars.map(
         webinar => new Webinar(webinar, this.service)
      )
   }

   @action.bound
   init() {
      this.localId = uuid.v4()
      this.ssoWebinars = []
   }

   @action.bound
   getActiveWebinar(webinarSlug: string) {
      const activeWebinar = this.ssoWebinars.find(
         eachWebinar => eachWebinar.webinarSlug === webinarSlug
      )
      return activeWebinar
   }

   @computed get ssoWebinarIdsList(): string[] {
      return this.ssoWebinars.map(({ webinarId }) => webinarId)
   }

   @action.bound
   getWebinarsWithGivenStatus(status: string): Webinar[] {
      return this.ssoWebinars.filter(
         webinar =>
            webinar.isEnded === false &&
            webinar.isHidden === false &&
            webinar.webinarStatus === status
      )
   }

   @action.bound
   getAllUniqueWebinarStatuses(): string[] {
      const activeWebinars = this.ssoWebinars.filter(
         webinar => webinar.isEnded === false && webinar.isHidden === false
      )
      const activeWebinarsStatuses = activeWebinars.map(
         webinar => webinar.webinarStatus
      )
      return [...new Set(activeWebinarsStatuses)]
   }
}

export default DynamicWebinarsDetails
