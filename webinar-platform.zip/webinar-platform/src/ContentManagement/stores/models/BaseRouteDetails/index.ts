import { action } from 'mobx'

import { webinarSectionTitleWithStatusList } from '../../../../Common/constants/BackendConstants'

import { RouteDetailsType } from '../../types'

import AnalyticsConfiguration from '../AnalyticsConfiguration'
import WebinarAccessConfiguration from '../WebinarAccessConfiguration'
import WebinarDashboardSectionDetailsModel from '../WebinarDashboardSectionDetailsModel'
import WhatsappDetailsModel from '../WhatsappDetailsModel'

class BaseRouteDetails {
   path!: string
   isActive!: boolean
   dataKey!: string
   ssoRequired
   accessibleProducts: string[]
   registrationLink: string
   accessConfiguration: WebinarAccessConfiguration | null
   showWhatsAppConsent: boolean
   pathRedirectionUrl: string
   analyticsConfig: AnalyticsConfiguration
   whatsappDetails?: WhatsappDetailsModel
   webinarDashboardSectionDetails: Array<WebinarDashboardSectionDetailsModel>

   constructor(routeDetails: RouteDetailsType) {
      const { whatsapp_details, dashboard_sections_info } = routeDetails
      this.path = routeDetails.path
      this.isActive = routeDetails.is_active
      this.dataKey = routeDetails.data_key
      this.ssoRequired = routeDetails.sso_required
      this.accessibleProducts = routeDetails.accessible_products ?? []
      this.registrationLink = routeDetails.registration_link ?? ''
      this.accessConfiguration = routeDetails.access_configuration
         ? new WebinarAccessConfiguration(routeDetails.access_configuration)
         : null
      this.showWhatsAppConsent =
         routeDetails.show_whatsapp_consent !== undefined
            ? routeDetails.show_whatsapp_consent
            : true
      this.analyticsConfig = new AnalyticsConfiguration(
         routeDetails.analytics_config
      )
      this.pathRedirectionUrl = routeDetails.path_redirection_url ?? ''
      if (whatsapp_details) {
         this.whatsappDetails = new WhatsappDetailsModel(whatsapp_details)
      }
      this.webinarDashboardSectionDetails = webinarSectionTitleWithStatusList.map(
         webinarSection =>
            new WebinarDashboardSectionDetailsModel(webinarSection)
      )

      if (dashboard_sections_info) {
         dashboard_sections_info.forEach(dashboardSection => {
            const dashboardSectionWithGivenStatus = this.webinarDashboardSectionDetails.find(
               section =>
                  section.webinarStatus === dashboardSection.webinar_status
            )

            if (dashboardSectionWithGivenStatus) {
               dashboardSectionWithGivenStatus.setSectionDetails(
                  dashboardSection
               )
            } else {
               this.webinarDashboardSectionDetails.push(
                  new WebinarDashboardSectionDetailsModel(dashboardSection)
               )
            }
         })
      }
   }

   @action.bound
   getDashboardSectionFromStatus(
      status: string
   ): WebinarDashboardSectionDetailsModel | undefined {
      return this.webinarDashboardSectionDetails.find(
         section => section.webinarStatus === status
      )
   }

   @action.bound
   getSectionTitleFromStatus(status: string): string {
      const dashboardSection = this.getDashboardSectionFromStatus(status)
      return dashboardSection ? dashboardSection.sectionTitle : status
   }

   @action.bound
   getIsSectionExpandedByDefault(status: string): boolean {
      const dashboardSection = this.getDashboardSectionFromStatus(status)
      return dashboardSection
         ? dashboardSection.isSectionExpandedByDefault
         : true
   }

   @action.bound
   getShouldShowWebinarsCountsFromStatus(status: string): boolean {
      const dashboardSection = this.getDashboardSectionFromStatus(status)
      return dashboardSection ? dashboardSection.shouldShowWebinarsCount : true
   }
}

export default BaseRouteDetails
