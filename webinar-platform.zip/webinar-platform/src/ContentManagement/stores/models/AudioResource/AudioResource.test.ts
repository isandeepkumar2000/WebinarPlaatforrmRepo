import AudioResource from '.'

const resource = {
   title: 'This is title',
   description: 'This is description',
   resource_type: 'This is resourceType',
   audio_url: 'https://sample.mp3'
}

describe('AudioResource model test cases', () => {
   it('should initialize resource details in the constructor', () => {
      const audioResource = new AudioResource(resource)
      expect(audioResource.title).toBe(resource.title)
      expect(audioResource.description).toBe(resource.description)
      expect(audioResource.resourceType).toBe(resource.resource_type)
      expect(audioResource.audioURL).toBe(resource.audio_url)
   })
})
