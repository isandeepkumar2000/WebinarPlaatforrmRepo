import { AudioResourceType } from '../../types'

import BaseResource from '../BaseResource'

class AudioResource extends BaseResource {
   audioURL

   constructor(resource: AudioResourceType) {
      const { audio_url: audioURL, ...resourceDetails } = resource
      super(resourceDetails)
      this.audioURL = audioURL
   }
}

export default AudioResource
