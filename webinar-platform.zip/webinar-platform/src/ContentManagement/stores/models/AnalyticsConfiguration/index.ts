import { action } from 'mobx'

import { AnalyticsConfigurationObject } from '../../types'

export default class AnalyticsConfiguration {
   serialNumber!: number
   shouldTrackEvents!: boolean
   shouldTrackPage!: boolean
   webinarCategory!: string

   constructor(analyticsConfiguration?: AnalyticsConfigurationObject) {
      this.init()
      if (analyticsConfiguration) this.initWithValues(analyticsConfiguration)
   }

   @action.bound
   init() {
      this.serialNumber = 0
      this.shouldTrackEvents = false
      this.shouldTrackPage = false
      this.webinarCategory = ''
   }

   @action.bound
   initWithValues(analyticsConfiguration: AnalyticsConfigurationObject) {
      const {
         should_track_events,
         should_track_page,
         track_event_properties
      } = analyticsConfiguration

      this.shouldTrackEvents = should_track_events ?? this.shouldTrackEvents
      this.shouldTrackPage = should_track_page ?? this.shouldTrackPage
      if (track_event_properties) {
         const { serial_number, webinar_category } = track_event_properties
         this.webinarCategory = webinar_category ?? this.webinarCategory
         this.serialNumber = serial_number ?? this.serialNumber
      }
   }
}
