import { videoQualityWithoutExtension } from '../../../../Common/components/Video/constants'
import { IbVideoConfig } from '../../types'

class IbVideoConfigModel {
   defaultDesktopResolution: string
   defaultMobileResolution: string

   constructor(ibVideoConfig: IbVideoConfig) {
      const { sevenTwenty, fourEighty } = videoQualityWithoutExtension
      this.defaultDesktopResolution = sevenTwenty
      this.defaultMobileResolution = fourEighty

      if (ibVideoConfig) {
         this.defaultDesktopResolution =
            ibVideoConfig.default_desktop_resolution ??
            this.defaultDesktopResolution
         this.defaultMobileResolution =
            ibVideoConfig.default_mobile_resolution ??
            this.defaultMobileResolution
      }
   }
}

export default IbVideoConfigModel
