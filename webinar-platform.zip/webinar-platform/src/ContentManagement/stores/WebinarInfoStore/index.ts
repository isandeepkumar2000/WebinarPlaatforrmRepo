import { WebinarInfoStore } from './WebinarInfoStore'
export default WebinarInfoStore
