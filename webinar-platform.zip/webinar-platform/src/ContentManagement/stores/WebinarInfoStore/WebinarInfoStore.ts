import { action, observable } from 'mobx'
import * as firebase from 'firebase/app'
import 'firebase/database'

import { captureLogEntriesExceptionWithScope } from '../../../Common/utils/LogEntriesUtils'
import { WEBINAR_INFO } from '../../../Common/constants/FireBaseConstants'
import {
   logEntriesTypes,
   LogEntryPriorityEnum
} from '../../../Common/constants/LogEntriesConstants'
import { captureError } from '../../../Common/utils/DecoratorLogEntriesUtils'

class WebinarInfoStore {
   @observable isEnableLiveInteraction!: boolean
   @observable youTubeId
   @observable webinarStartTime
   @observable webinarInfoError!: Error | null
   constructor() {
      this.init()
   }
   @action.bound
   init() {
      this.isEnableLiveInteraction = false
      this.youTubeId = null
      this.webinarInfoError = null
   }
   listenToWebinarInfo() {
      firebase
         .database()
         .ref(`${WEBINAR_INFO}`)
         .on(
            'value',
            snapshot => {
               if (snapshot.val() !== null) {
                  this.setWebinarInfoResponse(snapshot.val())
               } else {
                  this.isEnableLiveInteraction = false
                  this.youTubeId = null
               }
            },
            error => {
               captureLogEntriesExceptionWithScope(
                  'FIREBASE_WEBINAR_INFO',
                  error,
                  logEntriesTypes.errors,
                  LogEntryPriorityEnum.MEDIUM
               )
               this.setWebinarResponseError(error)
            }
         )
   }
   @action.bound
   setWebinarInfoResponse(response) {
      this.isEnableLiveInteraction = response.enable_live_interaction
      this.youTubeId = response.youtube_id
      this.webinarStartTime = response.webinar_start_time
   }

   @action.bound
   @captureError('listenToWebinarInfoAPI')
   setWebinarResponseError(error) {
      this.webinarInfoError = error
   }
   @action.bound
   setYouTubeId(youTubeId) {
      this.youTubeId = youTubeId
   }
   @action.bound
   clearStore() {
      this.init()
   }
}
export { WebinarInfoStore }
