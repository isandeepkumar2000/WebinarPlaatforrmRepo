import React from 'react'
import { ActiveWebinarsStore } from './ActiveWebinarsStore'
import { Webinar } from '../models/Webinar/Webinar'
import ActiveWebinarsFixtureService from '../../services/ActiveWebinarsService/index.fixtures'
import IbEventsFixture from '../../../Common/services/IbEventsService/index.fixture'
import QuestionFixture from '../../services/QuestionService/index.fixture'
import * as apiConstants from '@ib/api-constants'
import DynamicWebinarsDetails from '../models/DynamicWebinarsDetails'
import WebinarConfigModel from '../models/WebinarConfigModel/index'
import {
   GetWebinarsConfigDetailsAPIResponse,
   WebinarConfigObject
} from '../types'

// instance of ActiveWebinarsStore

const webinarServices = new ActiveWebinarsFixtureService()
const ibEventsAPIService = new IbEventsFixture()
const questionService = new QuestionFixture()

// instance of ActiveWebinarsStore storing in Variable activeWebinarStore

const activeWebinarStore = new ActiveWebinarsStore(
   webinarServices,
   ibEventsAPIService,
   questionService
)

describe('ActiveWebinarStore Test Cases', () => {
   describe('Meeting From the Webinar Id', () => {
      it('Checking the Meeting From the Webinar Id', () => {
         activeWebinarStore.studentAmbassadorWebinars = [
            { webinarId: '123' },
            { webinarId: '456' },
            { webinarId: '789' }
         ]
         const isWebinar = activeWebinarStore.getIsStudentAmbassadorWebinar(
            '123'
         )
         expect(isWebinar).toBe(true)
         const isNotWebinar = activeWebinarStore.getIsStudentAmbassadorWebinar(
            '9998'
         )
         expect(isNotWebinar).toBe(false)
      })
   })

   describe('isAllStoredWebinarsEnded', () => {
      it('returns true when there are no remind me webinars', () => {
         activeWebinarStore.remindMeWebinars = []
         const result = activeWebinarStore.isAllStoredWebinarsEnded()
         expect(result).toBe(true)
      })
      it('returns false when there are remind me webinars and some are not ended', () => {
         activeWebinarStore.remindMeWebinars = ['webinar-1', 'webinar-2']
         activeWebinarStore.activeWebinarsList = [
            new Webinar(
               { webinarId: 'webinar-1', isEnded: true },
               questionService
            ),
            { webinarId: 'webinar-2', isEnded: false }
         ]
         const result = activeWebinarStore.isAllStoredWebinarsEnded()
         expect(result).toBe(false)
      })
      it('returns true when there are remind me webinars and all are ended', () => {
         activeWebinarStore.remindMeWebinars = ['webinar-1', 'webinar-2']
         activeWebinarStore.activeWebinarsList = [
            new Webinar(
               { webinarId: 'webinar-1', isEnded: true },
               questionService
            )
         ]
         const result = activeWebinarStore.isAllStoredWebinarsEnded()
         expect(result).toBe(true)
      })
   })

   describe('onSelectOption', () => {
      it("should add the value to remindMeWebinars if it doesn't exist, and remove it if it does", () => {
         const activeWebinarStore = new ActiveWebinarsStore(
            webinarServices,
            ibEventsAPIService,
            questionService
         )
         activeWebinarStore.remindMeWebinars = ['webinar1', 'webinar2']
         activeWebinarStore.onSelectOption('webinar3')
         expect(activeWebinarStore.remindMeWebinars).toEqual([
            'webinar1',
            'webinar2',
            'webinar3'
         ])
         activeWebinarStore.onSelectOption('webinar2')
         expect(activeWebinarStore.remindMeWebinars).toEqual([
            'webinar1',
            'webinar3'
         ])
      })
   })

   describe('ActiveWebinarsStore', () => {
      let activeWebinarStore: ActiveWebinarsStore
      beforeEach(() => {
         activeWebinarStore = new ActiveWebinarsStore(
            webinarServices,
            ibEventsAPIService,
            questionService
         )
      })
      it('sets activeWebinarId to user active webinar id if activeSlug is set', () => {
         activeWebinarStore.activeSlug = 'webinar-slug'
         const mockWebinar = new Webinar(
            {
               webinarSlug: 'webinar-slug',
               webinarId: 'webinar-id'
            },
            questionService
         )
         jest
            .spyOn(activeWebinarStore, 'getUserActiveWebinarId')
            .mockReturnValue(mockWebinar.webinarId)
         jest
            .spyOn(activeWebinarStore, 'getActiveWebinar')
            .mockReturnValue(mockWebinar)
         activeWebinarStore.setActiveWebinarId()
         expect(activeWebinarStore.activeWebinarId).toBe(mockWebinar.webinarId)
      })

      it('sets activeWebinarId to defaultWebinarId if activeSlug is not set but defaultWebinarId is set', () => {
         activeWebinarStore.defaultWebinarId = 'default-webinar-id'
         activeWebinarStore.setActiveWebinarId()
         expect(activeWebinarStore.activeWebinarId).toBe(
            activeWebinarStore.defaultWebinarId
         )
      })
      it('sets activeWebinarId to null if activeSlug and defaultWebinarId are not set', () => {
         activeWebinarStore.setActiveWebinarId()
         expect(activeWebinarStore.activeWebinarId).toBeNull()
      })
   })

   describe('setActiveWebinarsAPIResponse', () => {
      it('should update the store with the provided API response', () => {
         const response = {
            webinars: [
               { id: '1', title: 'Webinar 1' },
               { id: '2', title: 'Webinar 2' }
            ],
            routes: [
               {
                  data_key: 'sso_webinars',
                  display_text: 'SSO Webinars',
                  should_show_expandable: true,
                  should_show_on_homepage: true,
                  slug: 'sso-webinars'
               }
            ],
            default_webinar: '1',
            student_ambassador_webinars: [
               { webinar_id: '3', title: 'Webinar 3' }
            ],
            show_announcement: true,
            form_footer_note: 'This is a form footer note.',
            fallback_cdn_urls: [
               'https://example.com/cdn1',
               'https://example.com/cdn2'
            ],
            c_meet_redirection_url: 'https://example.com/cmeet',
            home_page_redirection_url: 'https://example.com/home',
            maintenance_config: {
               startDateTime: '2023-05-01T00:00:00Z',
               endDateTime: '2023-05-01T02:00:00Z'
            }
         }

         activeWebinarStore.setActiveWebinarsAPIResponse(response)

         expect(activeWebinarStore.dynamicRoutes.length).toBe(1)
         expect(activeWebinarStore.dynamicRoutes[0].dataKey).toBe(
            'sso_webinars'
         )
         expect(activeWebinarStore.dynamicRoutes[0].shouldShowExpandable).toBe(
            true
         )
         expect(activeWebinarStore.defaultWebinarId).toBe('1')
         expect(activeWebinarStore.studentAmbassadorWebinars.length).toBe(1)
         expect(activeWebinarStore.studentAmbassadorWebinars[0].webinarId).toBe(
            '3'
         )
         expect(activeWebinarStore.showAnnouncementInNoWebinarScreen).toBe(true)
         expect(activeWebinarStore.formFooterNote).toBe(
            'This is a form footer note.'
         )
         expect(activeWebinarStore.fallBackUrls.length).toBe(2)
         expect(activeWebinarStore.communityMeetRedirectionUrl).toBe(
            'https://example.com/cmeet'
         )
         expect(activeWebinarStore.homePageRedirectionUrl).toBe(
            'https://example.com/home'
         )
         expect(activeWebinarStore.maintenanceConfig).not.toBeNull()
      })
   })

   describe('getActiveWebinarsAPI', () => {
      it('should call setActiveWebinarsAPIResponse with the response data on success', async () => {
         const mockResponse = { data: { webinars: [] } }
         const webinarServices = {
            getActiveWebinarsAPI: jest.fn().mockResolvedValue(mockResponse)
         }
         const activeWebinarStore = new ActiveWebinarsStore(
            webinarServices,
            ibEventsAPIService,
            questionService
         )
         const setActiveWebinarsAPIResponse = jest.spyOn(
            activeWebinarStore,
            'setActiveWebinarsAPIResponse'
         )
         await activeWebinarStore.getActiveWebinarsAPI()
         expect(setActiveWebinarsAPIResponse).toHaveBeenCalledWith(mockResponse)
      })
      it('should call setActiveWebinarsAPIError with the error on failure', async () => {
         const errorMessage = 'An error occurred'
         const mockError = new Error(errorMessage)
         const webinarServices = {
            getActiveWebinarsAPI: jest.fn().mockRejectedValue(mockError)
         }
         const activeWebinarStore = new ActiveWebinarsStore(
            webinarServices,
            ibEventsAPIService,
            questionService
         )
         const setActiveWebinarsAPIError = jest.spyOn(
            activeWebinarStore,
            'setActiveWebinarsAPIError'
         )
         await activeWebinarStore.getActiveWebinarsAPI()
         expect(setActiveWebinarsAPIError).toHaveBeenCalledWith(errorMessage)
      })
   })

   describe('setCurrentNetworkDateTimeAPIStatus', () => {
      it('should set the currentNetworkDateTimeAPIStatus to the given value', () => {
         activeWebinarStore.setCurrentNetworkDateTimeAPIStatus(
            apiConstants.API_INITIAL
         )
         expect(activeWebinarStore.getCurrentNetworkDateTimeAPIStatus).toBe(
            apiConstants.API_INITIAL
         )
      })
   })

   describe('setUserActiveWebinarsPageAPIResponse', () => {
      it('should set the userActiveWebinarsPageAPIResponse', () => {
         const activeWebinarStore = new ActiveWebinarsStore(
            webinarServices,
            ibEventsAPIService,
            questionService
         )
         const response = [{ id: '1', title: 'Webinar 1' }]
         activeWebinarStore.setUserActiveWebinarsPageAPIResponse(response)
         expect(activeWebinarStore.userActiveWebinarsPageAPIResponse).toEqual(
            response
         )
      })
   })

   describe('webinarAttendeesAPI', () => {
      it('should return a promise that resolves with attendee webinars data', async () => {
         const requestObject = { webinarId: '12345' }
         const attendeeWebinarsData = { mockData: true }
         const webinarsServiceMock = {
            webinarAttendeesAPI: jest
               .fn()
               .mockResolvedValue(attendeeWebinarsData)
         }
         const activeWebinarStore = new ActiveWebinarsStore(
            webinarsServiceMock,
            ibEventsAPIService,
            questionService
         )
         const resultPromise = activeWebinarStore.webinarAttendeesAPI(
            requestObject
         )
         await expect(resultPromise).resolves.toEqual(attendeeWebinarsData)
         expect(webinarsServiceMock.webinarAttendeesAPI).toHaveBeenCalledWith(
            requestObject
         )
      })
      it('should call onSuccess callback when promise is resolved', async () => {
         const requestObject = { webinarId: '12345' }
         const attendeeWebinarsData = { mockData: true }
         const webinarsServiceMock = {
            webinarAttendeesAPI: jest
               .fn()
               .mockResolvedValue(attendeeWebinarsData)
         }
         const onSuccessMock = jest.fn()
         const activeWebinarStore = new ActiveWebinarsStore(
            webinarsServiceMock,
            ibEventsAPIService,
            questionService
         )
         const resultPromise = activeWebinarStore.webinarAttendeesAPI(
            requestObject,
            onSuccessMock,
            undefined
         )
         await expect(resultPromise).resolves.toEqual(attendeeWebinarsData)
         expect(onSuccessMock).toHaveBeenCalled()
      })
   })

   describe('userWebinarEventsAPI', () => {
      it('should call onSuccess callback when promise is resolved', async () => {
         const requestObject = { userId: '12345' }
         const userWebinarEventsData = { mockData: true }
         const webinarsServiceMock = {
            userWebinarEventsAPI: jest
               .fn()
               .mockResolvedValue(userWebinarEventsData)
         }
         const onSuccessMock = jest.fn()
         const activeWebinarStore = new ActiveWebinarsStore(
            webinarsServiceMock,
            ibEventsAPIService,
            questionService
         )
         const resultPromise = activeWebinarStore.userWebinarEventsAPI(
            requestObject,
            onSuccessMock
         )
         await expect(resultPromise).resolves.toEqual(userWebinarEventsData)
         expect(onSuccessMock).toHaveBeenCalled()
      })
   })

   describe('onAddActiveWebinars', () => {
      it('should set activeWebinarsList property to an array of Webinar instances', () => {
         const mockResponse = [
            { id: 1, title: 'Webinar 1', description: 'Description 1' },
            { id: 2, title: 'Webinar 2', description: 'Description 2' }
         ]
         const activeWebinarStore = new ActiveWebinarsStore(
            webinarServices,
            ibEventsAPIService,
            { getQuestionsForWebinar: jest.fn() }
         )
         activeWebinarStore.onAddActiveWebinars(mockResponse)
         expect(activeWebinarStore.activeWebinarsList).toHaveLength(2)
         mockResponse.forEach((webinar, index) => {
            expect(activeWebinarStore.activeWebinarsList[index]).toBeInstanceOf(
               Webinar
            )
            expect(activeWebinarStore.activeWebinarsList[index]).not.toBe(
               webinar.id
            )
            expect(activeWebinarStore.activeWebinarsList[index].title).toBe(
               webinar.title
            )
            expect(
               activeWebinarStore.activeWebinarsList[index].description
            ).toBe(webinar.description)
         })
      })
   })

   describe('getActiveWebinarSlug', () => {
      const activeWebinar: any = {
         webinarId: 'webinar-1',
         webinarSlug: 'webinar-1-slug'
      }
      const studentAmbassadorWebinar: any = {
         webinarId: 'webinar-2',
         webinarSlug: 'webinar-2-slug'
      }
      const activeWebinarStore = new ActiveWebinarsStore(
         webinarServices,
         ibEventsAPIService,
         questionService
      )

      beforeEach(() => {
         activeWebinarStore.activeWebinarsList = [activeWebinar]
         activeWebinarStore.studentAmbassadorWebinars = [
            studentAmbassadorWebinar
         ]
      })
      it('returns the correct webinar slug when the webinar is in activeWebinarsList', () => {
         expect(activeWebinarStore.getActiveWebinarSlug('webinar-1')).toBe(
            'webinar-1-slug'
         )
      })
      it('returns the correct webinar slug when the webinar is in studentAmbassadorWebinars', () => {
         expect(activeWebinarStore.getActiveWebinarSlug('webinar-2')).toBe(
            'webinar-2-slug'
         )
      })
      it('returns undefined when the webinar is not found in either activeWebinarsList or studentAmbassadorWebinars', () => {
         expect(
            activeWebinarStore.getActiveWebinarSlug('webinar-3')
         ).toBeUndefined()
      })
   })

   describe('getUserActiveWebinarId', (): void => {
      it('should return the webinarId of the active webinar with the given slug', (): void => {
         const activeWebinarStore: ActiveWebinarsStore = new ActiveWebinarsStore(
            webinarServices,
            ibEventsAPIService,
            questionService
         )

         activeWebinarStore.activeWebinarsList = [
            {
               webinarId: 'webinarId1',
               webinarSlug: 'webinar-slug-1'
            }
         ]
         const webinarId:
            | string
            | undefined = activeWebinarStore.getUserActiveWebinarId(
            'webinar-slug-1'
         )

         expect(webinarId).toBe('webinarId1')
      })
   })

   describe('getUserActiveWebinarYoutube', () => {
      it('returns the correct YouTube ID for a given active webinar slug', () => {
         const activeWebinarsStore = new ActiveWebinarsStore(
            webinarServices,
            ibEventsAPIService,
            questionService
         )
         activeWebinarsStore.activeWebinarsList = [
            { webinarSlug: 'webinar-1', youTubeId: '1234' },
            { webinarSlug: 'webinar-2', youTubeId: '5678' }
         ]
         expect(
            activeWebinarsStore.getActiveWebinarYouTubeId('webinar-1')
         ).toBe('1234')
         expect(
            activeWebinarsStore.getActiveWebinarYouTubeId('webinar-2')
         ).toBe('5678')
         expect(
            activeWebinarsStore.getActiveWebinarYouTubeId('webinar-3')
         ).toBeUndefined()
      })
   })
   describe('getActiveWebinarVideoDuration', () => {
      it('returns the video duration of the active webinar with the given slug', () => {
         const activeWebinarStore = new ActiveWebinarsStore(
            webinarServices,
            ibEventsAPIService,
            questionService
         )
         const mockWebinar: any = {
            webinarSlug: 'mock-slug',
            videoDuration: '00:30:00'
         }
         activeWebinarStore.activeWebinarsList = [mockWebinar]
         const duration = activeWebinarStore.getActiveWebinarVideoDuration(
            'mock-slug'
         )
         expect(duration).toBe('00:30:00')
      })
   })
   describe('getActiveWebinarVideoUrl', () => {
      it('returns the video URL of the active webinar with the given slug', () => {
         const webinarSlug = 'sample-webinar-slug'
         const activeWebinar: any = {
            webinarSlug,
            videoUrl: 'https://example.com/webinar.mp4'
         }
         activeWebinarStore.activeWebinarsList = [activeWebinar]
         const result = activeWebinarStore.getActiveWebinarVideoUrl(webinarSlug)
         expect(result).toEqual('https://example.com/webinar.mp4')
      })
   })
   describe('getActiveWebinarTitle', () => {
      it('returns the webinar title if the webinar is active', () => {
         const webinarSlug = 'my-webinar'
         const activeWebinar: any = { webinarTitle: 'My Webinar' }
         const activeWebinarStore = new ActiveWebinarsStore(
            webinarServices,
            ibEventsAPIService,
            questionService
         )
         jest
            .spyOn(activeWebinarStore, 'getActiveWebinar')
            .mockReturnValueOnce(activeWebinar)
         expect(activeWebinarStore.getActiveWebinarTitle(webinarSlug)).toEqual(
            activeWebinar.webinarTitle
         )
      })

      it('returns undefined if the webinar is not active', () => {
         const webinarSlug = 'my-webinar'
         const activeWebinarStore = new ActiveWebinarsStore(
            webinarServices,
            ibEventsAPIService,
            questionService
         )
         jest
            .spyOn(activeWebinarStore, 'getActiveWebinar')
            .mockReturnValueOnce(undefined)
         expect(
            activeWebinarStore.getActiveWebinarTitle(webinarSlug)
         ).toBeUndefined()
      })
   })

   describe('getActiveWebinarPlatform', () => {
      it('returns the platform of the active webinar with the specified slug', () => {
         const webinarSlug = 'test-webinar'
         const activeWebinar: any = {
            webinarId: '1',
            webinarTitle: 'Test Webinar',
            platform: 'Zoom'
         }
         const activeWebinarStore = new ActiveWebinarsStore(
            webinarServices,
            ibEventsAPIService,
            questionService
         )
         jest
            .spyOn(activeWebinarStore, 'getActiveWebinar')
            .mockReturnValue(activeWebinar)
         const result = activeWebinarStore.getActiveWebinarPlatform(webinarSlug)
         expect(result).toBe(activeWebinar.platform)
      })
   })

   describe('getActiveWebinarVideoStartDateTime', () => {
      describe('ActiveWebinarStore Test Cases', () => {
         let activeWebinarStore: ActiveWebinarsStore

         beforeEach(() => {
            // Initialize ActiveWebinarsStore
            activeWebinarStore = new ActiveWebinarsStore(
               webinarServices,
               ibEventsAPIService,
               questionService
            )
         })

         afterEach(() => {
            // Reset ActiveWebinarsStore after each test
            activeWebinarStore.activeWebinarsList = []
            activeWebinarStore.studentAmbassadorWebinars = []
         })

         describe('getActiveWebinarSimulationMode', () => {
            it('should return undefined when activeWebinar is not found', () => {
               expect(
                  activeWebinarStore.getActiveWebinarSimulationMode(
                     'invalid-slug'
                  )
               ).toBeUndefined()
            })

            it("should return undefined when activeWebinar exists but doesn't have a simulationMode", () => {
               activeWebinarStore.activeWebinarsList.push({
                  webinarSlug: 'test-webinar-slug'
               })
               expect(
                  activeWebinarStore.getActiveWebinarSimulationMode(
                     'test-webinar-slug'
                  )
               ).toBeUndefined()
            })

            it('should return the simulationMode when activeWebinar exists and has a simulationMode', () => {
               const webinar: any = {
                  webinarSlug: 'test-webinar-slug',
                  simulationMode: 'simulation-mode'
               }
               activeWebinarStore.activeWebinarsList.push(webinar)
               expect(
                  activeWebinarStore.getActiveWebinarSimulationMode(
                     'test-webinar-slug'
                  )
               ).toBe(webinar.simulationMode)
            })
         })
      })
   })

   describe('getActiveWebinarVideoStartDateTime', () => {
      test('getActiveWebinarVideoStartDateTime should return the video start date time of the active webinar with the given slug', () => {
         const webinarSlug = 'active-webinar-1'
         const expectedDateTime = '2022-05-01T14:00:00Z'
         const activeWebinar = {
            webinarSlug,
            videoStartDateTime: expectedDateTime
         }
         const activeWebinarsList: any = [activeWebinar]
         const activeWebinarStore = new ActiveWebinarsStore(
            webinarServices,
            ibEventsAPIService,
            questionService
         )
         activeWebinarStore.activeWebinarsList = activeWebinarsList
         const result = activeWebinarStore.getActiveWebinarVideoStartDateTime(
            webinarSlug
         )
         expect(result).toBe(expectedDateTime)
      })
   })

   describe('getActiveWebinarRegistrationLink', () => {
      it('returns the registration link of the active webinar with the given slug, or an empty string if not found', () => {
         const activeWebinar: any = {
            webinarSlug: 'webinar-slug',
            registrationLink: 'https://example.com'
         }
         const activeWebinarStore = new ActiveWebinarsStore(
            webinarServices,
            ibEventsAPIService,
            questionService
         )
         activeWebinarStore.activeWebinarsList = [activeWebinar]
         expect(
            activeWebinarStore.getActiveWebinarRegistrationLink(
               activeWebinar.webinarSlug
            )
         ).toEqual(activeWebinar.registrationLink)
         expect(
            activeWebinarStore.getActiveWebinarRegistrationLink(
               'non-existent-slug'
            )
         ).toEqual('')
      })

      describe('getActiveWebinarAccessConfiguration', () => {
         it('getActiveWebinarAccessConfiguration returns the correct access configuration for a given webinar', () => {
            const webinarSlug = 'example-webinar-slug'
            const expectedAccessConfig = {
               isPublic: true,
               requireLogin: false,
               allowedDomains: ['example.com']
            }
            const activeWebinar: any = {
               webinarSlug,
               accessConfiguration: expectedAccessConfig
            }
            const activeWebinarsStore = new ActiveWebinarsStore(
               webinarServices,
               ibEventsAPIService,
               questionService
            )
            activeWebinarsStore.activeWebinarsList = [activeWebinar]
            const accessConfig = activeWebinarsStore.getActiveWebinarAccessConfiguration(
               webinarSlug
            )
            expect(accessConfig).toMatchObject(expectedAccessConfig)
         })
      })
   })

   describe('getActiveWebinar', () => {
      it('should return the active webinar if it exists in the active webinars list', () => {
         const mockWebinar: any = { webinarSlug: 'webinar-1' }
         const activeWebinarStore: ActiveWebinarsStore = new ActiveWebinarsStore(
            webinarServices,
            ibEventsAPIService,
            questionService
         )
         activeWebinarStore.activeWebinarsList = [mockWebinar]
         expect(activeWebinarStore.getActiveWebinar('webinar-1')).toEqual(
            mockWebinar
         )
      })

      it('should return the student ambassador webinar if it exists in the student ambassador webinars list', () => {
         const mockWebinar: any = { webinarSlug: 'webinar-1' }
         const activeWebinarStore: ActiveWebinarsStore = new ActiveWebinarsStore(
            webinarServices,
            ibEventsAPIService,
            questionService
         )
         activeWebinarStore.studentAmbassadorWebinars = [mockWebinar]
         expect(activeWebinarStore.getActiveWebinar('webinar-1')).toEqual(
            mockWebinar
         )
      })

      it('should return the webinar from the dynamic routes list if it exists there', () => {
         const mockWebinar: any = { webinarSlug: 'webinar-1' }
         const mockDynamicRoute: any = {
            ssoWebinars: [mockWebinar]
         }
         const activeWebinarStore: ActiveWebinarsStore = new ActiveWebinarsStore(
            webinarServices,
            ibEventsAPIService,
            questionService
         )
         activeWebinarStore.dynamicRoutes = [mockDynamicRoute]
         expect(activeWebinarStore.getActiveWebinar('webinar-1')).toEqual(
            mockWebinar
         )
      })

      it('should return undefined if the webinar is not found in any list', () => {
         const activeWebinarStore: ActiveWebinarsStore = new ActiveWebinarsStore(
            webinarServices,
            ibEventsAPIService,
            questionService
         )
         expect(
            activeWebinarStore.getActiveWebinar('webinar-1')
         ).toBeUndefined()
      })
   })

   describe('getDynamicRoutesTotalWebinarsList', () => {
      it('should return the list of webinars from dynamicRoutes', () => {
         const dynamicRoutes: Array<DynamicWebinarsDetails> = [
            {
               ssoWebinars: [
                  { webinarSlug: 'webinar-1' },
                  { webinarSlug: 'webinar-2' }
               ]
            },
            {
               ssoWebinars: [
                  { webinarSlug: 'webinar-3' },
                  { webinarSlug: 'webinar-4' }
               ]
            }
         ]
         const activeWebinarStore = new ActiveWebinarsStore({}, null, null)
         activeWebinarStore.dynamicRoutes = dynamicRoutes
         const result: Array<Webinar> = activeWebinarStore.getDynamicRoutesTotalWebinarsList()
         expect(result).toEqual([
            { webinarSlug: 'webinar-1' },
            { webinarSlug: 'webinar-2' },
            { webinarSlug: 'webinar-3' },
            { webinarSlug: 'webinar-4' }
         ])
      })
      it('should return an empty array if dynamicRoutes is empty', () => {
         const activeWebinarStore = new ActiveWebinarsStore(
            webinarServices,
            ibEventsAPIService,
            questionService
         )
         activeWebinarStore.dynamicRoutes = []
         const result: Array<Webinar> = activeWebinarStore.getDynamicRoutesTotalWebinarsList()
         expect(result).toEqual([])
      })
   })

   describe('getTotalNumberOfWebinars', () => {
      let activeWebinarStore: ActiveWebinarsStore

      beforeEach(() => {
         activeWebinarStore = new ActiveWebinarsStore(
            webinarServices,
            ibEventsAPIService,
            questionService
         )
      })

      it('should return the total number of webinars when all lists are non-empty', () => {
         activeWebinarStore.activeWebinarsList = [
            new Webinar({ webinarSlug: 'webinar-1' }, questionService),
            new Webinar({ webinarSlug: 'webinar-2' }, questionService)
         ]
         activeWebinarStore.studentAmbassadorWebinars = [
            new Webinar({ webinarSlug: 'webinar-3' }, questionService)
         ]
         activeWebinarStore.dynamicRoutes = [
            {
               ssoWebinars: [
                  { webinarSlug: 'webinar-4' },
                  { webinarSlug: 'webinar-5' }
               ]
            },
            { ssoWebinars: [{ webinarSlug: 'webinar-6' }] }
         ]
         const result = activeWebinarStore.getTotalNumberOfWebinars()
         expect(result).toEqual(6)
      })

      it('should return 0 when all lists are empty', () => {
         const result = activeWebinarStore.getTotalNumberOfWebinars()
         expect(result).toEqual(0)
      })

      it('should return the correct number when some lists are empty', () => {
         activeWebinarStore.studentAmbassadorWebinars = [
            new Webinar({ webinarSlug: 'webinar-1' }, questionService)
         ]
         const result = activeWebinarStore.getTotalNumberOfWebinars()
         expect(result).toEqual(1)
      })
   })

   describe('isAllWebinarsEnded', () => {
      it('should return true if all webinars in all lists are ended', () => {
         const endedWebinar1: any = {
            webinarSlug: 'ended-webinar-1',
            isEnded: true
         }
         const endedWebinar2: any = {
            webinarSlug: 'ended-webinar-2',
            isEnded: true
         }
         const endedWebinar3: any = {
            webinarSlug: 'ended-webinar-3',
            isEnded: true
         }

         const activeWebinarStore = new ActiveWebinarsStore(
            webinarServices,
            ibEventsAPIService,
            questionService
         )
         activeWebinarStore.activeWebinarsList = [endedWebinar1]
         activeWebinarStore.studentAmbassadorWebinars = [endedWebinar2]
         const mockDynamicRoute: any = { ssoWebinars: [endedWebinar3] }
         activeWebinarStore.dynamicRoutes = [mockDynamicRoute]

         expect(activeWebinarStore.isAllWebinarsEnded()).toEqual(true)
      })

      it('should return false if not all webinars in all lists are ended', () => {
         const endedWebinar1: any = {
            webinarSlug: 'ended-webinar-1',
            isEnded: true
         }
         const endedWebinar2: any = {
            webinarSlug: 'ended-webinar-2',
            isEnded: true
         }
         const ongoingWebinar1: any = {
            webinarSlug: 'ongoing-webinar-1',
            isEnded: false
         }

         const activeWebinarStore = new ActiveWebinarsStore(
            webinarServices,
            ibEventsAPIService,
            questionService
         )
         activeWebinarStore.activeWebinarsList = [endedWebinar1]
         activeWebinarStore.studentAmbassadorWebinars = [endedWebinar2]
         const mockDynamicRoute: any = {
            ssoWebinars: [endedWebinar1, ongoingWebinar1]
         }
         activeWebinarStore.dynamicRoutes = [mockDynamicRoute]

         expect(activeWebinarStore.isAllWebinarsEnded()).toEqual(false)
      })
   })

   describe('isValidSlug', () => {
      it('should return true when the slug is valid', () => {
         activeWebinarStore.activeWebinarsList = [
            { webinarSlug: 'test-webinar-slug' }
         ]
         activeWebinarStore.studentAmbassadorWebinars = [
            new Webinar(
               { webinarSlug: 'student-ambassador-slug' },
               questionService
            )
         ]
         const isValid = activeWebinarStore.isValidSlug('test-webinar-slug')
         expect(isValid).toBeTruthy()
      })

      it('should return false when the slug is invalid', () => {
         activeWebinarStore.activeWebinarsList = [
            new Webinar({ webinarSlug: 'test-webinar-slug' }, questionService)
         ]
         activeWebinarStore.studentAmbassadorWebinars = [
            new Webinar(
               { webinarSlug: 'student-ambassador-slug' },
               questionService
            )
         ]
         const isValid = activeWebinarStore.isValidSlug('invalid-slug')
         expect(isValid).toBeFalsy()
      })
   })

   describe('getActiveWebinarBasedOnPath', () => {
      it('should return the active webinar based on the given path name', (): void => {
         activeWebinarStore.dynamicRoutes = [
            { path: '/path1', isEnded: false },
            { path: '/path2', isEnded: true }
         ]
         expect(
            activeWebinarStore.getActiveWebinarBasedOnPath('/path1')
         ).toEqual({ path: '/path1', isEnded: false })
      })

      it('should return undefined when the active webinar based on the given path name does not exist', (): void => {
         activeWebinarStore.dynamicRoutes = [
            { path: '/path1', isEnded: false },
            { path: '/path2', isEnded: true }
         ]
         expect(
            activeWebinarStore.getActiveWebinarBasedOnPath('/path3')
         ).toBeUndefined()
      })
   })

   describe('isDynamicRouteWebinar', () => {
      it('isDynamicRouteWebinar should return true when the webinar slug exists in the dynamic routes total webinars list', () => {
         activeWebinarStore.dynamicRoutes = [
            { path: '/path1', ssoWebinars: [{ webinarSlug: 'webinar1' }] },
            { path: '/path2', ssoWebinars: [{ webinarSlug: 'webinar2' }] }
         ]
         expect(activeWebinarStore.isDynamicRouteWebinar('webinar1')).toBe(true)
      })

      it('isDynamicRouteWebinar should return false when the webinar slug does not exist in the dynamic routes total webinars list', () => {
         activeWebinarStore.dynamicRoutes = [
            { path: '/path1', ssoWebinars: [{ webinarSlug: 'webinar1' }] },
            { path: '/path2', ssoWebinars: [{ webinarSlug: 'webinar2' }] }
         ]
         expect(activeWebinarStore.isDynamicRouteWebinar('webinar3')).toBe(
            false
         )
      })

      it('getDynamicRoutesTotalWebinarsList should return the total webinars list of all dynamic routes', () => {
         activeWebinarStore.dynamicRoutes = [
            {
               path: '/path1',
               ssoWebinars: [
                  { webinarSlug: 'webinar1' },
                  { webinarSlug: 'webinar2' }
               ]
            },
            { path: '/path2', ssoWebinars: [{ webinarSlug: 'webinar3' }] }
         ]
         expect(
            activeWebinarStore.getDynamicRoutesTotalWebinarsList()
         ).toEqual([
            { webinarSlug: 'webinar1' },
            { webinarSlug: 'webinar2' },
            { webinarSlug: 'webinar3' }
         ])
      })
   })

   describe('isDynamicRouteAndSSO', () => {
      it('should return true if the webinar is in a dynamic route with SSO required', () => {
         activeWebinarStore.dynamicRoutes = [
            {
               path: '/path1',
               ssoWebinars: [
                  { webinarSlug: 'slug1' },
                  { webinarSlug: 'slug2' }
               ],
               ssoRequired: true
            },
            {
               path: '/path2',
               ssoWebinars: [{ webinarSlug: 'slug3' }],
               ssoRequired: false
            }
         ]
         expect(activeWebinarStore.isDynamicRouteAndSSO('slug1')).toBe(true)
      })

      it('should return false if the webinar is not in a dynamic route with SSO required', () => {
         activeWebinarStore.dynamicRoutes = [
            {
               path: '/path1',
               ssoWebinars: [
                  { webinarSlug: 'slug1' },
                  { webinarSlug: 'slug2' }
               ],
               ssoRequired: true
            },
            {
               path: '/path2',
               ssoWebinars: [{ webinarSlug: 'slug3' }],
               ssoRequired: false
            }
         ]
         expect(activeWebinarStore.isDynamicRouteAndSSO('slug3')).toBe(false)
      })

      it('should return false if the webinar does not exist', () => {
         activeWebinarStore.dynamicRoutes = [
            {
               path: '/path1',
               ssoWebinars: [
                  { webinarSlug: 'slug1' },
                  { webinarSlug: 'slug2' }
               ],
               ssoRequired: true
            },
            {
               path: '/path2',
               ssoWebinars: [{ webinarSlug: 'slug3' }],
               ssoRequired: false
            }
         ]
         expect(activeWebinarStore.isDynamicRouteAndSSO('slug4')).toBe(false)
      })
   })

   describe('getAccessibleProductBasedOnRoute', () => {
      it('should return the accessible products based on the given route path', () => {
         const dynamicRoutes: any = [
            { path: '/path1', accessibleProducts: ['product1', 'product2'] },
            { path: '/path2', accessibleProducts: ['product3'] }
         ]
         activeWebinarStore.dynamicRoutes = dynamicRoutes
         expect(
            activeWebinarStore.getAccessibleProductsBasedOnRoutePath('/path1')
         ).toEqual(['product1', 'product2'])
      })

      it('should return an empty array when the accessible products based on the given route path does not exist', () => {
         const dynamicRoutes: any = [
            { path: '/path1', accessibleProducts: ['product1', 'product2'] },
            { path: '/path2', accessibleProducts: ['product3'] }
         ]
         activeWebinarStore.dynamicRoutes = dynamicRoutes
         expect(
            activeWebinarStore.getAccessibleProductsBasedOnRoutePath('/path3')
         ).toEqual([])
      })
   })

   describe('getRegistrationLinkBasedOnRoutePath', () => {
      // Success case
      it('should return the registration link for the given path', () => {
         activeWebinarStore.dynamicRoutes = [
            { path: '/path1', registrationLink: 'https://example.com' },
            { path: '/path2', registrationLink: 'https://test.com' }
         ]
         expect(
            activeWebinarStore.getRegistrationLinkBasedOnRoutePath('/path1')
         ).toEqual('https://example.com')
      })

      // Failure case
      it('should return an empty string when the registration link does not exist for the given path', () => {
         activeWebinarStore.dynamicRoutes = [
            { path: '/path1', registrationLink: 'https://example.com' },
            { path: '/path2', registrationLink: 'https://test.com' }
         ]
         expect(
            activeWebinarStore.getRegistrationLinkBasedOnRoutePath('/path3')
         ).toEqual('')
      })
   })

   describe('getAccessConfigurationBasedOnRoutePath', () => {
      it('should return the access configuration for the given route path in Success Case', () => {
         const routePath = '/path1'
         const expectedAccessConfig = { type: 'paid', price: 10 }
         activeWebinarStore.dynamicRoutes = [
            { path: routePath, accessConfiguration: expectedAccessConfig },
            { path: '/path2', accessConfiguration: {} }
         ]
         const accessConfig = activeWebinarStore.getAccessConfigurationBasedOnRoutePath(
            routePath
         )
         expect(accessConfig).toEqual(expectedAccessConfig)
      })
      it('should return null when access configuration for the given route path does not exist failure Case', () => {
         const routePath = '/path1'
         activeWebinarStore.dynamicRoutes = [
            { path: '/path2', accessConfiguration: {} }
         ]
         const accessConfig = activeWebinarStore.getAccessConfigurationBasedOnRoutePath(
            routePath
         )
         expect(accessConfig).toBeNull()
      })
   })
   describe('getDynamicWebinarPathName', () => {
      test('getDynamicWebinarPathName should return correct path name for a matching webinar slug', () => {
         activeWebinarStore.dynamicRoutes = [
            { path: '/route1', ssoWebinars: [{ webinarSlug: 'webinar1' }] },
            { path: '/route2', ssoWebinars: [{ webinarSlug: 'webinar2' }] },
            { path: '/route3', ssoWebinars: [{ webinarSlug: 'webinar3' }] }
         ]
         const webinarSlug = 'webinar2'
         const expectedPathName = '/route2'
         const actualPathName = activeWebinarStore.getDynamicWebinarPathName(
            webinarSlug
         )
         expect(actualPathName).toBe(expectedPathName)
      })
   })
   describe('getDynamicBasedOnWebinarSlug', () => {
      it('should return the active webinar based on the path name of the webinar with the matching slug', () => {
         activeWebinarStore.dynamicRoutes = [
            { path: '/route1', ssoWebinars: [{ webinarSlug: 'webinar1' }] },
            { path: '/route2', ssoWebinars: [{ webinarSlug: 'webinar2' }] },
            { path: '/route3', ssoWebinars: [{ webinarSlug: 'webinar3' }] }
         ]
         const webinarSlug = 'webinar2'
         const expectedWebinar = {
            path: '/route2',
            ssoWebinars: [{ webinarSlug: 'webinar2' }]
         }
         expect(
            activeWebinarStore.getDynamicRouteBasedOnWebinarSlug(webinarSlug)
         ).toEqual(expectedWebinar)
      })
   })

   describe('getAccessibleProductBasedOnWebinarSlug', () => {
      it('should return the accessible products for a given webinar slug', () => {
         activeWebinarStore.dynamicRoutes = [
            {
               path: '/route1',
               ssoWebinars: [{ webinarSlug: 'webinar1' }],
               accessibleProducts: [{ productId: 1, productName: 'Product 1' }]
            },
            {
               path: '/route2',
               ssoWebinars: [{ webinarSlug: 'webinar2' }],
               accessibleProducts: [{ productId: 2, productName: 'Product 2' }]
            },
            {
               path: '/route3',
               ssoWebinars: [{ webinarSlug: 'webinar3' }],
               accessibleProducts: [{ productId: 3, productName: 'Product 3' }]
            }
         ]
         const webinarSlug = 'webinar2'
         expect(
            activeWebinarStore.getAccessibleProductsBasedOnWebinarSlug(
               webinarSlug
            )
         ).toEqual([{ productId: 2, productName: 'Product 2' }])
      })
      it('should return an empty array when no matching webinar is found', () => {
         activeWebinarStore.dynamicRoutes = [
            {
               path: '/route1',
               ssoWebinars: [{ webinarSlug: 'webinar1' }],
               accessibleProducts: [{ productName: 'Product 1' }]
            },
            {
               path: '/route2',
               ssoWebinars: [{ webinarSlug: 'webinar2' }],
               accessibleProducts: [{ productName: 'Product 2' }]
            },
            {
               path: '/route3',
               ssoWebinars: [{ webinarSlug: 'webinar3' }],
               accessibleProducts: [{ productName: 'Product 3' }]
            }
         ]
         const webinarSlug = 'webinar4'
         expect(
            activeWebinarStore.getAccessibleProductsBasedOnWebinarSlug(
               webinarSlug
            )
         ).toEqual([])
      })
   })
   describe('getDynamicWebinarBasedOnWebinarSlug', (): void => {
      let activeWebinarStore: ActiveWebinarsStore

      beforeEach((): void => {
         activeWebinarStore = new ActiveWebinarsStore(
            webinarServices,
            ibEventsAPIService,
            questionService
         )

         activeWebinarStore.dynamicRoutes = [
            {
               path: '/route1',
               ssoWebinars: [{ webinarSlug: 'webinar1' }],
               accessibleProducts: [{ name: 'product1' }]
            },
            {
               path: '/route2',
               ssoWebinars: [{ webinarSlug: 'webinar2' }],
               accessibleProducts: [{ name: 'product2' }]
            },
            {
               path: '/route3',
               ssoWebinars: [{ webinarSlug: 'webinar3' }],
               accessibleProducts: [{ name: 'product3' }]
            }
         ]
      })

      it('should return undefined when no matching webinar is found', (): void => {
         const webinarSlug = 'webinar4'
         expect(
            activeWebinarStore.getDynamicWebinarBasedOnWebinarSlug(webinarSlug)
         ).toBeUndefined()
      })

      it('should return the dynamic route object for the webinar with the matching slug', (): void => {
         const webinarSlug = 'webinar2'
         const expectedDynamicRoute = {
            path: '/route2',
            ssoWebinars: [{ webinarSlug: 'webinar2' }],
            accessibleProducts: [{ name: 'product2' }]
         }

         expect(
            activeWebinarStore.getDynamicWebinarBasedOnWebinarSlug(webinarSlug)
         ).toEqual(expectedDynamicRoute)
      })
   })

   describe('getDynamicWebinarBasedOnWebinarSlug ', () => {
      it('should set webinarsConfigDetails when response is not null', () => {
         const response: GetWebinarsConfigDetailsAPIResponse = {
            user_webinars: [
               {
                  webinar_id: '123',
                  is_user_registered: false
               },
               {
                  webinar_id: '456',
                  is_user_registered: true
               }
            ]
         }
         activeWebinarStore.setGetWebinarsConfigDetailsAPIResponse(response)
         expect(activeWebinarStore.webinarsConfigDetails.length).toBe(2)
         expect(activeWebinarStore.webinarsConfigDetails[0].webinarId).toBe(
            '123'
         )
         expect(
            activeWebinarStore.webinarsConfigDetails[0].isUserRegistered
         ).toBe(false)
         expect(activeWebinarStore.webinarsConfigDetails[1].webinarId).toBe(
            '456'
         )
         expect(
            activeWebinarStore.webinarsConfigDetails[1].isUserRegistered
         ).toBe(true)
      })
   })

   describe('getDynamicWebinarBasedOnWebinarSlug ', () => {
      describe('ActiveWebinarsStore', () => {
         let activeWebinarStore: ActiveWebinarsStore
         let mockWebinarsService: any
         let mockSuccessCallback: jest.Mock
         let mockFailureCallback: jest.Mock

         beforeEach(() => {
            mockWebinarsService = {
               getWebinarsConfigDetailsAPI: jest.fn(() => Promise.resolve({}))
            }
            mockSuccessCallback = jest.fn()
            mockFailureCallback = jest.fn()
            activeWebinarStore = new ActiveWebinarsStore(
               mockWebinarsService,
               ibEventsAPIService,
               questionService
            )
         })
         it('should call the webinarsService.getWebinarsConfigDetailsAPI method and handle success', async () => {
            const mockResponse: WebinarConfigObject = {
               user_webinars: [
                  { webinar_id: 'webinar1', name: 'Webinar 1' },
                  { webinar_id: 'webinar2', name: 'Webinar 2' }
               ],
               webinar_id: '',
               is_user_registered: false
            }
            mockWebinarsService.getWebinarsConfigDetailsAPI.mockReturnValueOnce(
               Promise.resolve(mockResponse)
            )
            await activeWebinarStore.getWebinarsConfigDetails(
               { webinar_ids: ['webinar1', 'webinar2'] },
               mockSuccessCallback,
               mockFailureCallback
            )
            expect(
               mockWebinarsService.getWebinarsConfigDetailsAPI
            ).toHaveBeenCalledWith({ webinar_ids: ['webinar1', 'webinar2'] })
            expect(activeWebinarStore.webinarsConfigDetails).toEqual(
               mockResponse.user_webinars.map(
                  userWebinarObject => new WebinarConfigModel(userWebinarObject)
               )
            )
            expect(mockSuccessCallback).toHaveBeenCalled()
            expect(mockFailureCallback).not.toHaveBeenCalled()
         })
      })
   })
})
