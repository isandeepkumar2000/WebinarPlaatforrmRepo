import { observable, action, computed } from 'mobx'

import { bindPromiseWithOnSuccess } from '@ib/mobx-promise'
import { API_INITIAL, APIStatus } from '@ib/api-constants'

import { isHomePage } from '../../../LiveWebinar/utils/windowsUtils'
import { webinarStatusConstants } from '../../../Common/constants/BackendConstants'
import { networkCallWithApisauce } from '../../../Common/utils/AuthAPIUtils'
import { getFormattedDateTimeFromNetworkDateTime } from '../../../Common/utils/DateUtils'
import {
   getRemindMeWebinars,
   setRemindMeWebinars
} from '../../../Common/utils/LocalStorageUtils'
import { captureError } from '../../../Common/utils/DecoratorLogEntriesUtils'
import IbEventsService from '../../../Common/services/IbEventsService'

import NetworkTimeAPI from '../../services/NetworkTimeService/index.api'
import ActiveWebinarsService from '../../services/ActiveWebinarsService'

import DynamicWebinarsDetails from '../models/DynamicWebinarsDetails'
import Webinar from '../models/Webinar'
import WebinarConfigModel from '../models/WebinarConfigModel'
import {
   NetworkTimeObjectType,
   GetWebinarsConfigDetailsAPIRequest,
   GetWebinarsConfigDetailsAPIResponse
} from '../types'
import MaintenanceConfiguration from '../models/MaintenanceConfiguration'

class ActiveWebinarsStore {
   @observable getWebinarsConfigDetailsAPIError!: Error | null
   @observable getWebinarsConfigDetailsAPIStatus!: APIStatus
   @observable webinarsConfigDetails!: WebinarConfigModel[]
   @observable activeWebinarsAPIStatus!: APIStatus
   @observable activeWebinarsAPIError!: Error | null
   @observable activeWebinarsList!: Array<Webinar>
   @observable userActiveWebinarsPageAPIStatus!: APIStatus
   @observable userActiveWebinarsPageAPIError!: Error | null
   @observable userActiveWebinarsPageAPIResponse
   @observable userAttendeeIbEventsAPIStatus!: APIStatus
   @observable userAttendeeIbEventsAPIError!: Error | null
   @observable userAttendeeIbEventsAPIResponse
   @observable defaultWebinarId!: string | null
   @observable activeSlug!: string | null
   @observable activeWebinarId!: string | null | undefined
   @observable remindMeWebinars!: Array<string>
   @observable studentAmbassadorWebinars!: Array<Webinar>
   @observable showAnnouncementInNoWebinarScreen!: boolean
   @observable formFooterNote!: string
   @observable additionalInformation
   @observable fallBackUrls!: Array<string>
   @observable getCurrentNetworkDateTimeAPIStatus!: APIStatus
   @observable getCurrentNetworkDateTimeAPIError!: Error | null
   @observable currentNetworkDateTime!: string
   @observable communityMeetRedirectionUrl!: string
   @observable homePageRedirectionUrl!: string
   @observable dynamicRoutes!: Array<DynamicWebinarsDetails>
   @observable maintenanceConfig!: MaintenanceConfiguration | null
   webinarsService: ActiveWebinarsService
   questionService
   ibEventsAPIService: IbEventsService
   constructor(webinarsService, questionService, ibEventsAPIService) {
      this.webinarsService = webinarsService
      this.questionService = questionService
      this.ibEventsAPIService = ibEventsAPIService
      this.init()
   }
   @action.bound
   init() {
      this.getWebinarsConfigDetailsAPIError = null
      this.getWebinarsConfigDetailsAPIStatus = API_INITIAL
      this.webinarsConfigDetails = []

      this.activeWebinarsAPIStatus = API_INITIAL
      this.activeWebinarsAPIError = null
      this.activeWebinarsList = []
      this.defaultWebinarId = null
      this.activeSlug = null
      this.activeWebinarId = null
      this.remindMeWebinars = this.getRemindMeWebinars()
      this.showAnnouncementInNoWebinarScreen = false
      this.formFooterNote = ''
      this.additionalInformation = {}
      this.studentAmbassadorWebinars = []
      this.dynamicRoutes = []
      this.fallBackUrls = []
      this.currentNetworkDateTime = ''
      this.getCurrentNetworkDateTimeAPIStatus = API_INITIAL
      this.getCurrentNetworkDateTimeAPIError = null
      this.communityMeetRedirectionUrl = ''
      this.homePageRedirectionUrl = ''
      this.maintenanceConfig = null
   }

   @action.bound
   isAllStoredWebinarsEnded() {
      let webinarEndedCount = 0
      this.remindMeWebinars.forEach(webinarId => {
         const webinar = this.activeWebinarsList.find(
            webinar => webinar.webinarId === webinarId
         )
         if (!webinar || (webinar && webinar.isEnded)) {
            webinarEndedCount = webinarEndedCount + 1
         }
      })
      if (webinarEndedCount === this.remindMeWebinars.length) {
         return true
      }
      return false
   }

   getIndexOfCheckedValue = (value: string) =>
      this.remindMeWebinars.indexOf(value)

   getRemindMeSelectedValues = () => this.remindMeWebinars.slice()

   onSelectOption = (value: string) => {
      const index = this.getIndexOfCheckedValue(value)
      if (index === -1) {
         this.remindMeWebinars.push(value)
      } else {
         this.remindMeWebinars.splice(index, 1)
      }
   }

   getIsStudentAmbassadorWebinar = (webinarId?: string): boolean => {
      const meeting = this.studentAmbassadorWebinars.find(
         eachMeeting => eachMeeting.webinarId === webinarId
      )
      if (meeting) {
         return true
      }
      return false
   }

   @action.bound
   setActiveWebinarId() {
      if (this.activeSlug) {
         this.activeWebinarId = this.getUserActiveWebinarId(this.activeSlug)
      } else if (this.defaultWebinarId) {
         this.activeWebinarId = this.defaultWebinarId
      } else {
         this.activeWebinarId = null
      }
   }

   getRemindMeWebinars = (): Array<string> => getRemindMeWebinars()

   setRemindMeWebinarsLocally = () => {
      setRemindMeWebinars(this.remindMeWebinars)
   }

   @action.bound
   setActiveSlug(slug: string) {
      this.activeSlug = slug
   }

   @action.bound
   clearStore() {
      this.init()
   }

   @action.bound
   setActiveWebinarsAPIStatus(apiStatus) {
      this.activeWebinarsAPIStatus = apiStatus
   }

   @action.bound
   @captureError('activeWebinarsAPI')
   setActiveWebinarsAPIError(error) {
      this.activeWebinarsAPIError = error
   }

   @action.bound
   setActiveWebinarsAPIResponse(response) {
      this.onAddActiveWebinars(response.webinars)
      if (response.routes) {
         this.dynamicRoutes = response.routes.map(
            routeDetails =>
               new DynamicWebinarsDetails(
                  routeDetails,
                  response[routeDetails.data_key] ?? [],
                  this.questionService
               )
         )
      }
      if (response?.default_webinar) {
         this.defaultWebinarId = response.default_webinar
      }
      if (response?.student_ambassador_webinars) {
         const studentAmbassadorWebinars = response.student_ambassador_webinars.map(
            eachWebinar => new Webinar(eachWebinar, this.questionService)
         )
         this.studentAmbassadorWebinars = studentAmbassadorWebinars
      }
      if (response?.show_announcement) {
         this.showAnnouncementInNoWebinarScreen = response.show_announcement
      }
      if (response?.form_footer_note) {
         this.formFooterNote = response.form_footer_note
      }
      if (response?.fallback_cdn_urls) {
         this.fallBackUrls = response.fallback_cdn_urls
      }
      if (response?.c_meet_redirection_url) {
         this.communityMeetRedirectionUrl = response.c_meet_redirection_url
      }
      if (response?.home_page_redirection_url) {
         this.homePageRedirectionUrl = response.home_page_redirection_url
      }
      if (response?.maintenance_config) {
         this.maintenanceConfig = new MaintenanceConfiguration(
            response.maintenance_config
         )
      }
   }

   @action.bound
   getActiveWebinarsAPI() {
      const activeWebinarsPromise = this.webinarsService.getActiveWebinarsAPI()
      return bindPromiseWithOnSuccess(activeWebinarsPromise)
         .to(this.setActiveWebinarsAPIStatus, response => {
            this.setActiveWebinarsAPIResponse(response)
         })
         .catch(error => {
            this.setActiveWebinarsAPIError(error)
         })
   }

   @action.bound
   setCurrentNetworkDateTimeAPIStatus(status: APIStatus): void {
      this.getCurrentNetworkDateTimeAPIStatus = status
   }

   @action.bound
   @captureError('networkDateTimeAPI')
   setCurrentNetworkDateTimeAPIError(error: Error | null): void {
      this.getCurrentNetworkDateTimeAPIError = error
   }

   @action.bound
   setCurrentNetworkDateTimeAPIResponse(response: NetworkTimeObjectType) {
      this.currentNetworkDateTime = getFormattedDateTimeFromNetworkDateTime(
         response
      )
   }

   @action.bound
   getCurrentNetworkDateTimeAPI(
      onSuccess: Function = () => {},
      onFailure: Function = () => {}
   ) {
      const networkTimePromise = new NetworkTimeAPI(
         networkCallWithApisauce
      ).getCurrentNetworkDateTimeAPI()
      return bindPromiseWithOnSuccess(networkTimePromise)
         .to(this.setCurrentNetworkDateTimeAPIStatus, response => {
            this.setCurrentNetworkDateTimeAPIResponse(
               response as NetworkTimeObjectType
            )
            onSuccess()
         })
         .catch(error => {
            this.setCurrentNetworkDateTimeAPIError(error)
            onFailure()
         })
   }

   @action.bound
   setUserActiveWebinarsPageAPIStatus(apiStatus): void {
      this.userActiveWebinarsPageAPIStatus = apiStatus
   }

   @action.bound
   @captureError('activeWebinarsPageAPI')
   setUserActiveWebinarsPageAPIError(error): void {
      this.userActiveWebinarsPageAPIError = error
   }

   @action.bound
   setUserActiveWebinarsPageAPIResponse(response): void {
      this.userActiveWebinarsPageAPIResponse = response
   }

   @action.bound
   postUserActiveWebinarsPageAPI(requestObject) {
      const updatedRequestObject = {
         ...requestObject,
         additional_data: this.additionalInformation
      }
      const userActiveWebinarsPagePromise = this.webinarsService.postUserActiveWebinarsPageAPI(
         updatedRequestObject
      )
      return bindPromiseWithOnSuccess(userActiveWebinarsPagePromise)
         .to(this.setUserActiveWebinarsPageAPIStatus, response => {
            this.setUserActiveWebinarsPageAPIResponse(response)
         })
         .catch(error => {
            this.setUserActiveWebinarsPageAPIError(error)
         })
   }

   setWebinarAttendeesAPIStatus = () => {
      // do nothing
   }

   @action.bound
   webinarAttendeesAPI(
      requestObject,
      onSuccess = () => {},
      onFailure = () => {}
   ) {
      const attendeeWebinarsPromise = this.webinarsService.webinarAttendeesAPI(
         requestObject
      )
      return bindPromiseWithOnSuccess(attendeeWebinarsPromise)
         .to(this.setWebinarAttendeesAPIStatus, () => {
            onSuccess()
         })
         .catch(error => {
            onFailure()
         })
   }

   @action.bound
   userWebinarEventsAPI(
      requestObject,
      onSuccess = () => {},
      onFailure = () => {}
   ) {
      const userWebinarEventsPromise = this.webinarsService.userWebinarEventsAPI(
         requestObject
      )
      return bindPromiseWithOnSuccess(userWebinarEventsPromise)
         .to(() => {}, onSuccess)
         .catch(error => {
            onFailure()
         })
   }

   @action.bound
   onAddActiveWebinars(response) {
      const activeWebinarsList = response.map(
         eachWebinar => new Webinar(eachWebinar, this.questionService)
      )
      this.activeWebinarsList = activeWebinarsList
   }

   @action.bound
   getActiveWebinarSlug(webinarId) {
      let webinar = this.activeWebinarsList.find(
         eachWebinar => eachWebinar.webinarId === webinarId
      )

      if (!webinar) {
         webinar = this.studentAmbassadorWebinars.find(
            eachWebinar => eachWebinar.webinarId === webinarId
         )
      }
      return webinar?.webinarSlug
   }

   @action.bound
   getUserActiveWebinarId(webinarSlug: string): string | undefined {
      const activeWebinar = this.getActiveWebinar(webinarSlug)
      return activeWebinar?.webinarId
   }

   @action.bound
   getActiveWebinarYouTubeId(webinarSlug) {
      const activeWebinar = this.getActiveWebinar(webinarSlug)
      return activeWebinar?.youTubeId
   }

   @action.bound
   getActiveWebinarVideoDuration(webinarSlug) {
      const activeWebinar = this.getActiveWebinar(webinarSlug)
      return activeWebinar?.videoDuration
   }

   @action.bound
   getActiveWebinarVideoUrl(webinarSlug) {
      const activeWebinar = this.getActiveWebinar(webinarSlug)
      return activeWebinar?.videoUrl
   }

   @action.bound
   getActiveWebinarTitle(webinarSlug) {
      const activeWebinar = this.getActiveWebinar(webinarSlug)
      return activeWebinar?.webinarTitle
   }

   @action.bound
   getActiveWebinarPlatform(webinarSlug) {
      const activeWebinar = this.getActiveWebinar(webinarSlug)
      return activeWebinar?.platform
   }

   @action.bound
   getActiveWebinarSimulationMode(webinarSlug): string | undefined {
      const activeWebinar = this.getActiveWebinar(webinarSlug)
      return activeWebinar?.simulationMode
   }

   @action.bound
   getActiveWebinarVideoStartDateTime(webinarSlug): string | undefined {
      const activeWebinar = this.getActiveWebinar(webinarSlug)
      return activeWebinar?.videoStartDateTime
   }

   @action.bound
   getActiveWebinarRegistrationLink(webinarSlug): string {
      const activeWebinar = this.getActiveWebinar(webinarSlug)
      return activeWebinar?.registrationLink ?? ''
   }

   @action.bound
   getActiveWebinarAccessConfiguration(webinarSlug) {
      const activeWebinar = this.getActiveWebinar(webinarSlug)
      return activeWebinar?.accessConfiguration ?? null
   }

   @action.bound
   getActiveWebinar(webinarSlug) {
      let activeWebinar = this.activeWebinarsList.find(
         eachWebinar => eachWebinar.webinarSlug === webinarSlug
      )
      if (!activeWebinar) {
         activeWebinar = this.studentAmbassadorWebinars.find(
            eachWebinar => eachWebinar.webinarSlug === webinarSlug
         )
      }
      if (!activeWebinar) {
         activeWebinar = this.getDynamicRoutesTotalWebinarsList().find(
            eachWebinar => eachWebinar.webinarSlug === webinarSlug
         )
      }
      return activeWebinar
   }

   @action.bound
   getDynamicRoutesTotalWebinarsList = () => {
      const webinarsList: any = this.dynamicRoutes.map(
         eachRoute => eachRoute.ssoWebinars
      )
      const totalWebinarsList: any = []
      webinarsList.map(webinars => totalWebinarsList.push(...webinars))
      return totalWebinarsList
   }

   @action.bound
   getTotalNumberOfWebinars() {
      return (
         this.activeWebinarsList.length +
         this.studentAmbassadorWebinars.length +
         this.getDynamicRoutesTotalWebinarsList().length
      )
   }

   @action.bound
   isAllWebinarsEnded() {
      const endedActiveWebinars = this.activeWebinarsList.filter(
         webinar => webinar.isEnded === true
      )
      const endedStudentAmbassadorWebinars = this.studentAmbassadorWebinars.filter(
         webinar => webinar.isEnded === true
      )
      const dynamicRouteWebinars = this.getDynamicRoutesTotalWebinarsList().filter(
         webinar => webinar.isEnded === true
      )

      if (
         endedActiveWebinars.length +
            endedStudentAmbassadorWebinars.length +
            dynamicRouteWebinars.length ===
         this.activeWebinarsList.length +
            this.studentAmbassadorWebinars.length +
            this.getDynamicRoutesTotalWebinarsList().length
      ) {
         return true
      }
      return false
   }

   @action.bound
   isValidSlug(slugId: string) {
      const activeWebinarSlugs = this.activeWebinarsList.map(
         webinar => webinar.webinarSlug
      )
      const studentAmbassadorWebinars = this.studentAmbassadorWebinars.map(
         webinar => webinar.webinarSlug
      )
      const dynamicWebinarsSlugs = this.getDynamicRoutesTotalWebinarsList().map(
         webinar => webinar.webinarSlug
      )
      const webinarSlugs = [
         ...activeWebinarSlugs,
         ...studentAmbassadorWebinars,
         ...dynamicWebinarsSlugs
      ]
      const isSlugValid = webinarSlugs.find(slug => slug === slugId)

      return isSlugValid
   }

   setAdditionalInformation = infoObject => {
      if (Object.keys(infoObject).length > 0) {
         this.additionalInformation = {
            ...infoObject,
            ...this.additionalInformation
         }
      }
   }

   @action.bound
   getActiveWebinarBasedOnPath(pathName: string) {
      let updatedPathName = pathName

      if (!isHomePage() && updatedPathName)
         updatedPathName =
            pathName.slice(-1) === '/' ? pathName.slice(0, -1) : pathName

      const activeWebinar = this.dynamicRoutes.filter(
         eachWebinar => eachWebinar.path === updatedPathName
      )
      return activeWebinar[0]
   }

   @action.bound
   isDynamicRouteWebinar(webinarSlug: string): boolean {
      const dynamicWebinars = this.getDynamicRoutesTotalWebinarsList().filter(
         webinar => webinar.webinarSlug === webinarSlug
      )
      return dynamicWebinars?.length > 0
   }

   @action.bound
   isDynamicRouteAndSSO(webinarSlug: string): boolean {
      const webinar = this.getActiveWebinar(webinarSlug)
      if (webinar) {
         const dynamicRoute = this.dynamicRoutes.find(eachRoute =>
            eachRoute.ssoWebinars.includes(webinar)
         )
         return dynamicRoute?.ssoRequired
      }
      return false
   }

   @action.bound
   getAccessibleProductsBasedOnRoutePath(path: string): string[] {
      const currentRoute = this.dynamicRoutes.find(
         eachRoute => eachRoute.path === path
      )
      if (currentRoute?.accessibleProducts)
         return currentRoute.accessibleProducts
      return []
   }

   @action.bound
   getRegistrationLinkBasedOnRoutePath(path: string): string {
      const currentRoute = this.dynamicRoutes.find(
         eachRoute => eachRoute.path === path
      )
      if (currentRoute?.registrationLink) return currentRoute.registrationLink
      return ''
   }

   @action.bound
   getAccessConfigurationBasedOnRoutePath(path: string) {
      const currentRoute = this.dynamicRoutes.find(
         eachRoute => eachRoute.path === path
      )
      if (currentRoute?.accessConfiguration)
         return currentRoute.accessConfiguration
      return null
   }

   @action.bound
   getDynamicWebinarPathName(webinarSlug): string {
      const pathNamesList: Array<string> = []

      this.dynamicRoutes.forEach(eachRoute => {
         eachRoute.ssoWebinars.forEach(eachWebinar => {
            if (eachWebinar.webinarSlug === webinarSlug) {
               pathNamesList.push(eachRoute.path)
            }
         })
      })
      return pathNamesList[0]
   }

   @action.bound
   getDynamicRouteBasedOnWebinarSlug(webinarSlug: string) {
      const pathName = this.getDynamicWebinarPathName(webinarSlug)
      return this.getActiveWebinarBasedOnPath(pathName)
   }

   @action.bound
   getAccessibleProductsBasedOnWebinarSlug(webinarSlug): Array<any> {
      const productsList = [] as Array<any>

      this.dynamicRoutes.forEach(eachRoute => {
         eachRoute.ssoWebinars.forEach(eachWebinar => {
            if (eachWebinar.webinarSlug === webinarSlug) {
               productsList.push(eachRoute.accessibleProducts)
            }
         })
      })
      if (productsList && productsList.length > 0) return productsList[0]
      return []
   }

   @action.bound
   getDynamicWebinarBasedOnWebinarSlug(
      webinarSlug
   ): DynamicWebinarsDetails | undefined {
      let dynamicRoute: DynamicWebinarsDetails | undefined

      this.dynamicRoutes.forEach(eachRoute => {
         eachRoute.ssoWebinars.forEach(eachWebinar => {
            if (eachWebinar.webinarSlug === webinarSlug) {
               dynamicRoute = eachRoute
            }
         })
      })

      return dynamicRoute
   }

   @computed
   get liveWebinars() {
      const activeWebinars = this.activeWebinarsList.filter(
         webinar => webinar.isEnded === false
      )
      const liveWebinars = activeWebinars.filter(
         webinar => webinar.webinarStatus === webinarStatusConstants.live
      )
      return liveWebinars
   }
   @computed
   get upcomingWebinars() {
      const activeWebinars = this.activeWebinarsList.filter(
         webinar => webinar.isEnded === false
      )
      const upcomingWebinars = activeWebinars.filter(
         webinar => webinar.webinarStatus === webinarStatusConstants.upcoming
      )
      return upcomingWebinars
   }
   @computed
   get todayWebinars() {
      const activeWebinars = this.activeWebinarsList.filter(
         webinar => webinar.isEnded === false
      )
      const todayWebinars = activeWebinars.filter(
         webinar => webinar.webinarStatus === webinarStatusConstants.today
      )
      return todayWebinars
   }

   @computed
   get jgc2Day0Webinars() {
      const activeWebinars = this.activeWebinarsList.filter(
         webinar => webinar.isEnded === false
      )
      const jgc2Day0Webinars = activeWebinars.filter(
         webinar => webinar.webinarStatus === webinarStatusConstants.jgc2Day0
      )
      return jgc2Day0Webinars
   }
   @computed
   get todayMorningWebinars() {
      const activeWebinars = this.activeWebinarsList.filter(
         webinar => webinar.isEnded === false
      )
      const todayMorningWebinars = activeWebinars.filter(
         webinar =>
            webinar.webinarStatus === webinarStatusConstants.todayMorning
      )
      return todayMorningWebinars
   }
   @computed
   get todayAfternoonWebinars() {
      const activeWebinars = this.activeWebinarsList.filter(
         webinar => webinar.isEnded === false
      )
      const todayAfternoonWebinars = activeWebinars.filter(
         webinar =>
            webinar.webinarStatus === webinarStatusConstants.todayAfternoon
      )
      return todayAfternoonWebinars
   }
   @computed
   get todayEveningWebinars() {
      const activeWebinars = this.activeWebinarsList.filter(
         webinar => webinar.isEnded === false
      )
      const todayEveningWebinars = activeWebinars.filter(
         webinar =>
            webinar.webinarStatus === webinarStatusConstants.todayEvening
      )
      return todayEveningWebinars
   }

   @computed
   get studentAmbassadorTodayMorningWebinars() {
      const activeWebinars = this.studentAmbassadorWebinars.filter(
         webinar => webinar.isEnded === false
      )
      const todayMorningWebinars = activeWebinars.filter(
         webinar =>
            webinar.webinarStatus === webinarStatusConstants.todayMorning
      )
      return todayMorningWebinars
   }

   @computed
   get studentAmbassadorTodayAfternoonWebinars() {
      const activeWebinars = this.studentAmbassadorWebinars.filter(
         webinar => webinar.isEnded === false
      )
      const todayAfternoonWebinars = activeWebinars.filter(
         webinar =>
            webinar.webinarStatus === webinarStatusConstants.todayAfternoon
      )
      return todayAfternoonWebinars
   }

   @computed
   get studentAmbassadorTodayEveningWebinars() {
      const activeWebinars = this.studentAmbassadorWebinars.filter(
         webinar => webinar.isEnded === false
      )
      const todayEveningWebinars = activeWebinars.filter(
         webinar =>
            webinar.webinarStatus === webinarStatusConstants.todayEvening
      )
      return todayEveningWebinars
   }

   @computed
   get studentAmbassadorLiveWebinars() {
      const activeWebinars = this.studentAmbassadorWebinars.filter(
         webinar => webinar.isEnded === false
      )
      const liveWebinars = activeWebinars.filter(
         webinar => webinar.webinarStatus === webinarStatusConstants.live
      )
      return liveWebinars
   }

   get studentAmbassadorUpcomingWebinars() {
      const activeWebinars = this.studentAmbassadorWebinars.filter(
         webinar => webinar.isEnded === false
      )
      const upcomingWebinars = activeWebinars.filter(
         webinar => webinar.webinarStatus === webinarStatusConstants.upcoming
      )
      return upcomingWebinars
   }

   @action.bound
   @captureError('webinarConfigDetailsAPI')
   setGetWebinarsConfigDetailsAPIError(error: Error | null): void {
      this.getWebinarsConfigDetailsAPIError = error
   }

   @action.bound
   setGetWebinarsConfigDetailsAPIResponse(
      response: GetWebinarsConfigDetailsAPIResponse | null
   ) {
      if (response) {
         this.webinarsConfigDetails = response.user_webinars.map(
            userWebinarObject => new WebinarConfigModel(userWebinarObject)
         )
      }
   }

   @action.bound
   setGetWebinarsConfigDetailsAPIStatus(status: APIStatus): void {
      this.getWebinarsConfigDetailsAPIStatus = status
   }

   @action.bound
   getWebinarsConfigDetails(
      requestObject: GetWebinarsConfigDetailsAPIRequest,
      onSuccess: () => void,
      onFailure: (error: Error) => void
   ) {
      const { getWebinarsConfigDetailsAPI } = this.webinarsService
      const WebinarsConfigDetailsPromise = getWebinarsConfigDetailsAPI(
         requestObject
      )

      return bindPromiseWithOnSuccess(WebinarsConfigDetailsPromise)
         .to(this.setGetWebinarsConfigDetailsAPIStatus, response => {
            this.setGetWebinarsConfigDetailsAPIResponse(response)
            onSuccess()
         })
         .catch(error => {
            this.setGetWebinarsConfigDetailsAPIError(error)
            onFailure(error)
         })
   }

   @action.bound
   setUserAttendeeIbEventsAPIStatus(apiStatus): void {
      this.userAttendeeIbEventsAPIStatus = apiStatus
   }

   @action.bound
   @captureError('sendIbEventsDataAPI')
   setUserAttendeeIbEventsAPIError(error): void {
      this.userAttendeeIbEventsAPIError = error
   }

   @action.bound
   setUserAttendeeIbEventsAPIResponse(response): void {
      this.userAttendeeIbEventsAPIResponse = response
   }

   @action.bound
   postUserAttendeeIbEventsAPI(requestObject) {
      const userAttendeeIbEventsPromise = this.ibEventsAPIService.sendIbEventsDataAPI(
         requestObject
      )
      return bindPromiseWithOnSuccess(userAttendeeIbEventsPromise)
         .to(this.setUserAttendeeIbEventsAPIStatus, response => {
            this.setUserAttendeeIbEventsAPIResponse(response)
         })
         .catch(error => {
            this.setUserAttendeeIbEventsAPIError(error)
         })
   }
}
export { ActiveWebinarsStore, Webinar }
