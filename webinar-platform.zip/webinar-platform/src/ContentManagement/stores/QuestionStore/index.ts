import { observable, action, computed } from 'mobx'
import { APIStatus, API_INITIAL, API_SUCCESS } from '@ib/api-constants'
import * as firebase from 'firebase/app'
import 'firebase/database'

import { bindPromiseWithOnSuccess } from '../../../Common/utils/MobxPromise'
import { captureLogEntriesExceptionWithScope } from '../../../Common/utils/LogEntriesUtils'
import {
   logEntriesTypes,
   LogEntryPriorityEnum
} from '../../../Common/constants/LogEntriesConstants'
import { captureError } from '../../../Common/utils/DecoratorLogEntriesUtils'

import QuestionService from '../../services/QuestionService'

import QuestionModal from '../models/QuestionModel'
import { getAPIErrorMessage } from '../../../Common/utils/APIUtils'
import { SubmitRequestObjectType } from '../types'
import {
   WEBINARS,
   ACTIVE_QUESTION
} from '../../../Common/constants/FireBaseConstants'

class QuestionStore {
   @observable questionDetailsList!: Array<QuestionModal>
   @observable getQuestionResponseStatus!: APIStatus
   @observable getQuestionResponseError!: any
   @observable getSubmitQuestionAnswerStatus!: APIStatus
   @observable getSubmitQuestionAnswerError!: any
   @observable questionService!: QuestionService
   @observable isSubmitted!: boolean

   constructor(questionService: QuestionService) {
      this.questionService = questionService
      this.init()
   }

   init(): void {
      this.getQuestionResponseStatus = API_INITIAL
      this.getQuestionResponseError = null
      this.getSubmitQuestionAnswerStatus = API_INITIAL
      this.getSubmitQuestionAnswerError = null
      this.isSubmitted = false
   }

   @action.bound
   listenToActiveQuestion(webinarId) {
      firebase
         .database()
         .ref(`${WEBINARS}/${webinarId}/${ACTIVE_QUESTION}`)
         .on(
            'value',
            snapshot => {
               if (snapshot.val() !== null) {
                  this.questionResponse(snapshot.val())
               } else {
                  this.questionDetailsList = observable([])
               }
            },
            error => {
               captureLogEntriesExceptionWithScope(
                  'FIREBASE_ACTIVE_QUESTION',
                  error,
                  logEntriesTypes.errors,
                  LogEntryPriorityEnum.MEDIUM
               )
               this.setGetQuestionResponseError(error)
            }
         )
   }

   @action.bound
   questionResponse(questionResponse): void {
      this.isSubmitted = false
      this.questionDetailsList = observable([
         new QuestionModal(questionResponse)
      ])
   }

   @action.bound
   setGetQuestionResponseStatus(status: APIStatus): void {
      this.isSubmitted = false
      this.getQuestionResponseStatus = status
   }

   @action.bound
   @captureError('questionResponseAPI')
   setGetQuestionResponseError(error: any): void {
      this.getQuestionResponseError = error
   }

   @action.bound
   submitQuestionAnswer(
      onSuccess,
      onFailure,
      requestObject: SubmitRequestObjectType
   ): Promise<void | {}> {
      const submitQuestionAnswerPromise = this.questionService.submitQuestionAnswer(
         requestObject
      )
      return bindPromiseWithOnSuccess(submitQuestionAnswerPromise)
         .to(this.setGetSubmitQuestionAnswerStatus, response => {
            onSuccess()
         })
         .catch(error => {
            captureLogEntriesExceptionWithScope(
               'SUBMIT_ANSWER',
               error,
               logEntriesTypes.errors,
               LogEntryPriorityEnum.MEDIUM
            )
            this.setGetSubmitQuestionAnswerError(error)
            onFailure(getAPIErrorMessage(error))
         })
   }

   @action.bound
   setGetSubmitQuestionAnswerStatus(status: APIStatus): void {
      this.getSubmitQuestionAnswerStatus = status
      if (status === API_SUCCESS) {
         this.isSubmitted = true
      }
   }

   @action.bound
   @captureError('submitQuestionAnswerAPI')
   setGetSubmitQuestionAnswerError(error: any): void {
      this.getSubmitQuestionAnswerError = error
   }

   @computed
   get activeQuestion() {
      if (this.questionDetailsList) {
         return this.questionDetailsList[0]
      }
      return null
   }
}

export default QuestionStore
