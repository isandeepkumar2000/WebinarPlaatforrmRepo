export interface SampleApiRequest {
   phone_number: string
   country_code: string
}

export interface SampleApiResponse {
   is_profile_updated: boolean
   is_new_user: boolean
}

export interface BaseResourceType {
   title: string
   description: string
   resource_type: string
}

export interface TextResourceType extends BaseResourceType {
   author: string
   front_cover_image_url: string
   back_cover_image_url: string
}

export interface AudioResourceType extends BaseResourceType {
   audio_url: string
}

export interface VideoResourceType extends BaseResourceType {
   video_url: string
}

export interface LinkResourceType extends BaseResourceType {
   link_resource_url: string
}

export interface ImageResourceType extends BaseResourceType {
   image_url: string
}

export interface DocumentResourceType extends BaseResourceType {
   document_url: string
}

export interface OptionsType {
   id: string
   content: string
   content_type: string
}
export interface QuestionType {
   question: {
      content: string
      content_type: string
   }
   mcq_id: string
   options: Array<OptionsType>
}

export interface SubmitRequestObjectType {
   question_id: string
   phone_number: string | null
   option_id: string
}

export interface WebinarObjectType {
   webinar_id: string
   youtube_id: string
   webinar_slug: string
   is_ended: boolean
}

export interface ActiveWebinarsListObjectType {
   active_webinars: Array<WebinarObjectType>
}

export interface ActiveUserWebinarPageObjectType {
   name: string
   phone_number: number
   webinar_id: string
}

export interface WhatsappDetailsObjectType {
   is_whatsapp_enabled: boolean
   whatsapp_number: string
   message?: string
}

export interface DashboardSectionType {
   webinar_status: string
   section_title?: string
   should_show_webinars_count?: boolean
   is_section_expanded_by_default?: boolean
}

export interface RouteDetailsType {
   path: string
   is_active: boolean
   data_key: string
   sso_required: boolean
   accessible_products: Array<string>
   registration_link?: string
   access_configuration: AccessConfigurationObject
   show_whatsapp_consent?: boolean
   analytics_config?: AnalyticsConfigurationObject
   path_redirection_url?: string
   whatsapp_details?: WhatsappDetailsObjectType
   dashboard_sections_info?: Array<DashboardSectionType>
   should_show_expandable?: boolean
}

export interface NetworkTimeObjectType {
   network_time: string
}

export type PlatformTypes = 'DEFAULT' | 'YOUTUBE'

export type SimulationMode = 'LIVE' | 'RECORDED'

export interface AccessConfigurationObject {
   access_type?: string // AccessStringType
   is_one_product_access_sufficient?: boolean
   should_redirect_to_webinar_directly?: boolean
   inaccessible_view_message?: string
}

export interface AnalyticsConfigurationObject {
   should_track_events: boolean
   should_track_page: boolean
   track_event_properties: {
      serial_number: number
      webinar_category: string
   }
}

export interface AccessConfigurationType {
   access_configuration: AccessConfigurationObject
}

export interface IbVideoConfig {
   default_desktop_resolution: string
   default_mobile_resolution: string
}

export interface GetWebinarsConfigDetailsAPIRequest {
   webinar_ids: string[]
}
export interface WebinarConfigObject {
   [x: string]: any
   webinar_id: string
   is_user_registered: boolean
}
export interface GetWebinarsConfigDetailsAPIResponse {
   user_webinars: WebinarConfigObject[]
}

export type WebinarCardFooterStatusType =
   | 'LIVE'
   | 'DATE_ONLY'
   | 'TIME_ONLY'
   | 'DATE_AND_TIME'

export interface WebinarCardUIDetailsType {
   card_footer_status: WebinarCardFooterStatusType
}

export interface PreWebinarFormConfig {
   question_text: string
   options: Array<string>
}

export interface MaintenanceConfigurationTypes {
   start_datetime: string
   end_datetime: string
}
