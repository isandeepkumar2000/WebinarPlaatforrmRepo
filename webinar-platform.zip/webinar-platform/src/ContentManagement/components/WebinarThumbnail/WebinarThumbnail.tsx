import React, { Component } from 'react'

import { WebinarThumbnailImage } from './styledComponents'

interface WebinarThumbnailPropTypes {
   thumbnailSrc: string | undefined
   altText: string | undefined
}

class WebinarThumbnail extends Component<WebinarThumbnailPropTypes> {
   render() {
      const { thumbnailSrc, altText } = this.props
      return <WebinarThumbnailImage src={thumbnailSrc} alt={altText} />
   }
}

export { WebinarThumbnail }
