import { WebinarThumbnail } from './WebinarThumbnail'
export default WebinarThumbnail
