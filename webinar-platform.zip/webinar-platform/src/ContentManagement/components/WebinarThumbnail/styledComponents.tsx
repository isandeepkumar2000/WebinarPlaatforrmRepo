import styled from 'styled-components'
import Image from '../../../Common/components/Image'
import { mobile, tablet, customDevice } from '../../../Common/utils/MixinUtils'

export const WebinarThumbnailImage = styled(Image)`
   display: flex;
   height: 528px;
   width: 100%;
   ${mobile} {
      height: calc(100vw * 0.5625);
   }
   ${tablet} {
      height: 467px;
   }
   ${customDevice(1025, 1500)} {
      height: calc(55.8vw * 0.5625);
   }
`
