import React, { Component } from 'react'
import { observer } from 'mobx-react'
import RadioGroup from '../../../Common/components/RadioGroup'
import { getQuestionOption } from '../../utils/McqQuestionUtils'
import {
   McqQuestionWrapper,
   QuestionText,
   OptionsWrapper,
   radioItemCss
} from './styledComponents'

interface McqQuestionProps {
   question: any
}
@observer
class McqQuestion extends Component<McqQuestionProps> {
   handleSelectedOption = value => {
      const { question } = this.props
      question.setSelectedOption(value)
   }
   render() {
      const { question } = this.props
      let options = []
      if (question.options && question.options.length > 0) {
         options = question.options.map(option =>
            getQuestionOption(option.optionContent, option.optionId)
         )
      }
      return (
         <McqQuestionWrapper>
            <QuestionText
               dangerouslySetInnerHTML={{ __html: question.questionContent }}
            />
            <OptionsWrapper>
               <RadioGroup
                  options={options}
                  onSelectOption={this.handleSelectedOption}
                  radioItemCss={radioItemCss}
                  radioImageSize={20}
                  selectedValue={question.selectedOption}
               />
            </OptionsWrapper>
         </McqQuestionWrapper>
      )
   }
}

export default McqQuestion
