import styled, { css } from 'styled-components'
import {
   Typo18CharcoalGreyHKGroteskMedium,
   Typo16SlateHKGroteskSemiBold
} from '../../../Common/styleGuide/Typos'

export const McqQuestionWrapper = styled.div`
   display: flex;
   flex-direction: column;
   justify-content: flex-start;
   flex-wrap: wrap;
   width: 100%;
`
export const QuestionText = styled(Typo18CharcoalGreyHKGroteskMedium)`
   display: flex;
   color: ${props => props.theme.tertiaryTextColorTwo};
   user-select: none;
   flex-wrap: wrap;
   word-break: break-word;
   white-space: pre-wrap;
`
export const OptionsWrapper = styled.div`
   display: flex;
   flex-direction: column;
   word-break: break-word;
   width: 100%;
   user-select: none;
`
export const radioItemCss = css`
   ${Typo16SlateHKGroteskSemiBold};
   margin-top: 24px;
   margin-bottom: 24px;
   color: ${props => props.theme.primaryTextColor};
`
