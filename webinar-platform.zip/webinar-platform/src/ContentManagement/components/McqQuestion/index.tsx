import McqQuestion from './McqQuestion'
export default McqQuestion
