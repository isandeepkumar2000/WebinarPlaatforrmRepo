import { observable } from 'mobx'
import React, { Component } from 'react'
import uuid from 'uuid'

import GoogleAnalyticsModel from '../../../Common/stores/models/GoogleAnalyticsModel'
import { videoDataLayer } from '../../../Common/utils/GoogleAnalyticsUtils'
import { TWO_MINUTES } from '../../../Common/constants/TimeConstants'
import { trackEvent } from '../../../Common/utils/SegmentUtils/SegmentUtils'
import { PLAY_BUTTON_CLICK_EVENT } from '../../../Common/constants/SegmentConstants'
import {
   getVideoPlayBackRate,
   getVideoQuality,
   getWebinarWatchedDurationData,
   setUserPlaybackDetailsData
} from '../../../Common/components/Video/utils'
import { getUserUUID } from '../../../Common/utils/LocalStorageUtils'
import { beforeUnloadEventTypes } from '../../../Common/components/Video/constants'
import { VIDEO_BEFORE_UNLOAD_EVENT } from '../../../Common/constants/LogEntriesConstants'
import {
   getBaseLogEntriesObject,
   sendLogEntriesObjectData
} from '../../../Common/utils/LogEntriesUtils'
import { getRoundedValue } from '../../../Common/utils/MathUtils'

import { PLAYING } from '../../constants'

import { WebinarVideo, VideoWrapper } from './styledComponents'

interface WebinarYouTubeVideoProps {
   youTubeId: string
   analyticsModel: GoogleAnalyticsModel
   defaultVideoStartPosition?: number | null
   analyticsObject?: any
   webinarId: string
   secondsFromQueryParams?: number | null
   shouldPostAttendeeDetails?: Function
}

class WebinarYouTubeVideo extends Component<WebinarYouTubeVideoProps> {
   @observable webinarVideoElement
   timerId!: any
   intervalUniqueId!: number
   isFirstPlay: boolean

   constructor(props) {
      super(props)
      this.isFirstPlay = true
   }

   componentDidMount() {
      this.addEventListeners()
   }

   addEventListeners = () => {
      const { add } = beforeUnloadEventTypes
      try {
         window.addEventListener('beforeunload', () =>
            this.savePlaybackDetailsInLocalStorage()
         )
      } catch (e) {
         this.sendBeforeUnloadEventErrorLog(add, e)
      }
   }

   removeEventListeners = () => {
      const { remove } = beforeUnloadEventTypes
      try {
         window.removeEventListener('beforeunload', () =>
            this.savePlaybackDetailsInLocalStorage()
         )
      } catch (e) {
         this.sendBeforeUnloadEventErrorLog(remove, e)
      }
   }

   sendBeforeUnloadEventErrorLog = (type: string, error: any) => {
      const logEntriesObjectData = {
         event_name: VIDEO_BEFORE_UNLOAD_EVENT,
         type: type,
         error: error
      }
      const finalLogEntriesObjectData = {
         ...logEntriesObjectData,
         ...getBaseLogEntriesObject()
      }
      sendLogEntriesObjectData(finalLogEntriesObjectData)
   }

   componentWillUnmount() {
      const { analyticsObject, analyticsModel } = this.props
      const { onVideoExitEvent } = analyticsModel
      if (analyticsObject) {
         const dataLayerAnalyticsObject = {
            event: 'videoUnmountEvent',
            ...analyticsObject
         }
         videoDataLayer(dataLayerAnalyticsObject)
      }
      onVideoExitEvent(this.getVideoCurrentTime())
      this.savePlaybackDetailsInLocalStorage()
      this.clearIntervalAndResetAllTimers()
      this.removeEventListeners()
   }

   savePlaybackDetailsInLocalStorage = () => {
      const { webinarId, analyticsModel } = this.props
      const { cumulativeOffset, resetCumulativeOffset } = analyticsModel

      const userId = getUserUUID()
      const playbackSettings = {
         userId: userId,
         webinarId: webinarId,
         watchedDuration: this.getVideoCurrentTime(),
         videoQuality: getVideoQuality(userId),
         playbackRate: getVideoPlayBackRate(userId),
         cumulativeOffset: cumulativeOffset
      }

      if (this.getVideoCurrentTime()) {
         setUserPlaybackDetailsData(playbackSettings)
         resetCumulativeOffset()
      }
   }

   createNewIntervalUniqueId = () => {
      this.intervalUniqueId = uuid.v4()
   }

   onReadyVideoPlayer = (event): void => {
      const { analyticsObject, analyticsModel } = this.props
      const { onVideoEnteredEvent } = analyticsModel
      this.webinarVideoElement = event.target
      if (analyticsObject) {
         const dataLayerAnalyticsObject = {
            event: 'videoMountEvent',
            ...analyticsObject
         }
         videoDataLayer(dataLayerAnalyticsObject)
      }
      onVideoEnteredEvent(this.getVideoCurrentTime())
   }

   getVideoCurrentTime = (): number =>
      this.webinarVideoElement?.getCurrentTime()

   startTimer = () => {
      this.createNewIntervalUniqueId()
      const { analyticsModel } = this.props
      const { onVideoProgressEvent, setProgressEventDuration } = analyticsModel
      this.timerId = setInterval(() => {
         onVideoProgressEvent(this.getVideoCurrentTime(), this.intervalUniqueId)
         setProgressEventDuration(new Date().getTime())
         this.savePlaybackDetailsInLocalStorage()
      }, TWO_MINUTES)
   }

   clearTimeIntervalAndStartAgain = () => {
      const { analyticsModel } = this.props
      const { setVideoStartTime, setProgressEventDuration } = analyticsModel
      this.clearIntervalAndResetAllTimers()
      this.startTimer()
      setVideoStartTime(new Date().getTime())
      setProgressEventDuration(new Date().getTime())
   }

   clearIntervalAndResetAllTimers = () => {
      const { analyticsModel } = this.props
      const { setVideoStartTime, setProgressEventDuration } = analyticsModel
      clearInterval(this.timerId)
      setVideoStartTime(NaN)
      setProgressEventDuration(NaN)
   }

   onPauseVideo = () => {
      const { analyticsModel } = this.props
      const { onVideoPauseEvent } = analyticsModel
      onVideoPauseEvent(this.getVideoCurrentTime())
      this.clearIntervalAndResetAllTimers()
   }

   trackFirstPlay = () => {
      const { analyticsModel } = this.props
      const { webinarDetails } = analyticsModel
      const { analyticsConfiguration, language, webinarSlug } = webinarDetails

      if (analyticsConfiguration.shouldTrackEvents)
         trackEvent(PLAY_BUTTON_CLICK_EVENT, {
            language,
            serial_number: analyticsConfiguration.serialNumber,
            webinar_slug: webinarSlug
         })
   }

   onPlayVideo = () => {
      const { analyticsModel, shouldPostAttendeeDetails } = this.props
      if (this.isFirstPlay) {
         this.trackFirstPlay()
         this.isFirstPlay = false
         shouldPostAttendeeDetails && shouldPostAttendeeDetails()
      }
      const { onVideoPlayEvent } = analyticsModel
      onVideoPlayEvent(this.getVideoCurrentTime())
      this.clearTimeIntervalAndStartAgain()
   }

   onEndVideo = () => {
      const { analyticsModel } = this.props
      const { onVideoEndEvent } = analyticsModel
      onVideoEndEvent(this.getVideoCurrentTime())
      this.clearIntervalAndResetAllTimers()
   }

   onPlaybackRateChange = target => {
      const { analyticsModel } = this.props
      const {
         onPlayBackRateChangeEvent,
         setOnPlayBackRateChangeValue,
         onVideoProgressEvent
      } = analyticsModel
      if (this.webinarVideoElement.getPlayerState() === PLAYING) {
         onPlayBackRateChangeEvent(this.getVideoCurrentTime())
         onVideoProgressEvent(this.getVideoCurrentTime(), this.intervalUniqueId)
         this.clearTimeIntervalAndStartAgain()
      } else {
         this.clearIntervalAndResetAllTimers()
      }
      setOnPlayBackRateChangeValue(target.data)
   }

   getVideoDefaultStartPosition = () => {
      const {
         defaultVideoStartPosition,
         secondsFromQueryParams,
         webinarId
      } = this.props
      if (secondsFromQueryParams) {
         return secondsFromQueryParams
      }
      return (
         getWebinarWatchedDurationData(getUserUUID(), webinarId) ??
         defaultVideoStartPosition
      )
   }

   getDefaultStartTimeIfExist = () => {
      let playerVarsStartOption = {}
      const defaultVideoStartPosition = this.getVideoDefaultStartPosition()

      if (defaultVideoStartPosition) {
         playerVarsStartOption = {
            start: getRoundedValue(defaultVideoStartPosition)
         }
      }
      return playerVarsStartOption
   }

   render() {
      const { youTubeId, analyticsObject, ...options } = this.props
      const dataVideoId = (analyticsObject && analyticsObject.videoId) ?? ''
      return (
         <VideoWrapper data-video-id={dataVideoId}>
            <WebinarVideo
               id={`video-${youTubeId}`}
               videoId={youTubeId}
               onReady={this.onReadyVideoPlayer}
               onPlay={this.onPlayVideo}
               onPause={this.onPauseVideo}
               onEnd={this.onEndVideo}
               onPlaybackRateChange={this.onPlaybackRateChange}
               opts={{
                  playerVars: {
                     playsinline: 1,
                     enablejsapi: 1,
                     rel: 0,
                     modestbranding: 1,
                     ...this.getDefaultStartTimeIfExist()
                  },
                  ...options
               }}
            />
         </VideoWrapper>
      )
   }
}

export default WebinarYouTubeVideo
