import styled from 'styled-components'
import { desktop } from '../../../Common/utils/MixinUtils'
import Youtube from 'react-youtube'

export const VideoWrapper = styled.div`
   float: none;
   clear: both;
   width: 100%;
   position: relative;
   padding-bottom: 56.25%;
   height: 0;
`

export const WebinarVideo =  styled(Youtube)`
   position: absolute;
   top: 0;
   left: 0;
   width: 100%;
   height: 100%;
   ${desktop} {
      border-top-left-radius: 12px;
      border-top-right-radius: 12px;
   }
`
