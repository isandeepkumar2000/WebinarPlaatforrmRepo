import WebinarYouTubeVideo from './WebinarYouTubeVideo'
export default WebinarYouTubeVideo
