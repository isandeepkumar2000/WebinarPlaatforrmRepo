import React, { Component } from 'react'

import { getLogo, getIconDimensions } from '../../../Common/utils/LogoUtils'

import { WebinarHeaderWrapper } from './styledComponents'

class WebinarHeader extends Component {
   render() {
      return (
         <WebinarHeaderWrapper>
            {getLogo(getIconDimensions())}
         </WebinarHeaderWrapper>
      )
   }
}

export default WebinarHeader
