import styled from 'styled-components'

import Colors from '../../../Common/themes/Colors'
import { minDeviceWidth } from '../../../Common/utils/MixinUtils'

export const WebinarHeaderWrapper = styled.div`
   display: flex;
   padding-left: 24px;
   ${minDeviceWidth(1440)} {
      padding-left: 24px;
   }
   justify-content: space-between;
   align-items: center;
   background-color: ${Colors.white};
   width: auto;
   height: 72px;
`
