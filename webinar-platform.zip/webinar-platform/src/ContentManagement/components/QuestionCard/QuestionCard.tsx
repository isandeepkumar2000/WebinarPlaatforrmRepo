import React, { Component } from 'react'
import { WithTranslation, withTranslation } from 'react-i18next' //eslint-disable-line
import { observer } from 'mobx-react'
import McqQuestion from '../McqQuestion/McqQuestion'

import {
   QuestionCardWrapper,
   McqQuestionWrapper,
   QuestionFooter,
   SubmitButton
} from './styledComponents'

interface QuestionCardProps extends WithTranslation {
   question: any
   isLoading: boolean
   handleSave: Function
}
@observer
class QuestionCard extends Component<QuestionCardProps> {
   render() {
      const { question, isLoading, t, handleSave } = this.props

      return (
         <QuestionCardWrapper>
            <McqQuestionWrapper>
               <McqQuestion question={question} />
            </McqQuestionWrapper>
            {question.options && question.options.length > 0 ? (
               <QuestionFooter>
                  <SubmitButton
                     onClick={handleSave}
                     isLoading={isLoading}
                     disabled={question.selectedOption === ''}
                  >
                     {t('contentManagement:submit')}
                  </SubmitButton>
               </QuestionFooter>
            ) : null}
         </QuestionCardWrapper>
      )
   }
}

export default withTranslation()(QuestionCard)
