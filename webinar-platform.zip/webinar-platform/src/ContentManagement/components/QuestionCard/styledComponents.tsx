import styled from 'styled-components'
import Colors from '../../../Common/themes/Colors'
import { Typo12SteelHKGroteskSemiBold } from '../../../Common/styleGuide/Typos'
import Button from '../../../Common/components/Button'

export const QuestionCardWrapper = styled.div`
   display: flex;
   flex-direction: column;
   width: 100%;
   height: auto;
   background-color: ${props => props.theme.secondaryBackgroundColor};
   border-radius: 16px;
   padding: 24px;
   border: 2px solid ${props => props.theme.primaryBorderColor};
   transition: all 0.25s linear;
`
export const McqQuestionWrapper = styled.div`
   display: flex;
   width: 100%;
`
export const QuestionNumber = styled(Typo12SteelHKGroteskSemiBold)`
   padding-bottom: 24px;
   text-transform: uppercase;
`
export const QuestionFooter = styled.div`
   display: flex;
   width: 100%;
`
export const SubmitButton = styled(Button)`
   background-color: ${Colors.cerulean};
   width: 92px;
   height: 40px;
`
