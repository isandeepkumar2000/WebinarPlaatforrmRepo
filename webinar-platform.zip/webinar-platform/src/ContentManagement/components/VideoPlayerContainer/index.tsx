import { observable } from 'mobx'
import { Observer, observer } from 'mobx-react'
import React, { Component } from 'react'
import { WithTranslation, withTranslation } from 'react-i18next' //eslint-disable-line
import { API_INITIAL } from '@ib/api-constants'

import DecrementTimer from '../../../Common/components/DecrementTimer'
import LoadingWrapperWithFailure from '../../../Common/components/LoadingWrapperWithFailure'
import Video from '../../../Common/components/Video'
import { VideoSource } from '../../../Common/components/Video/types'
import AlarmClockIcon from '../../../Common/icons/AlarmClockIcon'
import GoogleAnalyticsModel from '../../../Common/stores/models/GoogleAnalyticsModel'
import {
   getDurationFromTheDate,
   getDurationFromTheNetworkDate,
   getISTFromUTC
} from '../../../Common/utils/DateUtils'
import { isMobile } from '../../../Common/utils/ResponsiveUtils'
import { getUniversalUniqueId } from '../../../Common/utils/UuidUtils'
import { getUserUUID } from '../../../Common/utils/LocalStorageUtils'
import {
   getVideoPlayBackRate,
   getWebinarWatchedDurationData
} from '../../../Common/components/Video/utils'
import AlertWarningBanner from '../../../Common/components/AlertWarningBanner'

import { videoSimulationModes } from '../../routes/Aug16WebinarRoute/constants'
import IbVideoConfigModel from '../../stores/models/IbVideoConfig'

import {
   SessionStartsText,
   SessionStartsWrapper,
   ThumbnailContainer,
   ThumbnailOverlay,
   ThumbnailWrapper,
   TimerCountCSS,
   TimerWrapper,
   VideoContainer,
   VideoThumbnail
} from './styledComponents'

interface Props extends WithTranslation {
   fallbackURLs: string[]
   id: string
   userId: string
   sources: VideoSource[]
   videoClassName: string
   videoContainerClassName: string
   videoMotomoTitle: string
   width: number
   height: number
   poster: string
   simulationMode: string
   videoStartDateTime: string
   activeWebinarStore: any
   analyticsObject: any
   analyticsModel: GoogleAnalyticsModel
   videoDuration: number
   defaultVideoStartPosition?: number | null
   ibVideoConfig: IbVideoConfigModel
   webinarId: string
   webinarTitle: string
   webinarLanguage: string
   secondsFromQueryParams?: number | null
   shouldPostAttendeeDetails?: Function
   enableVideoWatermark: boolean
}

@observer
class VideoPlayerContainer extends Component<Props> {
   videoPlayerRef: any
   @observable currentDuration: number
   @observable playerKey!: string
   @observable isMediaNotSupported: boolean
   shouldPlayVideo: boolean

   constructor(props: Props) {
      super(props)
      this.videoPlayerRef = React.createRef()
      this.currentDuration = 0
      this.setPlayerKey()
      this.shouldPlayVideo = false
      this.isMediaNotSupported = false
   }

   changeCurrentVideoTime = (): void => {
      setTimeout(this.setVideoPlayerStartingPosition, 1000)
   }

   getVideoDefaultStartPosition = () => {
      const {
         defaultVideoStartPosition,
         secondsFromQueryParams,
         webinarId
      } = this.props
      if (secondsFromQueryParams) {
         return secondsFromQueryParams
      }
      return (
         getWebinarWatchedDurationData(getUserUUID(), webinarId) ??
         defaultVideoStartPosition
      )
   }

   setVideoPlayerStartingPosition = () => {
      const defaultVideoStartPosition = this.getVideoDefaultStartPosition()
      let finalPosition
      if (
         defaultVideoStartPosition &&
         defaultVideoStartPosition > this.currentDuration
      ) {
         finalPosition = defaultVideoStartPosition
      } else {
         finalPosition = this.currentDuration
      }

      if (this.shouldPlayVideo) {
         this.changeCurrentTimeAndPlayVideo(finalPosition)
         this.shouldPlayVideo = false
      } else {
         this.changeCurrentTime(finalPosition)
      }
   }

   onSuccessGetCurrentNetworkDateTime = (): void => {
      const { videoStartDateTime, activeWebinarStore } = this.props
      const { currentNetworkDateTime } = activeWebinarStore

      const istDateTime = getISTFromUTC(currentNetworkDateTime)
      this.currentDuration = getDurationFromTheNetworkDate(
         istDateTime,
         videoStartDateTime
      )
      if (this.currentDuration >= 0) this.changeCurrentVideoTime()
   }

   onFailureGetCurrentNetworkDateTime = (): void => {
      const { videoStartDateTime } = this.props

      this.currentDuration = getDurationFromTheDate(videoStartDateTime)
      if (this.currentDuration >= 0) this.changeCurrentVideoTime()
   }

   componentDidMount(): void {
      this.doNetworkCall()
   }

   componentWillUnmount() {
      const { activeWebinarStore } = this.props
      const { setCurrentNetworkDateTimeAPIStatus } = activeWebinarStore
      setCurrentNetworkDateTimeAPIStatus(API_INITIAL)
   }

   doNetworkCall = (): void => {
      const { videoStartDateTime } = this.props

      if (videoStartDateTime && this.getIsLiveOrNot()) {
         this.props.activeWebinarStore.getCurrentNetworkDateTimeAPI(
            this.onSuccessGetCurrentNetworkDateTime,
            this.onFailureGetCurrentNetworkDateTime
         )
      }
   }

   getTimeRemainingToStartInSeconds = (): number => {
      if (this.currentDuration < 0) return this.currentDuration * -1
      return 0
   }

   getIsLiveOrNot = (): boolean => {
      const { simulationMode } = this.props
      if (simulationMode === videoSimulationModes.live) {
         return true
      }
      return false
   }

   getIsLiveAccordingToDuration = () =>
      this.currentDuration < this.props.videoDuration && this.getIsLiveOrNot()

   getLoadingWrapperHeight = (): string => (isMobile() ? '250px' : '360px')

   onTimerComplete = (): void => {
      this.doNetworkCall()
   }

   setVideoPlayerPlaybackRate = () => {
      const playbackRate = getVideoPlayBackRate(getUserUUID())
      setTimeout(
         () => this.videoPlayerRef?.current?.setVideoPlaybackRate(playbackRate),
         1000
      )
   }

   onLoadedMetadata = () => {
      if (!this.getIsLiveOrNot()) {
         this.changeCurrentVideoTime()
      }
      if (!this.getIsLiveAccordingToDuration()) {
         this.setVideoPlayerPlaybackRate()
      }
   }

   playVideo = (): void => {
      setTimeout(() => {
         try {
            if (this.videoPlayerRef?.current) {
               this.videoPlayerRef?.current?.playVideo()
            }
         } catch (exception) {
            console.log(exception)
         }
      }, 1000)
   }

   changeCurrentTimeAndPlayVideo = (time: number): void => {
      this.videoPlayerRef?.current?.changeCurrentTimeAndPlay(time)
   }

   changeCurrentTime = (time: number): void => {
      this.videoPlayerRef?.current?.changeCurrentTime(time)
   }

   setPlayerKey = () => {
      this.playerKey = getUniversalUniqueId()
   }

   onClickOfflineRetry = (): void => {
      this.setPlayerKey()
      if (this.getIsLiveOrNot()) {
         this.shouldPlayVideo = true
         this.doNetworkCall()
      } else this.playVideo()
   }

   setMediaNotSupported = (): void => {
      this.isMediaNotSupported = true
   }

   renderVideoPlayer = (): React.ReactNode => {
      const {
         fallbackURLs,
         id,
         userId,
         sources,
         videoClassName,
         videoContainerClassName,
         videoMotomoTitle,
         width,
         height,
         poster,
         analyticsObject,
         analyticsModel,
         videoDuration,
         ibVideoConfig,
         webinarId,
         webinarTitle,
         webinarLanguage,
         shouldPostAttendeeDetails,
         enableVideoWatermark
      } = this.props

      return this.isMediaNotSupported ? (
         <AlertWarningBanner />
      ) : (
         <Video
            fallbackURLs={fallbackURLs}
            id={id}
            userId={userId}
            sources={sources}
            videoClassName={videoClassName}
            videoContainerClassName={videoContainerClassName}
            videoMotomoTitle={videoMotomoTitle}
            width={width}
            height={height}
            poster={poster}
            ref={this.videoPlayerRef}
            isLive={this.getIsLiveAccordingToDuration()}
            onLoadedMetadata={this.onLoadedMetadata}
            analyticsObject={analyticsObject}
            analyticsModel={analyticsModel}
            videoDuration={videoDuration}
            defaultVideoStartPosition={
               this.getVideoDefaultStartPosition() ?? null
            }
            shouldPostAttendeeDetails={shouldPostAttendeeDetails}
            ibVideoConfig={ibVideoConfig}
            onClickOfflineRetry={this.onClickOfflineRetry}
            webinarId={webinarId}
            webinarTitle={webinarTitle}
            webinarLanguage={webinarLanguage}
            setMediaNotSupported={this.setMediaNotSupported}
            enableVideoWatermark={enableVideoWatermark}
         />
      )
   }

   renderVideoThumbnail = (): React.ReactNode => {
      const { poster, t } = this.props
      return (
         <ThumbnailContainer>
            <ThumbnailWrapper>
               <ThumbnailOverlay />
               <VideoThumbnail
                  src={poster}
                  key={this.getTimeRemainingToStartInSeconds()}
                  alt={'default-thumbnail'}
               />
            </ThumbnailWrapper>
            <SessionStartsWrapper>
               <SessionStartsText>
                  {t('common:webinar.sessionStartsIn')}
               </SessionStartsText>
               <TimerWrapper>
                  {isMobile() ? (
                     <AlarmClockIcon width={18} height={18} />
                  ) : (
                     <AlarmClockIcon />
                  )}
                  <DecrementTimer
                     key={this.getTimeRemainingToStartInSeconds()}
                     timeInSeconds={this.getTimeRemainingToStartInSeconds()}
                     containerCss={TimerCountCSS}
                     onComplete={this.onTimerComplete}
                  />
               </TimerWrapper>
            </SessionStartsWrapper>
         </ThumbnailContainer>
      )
   }

   renderSuccessUI = (): React.ReactNode => (
      <Observer>
         {() =>
            this.currentDuration < 0 ? (
               <>{this.renderVideoThumbnail()}</>
            ) : (
               <VideoContainer key={this.playerKey}>
                  {this.renderVideoPlayer()}
               </VideoContainer>
            )
         }
      </Observer>
   )

   render() {
      const { activeWebinarStore, videoStartDateTime } = this.props
      const {
         getCurrentNetworkDateTimeAPIStatus,
         getCurrentNetworkDateTimeAPIError
      } = activeWebinarStore

      return videoStartDateTime && this.getIsLiveOrNot() ? (
         <LoadingWrapperWithFailure
            apiStatus={getCurrentNetworkDateTimeAPIStatus}
            apiError={getCurrentNetworkDateTimeAPIError}
            onRetryClick={() => {}}
            renderSuccessUI={this.renderSuccessUI}
            renderFailureUI={this.renderSuccessUI}
            height={this.getLoadingWrapperHeight()}
         />
      ) : (
         this.renderSuccessUI()
      )
   }
}

export default withTranslation()(VideoPlayerContainer)
