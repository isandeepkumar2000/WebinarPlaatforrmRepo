import styled, { css } from 'styled-components'
import { Typo18WhiteHKGroteskBold } from '../../../Common/styleGuide/Typos'
import Colors from '../../../Common/themes/Colors'
import { mobile } from '../../../Common/utils/MixinUtils'

export const ThumbnailWrapper = styled.div`
   float: none;
   clear: both;
   width: 100%;
   position: relative;
   padding-bottom: 56.25%;
   height: 0;
`

export const ThumbnailOverlay = styled(ThumbnailWrapper)`
   top: 0;
   left: 0;
   right: 0;
   bottom: 0;
   z-index: 2;
`

export const VideoThumbnail = styled.img`
   position: absolute;
   top: 0;
   left: 0;
   width: 100%;
   height: 100%;
`

export const SessionStartsWrapper = styled.div`
   position: absolute;
   min-width: 198px;
   height: 101px;
   display: flex;
   flex-direction: column;
   align-items: center;
   justify-content: center;
   background: ${Colors.black};
   opacity: 0.71;
   border-radius: 16px;
   ${mobile} {
      min-width: 130px;
      height: 75px;
   }
   padding: 0px 12px;
`

export const SessionStartsText = styled(Typo18WhiteHKGroteskBold)`
   ${mobile} {
      font-size: 14px;
   }
`

export const TimerWrapper = styled.div`
   margin-top: 16px;
   display: flex;
   align-items: center;
`

export const TimerCountCSS = css`
   margin-left: 16px;
   font-size: 30px;
   color: ${Colors.white};
   ${mobile} {
      font-size: 18px;
      margin-left: 13px;
   }
`

export const ThumbnailContainer = styled.div`
   height: 100%;
   width: 100%;
   position: relative;
   display: flex;
   align-items: center;
   justify-content: center;
`

export const VideoContainer = styled.div``
