import React from 'react'
import { ProtectedRoute } from '../../Common/utils/RouteUtils'
import {
   AUG_16_WEBINAR_PATH,
   AUG_16_WEBINAR_KEY
} from '../constants/NavigationConstants'
import Aug16WebinarRoute from './Aug16WebinarRoute'

const aug16WebinarRoutes = [
   <ProtectedRoute
      path={AUG_16_WEBINAR_PATH}
      key={AUG_16_WEBINAR_KEY}
      component={Aug16WebinarRoute}
   />
]
export default aug16WebinarRoutes
