import React, { Component } from 'react'
import { WithTranslation, withTranslation } from 'react-i18next' //eslint-disable-line
import { Match, Redirect } from 'react-router-dom'

import { History } from 'history'
import { inject, observer } from 'mobx-react'
import { API_FETCHING } from '@ib/api-constants'
import { observable } from 'mobx'
import { withTheme } from 'styled-components'

import TrackAnalyticsDataWrapper from '../../../Common/components/TrackAnalyticsDataWrapper'
import {
   USER_VISITED_WEBINAR_PAGE,
   SINGLE_WEBINAR_PAGE_EVENT_NAME
} from '../../../Common/constants/SegmentConstants'
import {
   getIsSyncedWithBackend,
   setIsSyncedWithBackend,
   NOT_SYNCED_WITH_BACKEND,
   SYNCED_WITH_BACKEND,
   getGATrackID,
   getUserUUID
} from '../../../Common/utils/LocalStorageUtils'
import { UserDetailsRequest } from '../../../UserProfile/stores/types'

import WebinarYouTubeVideo from '../../components/WebinarYouTubeVideo'
import {
   WEBINAR_YOUTUBE_ID,
   TIMESTAMP_QUERY_PARAM
} from '../../constants/Aug16WebinarConstants'
import QuestionCard from '../../components/QuestionCard/QuestionCard'
import { showFailureBottomCenterToast } from '../../../Common/utils/ToastUtils'
import VideoTitleBar from '../../../Common/components/VideoTitleBar'
import WelcomeBoard from '../../../Common/components/WelcomeBoard'

import AnswerSubmitSuccessView from '../../../Common/components/AnswerSubmitSuccessView'
import UserDetailsStore from '../../../UserProfile/stores/UserDetailsStore'
import DesktopLayout from '../../../Common/components/DesktopLayout'
import BestViewCard from '../../../Common/components/BestViewCard'
import WebinarInfoStore from '../../stores/WebinarInfoStore'

import withActiveWebinar from '../../../Common/hocs/WithActiveWebinar'
import { ActiveWebinarsStore } from '../../stores/ActiveWebinarsStore/ActiveWebinarsStore'

import {
   goToPreviousPage,
   goToStudentAmbassadorDashboard,
   navigateToDynamicRouteDashboard
} from '../../../Common/utils/NavigationUtils'
import UserPresenceStore from '../../../LiveWebinar/stores/UserPresenceStore'
import WebinarThumbnail from '../../components/WebinarThumbnail'
import {
   isMobile,
   isTabletOrMobile
} from '../../../Common/utils/ResponsiveUtils'
import ThemeStore from '../../../Common/stores/ThemeStore'
import {
   ctaButtonStyleType,
   ctaDetailsType,
   validationTypes,
   webinarAttendeeFormId
} from '../../../Common/constants/BackendConstants'
import LoginForm from '../../../Common/components/LoginForm'
import TypeFormModal from '../../../Common/components/TypeFormModal'
import OTGFormModal from '../../../Common/components/OTGFormModal'
import {
   openLinkInNewWindowWithQueryParams,
   openLinkInSameWindowWithQueryParams
} from '../../../LiveWebinar/utils/windowsUtils'
import { pushToDataLayer } from '../../../Common/utils/GoogleAnalyticsUtils'
import { getQueryStringValue } from '../../../Common/utils/RouteUtils'
import { HIDE_BIG_PLAY_BUTTON_CLASSNAME } from '../../../Common/components/Video/constants'
import { getMultimediaSources } from '../../../Common/components/Video/utils'
import AttendeeModal from '../../../Common/components/AttendeeModal'
import GoogleAnalyticsModel from '../../../Common/stores/models/GoogleAnalyticsModel'
import UIStore from '../../../Common/stores/UIStore'
import {
   WEBINAR,
   WEBINAR_PATH
} from '../../../Common/constants/NavigationConstants'
import { getPlatformFeatureFlags } from '../../../Common/utils/EnvironmentUtils'
import { GoogleAnalyticsModelType } from '../../../Common/stores/types'
import AttendeeBranchModal from '../../../Common/components/AttendeeBranchModal'
import WhatsAppChatFloatButton from '../../../Common/components/WhatsAppChatFloatButton'
import { getDeviceTypeAtAnalyticsTracking } from '../../../Common/utils/ReactDeviceDetectUtils'

import VideoPlayerContainer from '../../components/VideoPlayerContainer'
import Webinar from '../../stores/models/Webinar'
import IbVideoConfigModel from '../../stores/models/IbVideoConfig'
import DynamicWebinarsDetails from '../../stores/models/DynamicWebinarsDetails'

import ActiveWebinarWithProductAccessWrapper from '../../../Common/components/ActiveWebinarWithProductAccessWrapper'
import AppsAndSubscriptionsStore from '../../../Common/stores/AppsAndSubscriptionsStore'
import { trackEvent } from '../../../Common/utils/SegmentUtils/SegmentUtils'
import { platformTypes, videoSimulationModes, attendees } from './constants'

import {
   Aug16WebinarRouteWrapper,
   WebinarVideoWrapper,
   QuestionCardWrapper,
   WebinarSessionWrapper,
   VideoWrapper,
   WelcomeCardWrapper,
   BestViewCardContainer,
   FeedbackButtonWrapper,
   FeedbackButton,
   FeedbackButtonText,
   ButtonContainer,
   AssignmentButtonText,
   AssignmentButton,
   CtaButton,
   CtaButtonText,
   CtaOutlineButton,
   CtaOutlineButtonText,
   FeedbackOutlineButtonTextTypo,
   FeedbackOutlineButton,
   DescriptionContainer,
   DangerouslySetInnerHtmlContainer,
   DescriptionHeadingText,
   ActiveWebinarContainer
} from './styledComponents'

interface Aug16WebinarRouteProps extends WithTranslation {
   match: Match
   history: History
   theme
}
interface InjectedProps extends Aug16WebinarRouteProps {
   userDetailsStore: UserDetailsStore
   webinarInfoStore: WebinarInfoStore
   activeWebinarsStore: ActiveWebinarsStore
   themeStore: ThemeStore
   userPresenceStore: UserPresenceStore
   commonUIStore: UIStore
   appsAndSubscriptionsStore: AppsAndSubscriptionsStore
}
@inject(
   'userDetailsStore',
   'webinarInfoStore',
   'activeWebinarsStore',
   'themeStore',
   'userPresenceStore',
   'commonUIStore',
   'appsAndSubscriptionsStore'
)
@observer
class Aug16WebinarRoute extends Component<Aug16WebinarRouteProps> {
   @observable showVideo = false
   @observable showLoginModal = true
   @observable phoneNumber!: string
   @observable username!: string
   @observable isFeedbackButtonClicked = false
   @observable isAssignmentButtonClicked = false
   @observable openCtaDetailsModel = false
   @observable googleAnalyticsModel: GoogleAnalyticsModel
   @observable ctaUrl = ''
   constructor(props) {
      super(props)
      this.phoneNumber = ''
      this.username = ''
      if (this.shouldCallPostUserActiveWebinarsPage()) {
         this.shouldPostUserActiveWebinarsPage()
      }
      this.googleAnalyticsModel = new GoogleAnalyticsModel(
         this.getGoogleAnalyticsInitObject()
      )
   }
   //HACK: added windowscrollTo() to scroll directly screen to top
   componentDidMount() {
      this.doNetworkCalls()
      const {
         isDynamicRouteWebinar,
         isDynamicRouteAndSSO,
         userWebinarEventsAPI
      } = this.getActiveWebinarsStore()

      const { getActiveWebinarYouTubeId } = this.getActiveWebinarsStore()

      const username = this.getUserProfileStore().getUsername()
      const phoneNumber = this.getUserProfileStore().getMobileNumber()
      const youTubeId = getActiveWebinarYouTubeId(this.getSlug())
      const { studentAmbassadorWebinar } = validationTypes

      this.setActiveYoutubeId(youTubeId)
      if (window) {
         window.scrollTo(0, 0)
      }
      if (
         this.getActiveWebinar()?.isEnded ||
         !this.getActiveWebinarsStore().isValidSlug(this.getSlug())
      ) {
         this.navigateToHomeScreen()
      }

      if (
         this.getActiveWebinarsStore().getTotalNumberOfWebinars() === 0 ||
         this.getActiveWebinarsStore().isAllWebinarsEnded()
      ) {
         this.navigateToHomeScreen()
      }
      if (username && phoneNumber) {
         this.username = username
         this.phoneNumber = phoneNumber
      }
      const { getUserActiveWebinarId } = this.getActiveWebinarsStore()
      const webinarId = getUserActiveWebinarId(this.getSlug())
      this.getUserPresenceStore().addUserToWebinar(webinarId)
      if (
         this.getValidationTypeBasedOnWebinar() === studentAmbassadorWebinar ||
         (isDynamicRouteWebinar(this.getSlug()) &&
            isDynamicRouteAndSSO(this.getSlug()))
      ) {
         this.handleLoginModal(false)
      }

      const activeWebinar = this.getActiveWebinar()
      if (activeWebinar) {
         const { webinarName } = activeWebinar
         const webinarDetails = {
            webinar_id: webinarId,
            title: webinarName
         }
         pushToDataLayer(webinarDetails)
      }

      this.trackUserVisitedWebinarPage()

      if (this.getActiveWebinar()?.shouldEnableExtraEventProperties) {
         const requestObject = {
            webinar_id: this.getActiveWebinar()?.webinarId,
            user_id: getUserUUID(),
            device_type: getDeviceTypeAtAnalyticsTracking()
         }
         userWebinarEventsAPI(requestObject)
      }
   }

   trackUserVisitedWebinarPage = () => {
      const activeWebinar = this.getActiveWebinar()
      if (activeWebinar) {
         const { language, analyticsConfiguration, webinarSlug } = activeWebinar
         if (analyticsConfiguration.shouldTrackEvents)
            trackEvent(USER_VISITED_WEBINAR_PAGE, {
               language,
               serial_number: analyticsConfiguration.serialNumber,
               webinar_category: analyticsConfiguration.webinarCategory,
               webinar_slug: webinarSlug
            })
      }
   }

   componentWillUnmount() {
      this.getUserPresenceStore().removeUserFromWebinar()
   }

   getGoogleAnalyticsInitObject = (): GoogleAnalyticsModelType => {
      const { browserSessionId } = this.getUiStore()
      const webinar = this.getActiveWebinar() as Webinar
      return {
         browserSessionId,
         userId: getUserUUID(),
         webinarDetails: {
            analyticsConfiguration: webinar?.analyticsConfiguration,
            language: webinar?.language,
            webinarId: webinar?.webinarId,
            webinarSlug: webinar?.webinarSlug
         }
      }
   }

   shouldCallPostUserActiveWebinarsPage = () => {
      const { getMobileNumber } = this.getUserProfileStore()
      if (
         getMobileNumber() &&
         this.getActiveWebinarsStore().isValidSlug(this.getSlug())
      )
         return true
      return false
   }

   doNetworkCalls = () => {
      const {
         getUserActiveWebinarId,
         getActiveWebinar
      } = this.getActiveWebinarsStore()
      const webinarId = getUserActiveWebinarId(this.getSlug())
      const activeWebinarQuestionStore = getActiveWebinar(this.getSlug())
      activeWebinarQuestionStore?.questionStore.listenToActiveQuestion(
         webinarId
      )
      // this.getWebinarInfoStore().listenToWebinarInfo()
   }
   getInjectedProps = (): InjectedProps => this.props as InjectedProps
   getThemeStore = () => this.getInjectedProps().themeStore
   getUserProfileStore = () => this.getInjectedProps().userDetailsStore
   getWebinarInfoStore = () => this.getInjectedProps().webinarInfoStore
   getActiveWebinarsStore = () => this.getInjectedProps().activeWebinarsStore
   getUserPresenceStore = () => this.getInjectedProps().userPresenceStore
   getUiStore = () => this.getInjectedProps().commonUIStore
   getAppsAndSubscriptionsStore = () =>
      this.getInjectedProps().appsAndSubscriptionsStore

   getSlug = () => this.props.match.params.webinar_slug
   getActiveWebinar = () =>
      this.getActiveWebinarsStore().getActiveWebinar(this.getSlug())

   getDynamicWebinarsDetails = (): DynamicWebinarsDetails | undefined => {
      const {
         getDynamicWebinarBasedOnWebinarSlug
      } = this.getActiveWebinarsStore()
      return getDynamicWebinarBasedOnWebinarSlug(this.getSlug())
   }

   getSecondsFromQueryParams = (): number | null => {
      const { history } = this.props
      const { location } = history
      const secondsString: string = getQueryStringValue(
         location,
         TIMESTAMP_QUERY_PARAM
      )
      if (secondsString) {
         const seconds = Number(secondsString)
         return isNaN(seconds) ? null : seconds
      }
      return null
   }

   getDefaultVideoStartPosition = (): number | null | undefined => {
      const defaultVideoStartPosition = this.getActiveWebinar()
         ?.defaultStartPosition
      return defaultVideoStartPosition
   }

   onSuccess = () => {}
   onFailure = error => {
      showFailureBottomCenterToast(error)
   }

   setActiveYoutubeId = youTubeId => {
      const { setYouTubeId } = this.getWebinarInfoStore()
      setYouTubeId(youTubeId)
   }

   shouldPostUserActiveWebinarsPage = (): void => {
      const username = this.getUserProfileStore().getUsername()
      const phoneNumber = this.getUserProfileStore().getMobileNumber()
      const { getUserActiveWebinarId } = this.getActiveWebinarsStore()
      const webinarSlug = this.getSlug()

      if (this.getActiveWebinarsStore().isValidSlug(webinarSlug)) {
         const userWebinarId = getUserActiveWebinarId(webinarSlug)
         const requestObject = {
            name: username,
            phone_number: phoneNumber,
            webinar_id: userWebinarId,
            ga_client_id: getGATrackID(),
            ga_user_id: getUserUUID()
         }
         this.getActiveWebinarsStore().postUserActiveWebinarsPageAPI(
            requestObject
         )
      }
   }

   shouldPostAttendeeDetails = (): void => {
      const { getUserActiveWebinarId } = this.getActiveWebinarsStore()
      const webinarSlug = this.getSlug()
      const { enableIbEventsAPI } = getPlatformFeatureFlags()

      if (this.getActiveWebinarsStore().isValidSlug(webinarSlug)) {
         const userWebinarId = getUserActiveWebinarId(webinarSlug)

         const userId = getUserUUID()

         const requestObject = {
            user_id: userId,
            webinar_id: userWebinarId,
            watch_duration_in_seconds: '1'
         }
         if (enableIbEventsAPI) {
            this.getActiveWebinarsStore().postUserAttendeeIbEventsAPI(
               requestObject
            )
         }
      }
   }

   handleHideVideoButton = () => {
      this.showVideo = !this.showVideo
   }

   onSuccessEntry = (): void => {
      setIsSyncedWithBackend(SYNCED_WITH_BACKEND)
   }

   onFailureEntry = (error): void => {
      setIsSyncedWithBackend(NOT_SYNCED_WITH_BACKEND)
   }

   navigateToHomeScreen = () => {
      const { history } = this.props
      goToPreviousPage(history)
   }

   getMobileIconDimesnsion = () => {
      if (isMobile() || isTabletOrMobile()) {
         return { width: 120, height: 48 }
      }

      return { width: 150, height: 62 }
   }

   shouldShowWhatsAppConsent = () => {
      const {
         getDynamicRouteBasedOnWebinarSlug
      } = this.getActiveWebinarsStore()
      return getDynamicRouteBasedOnWebinarSlug(this.getSlug())
         ?.showWhatsAppConsent
   }

   handleLoginModal = isOpen => {
      this.showLoginModal = isOpen
   }

   onFeedbackButtonTriggered = () => {
      this.isFeedbackButtonClicked = !this.isFeedbackButtonClicked
   }

   onAssignmentButtonTriggered = () => {
      this.isAssignmentButtonClicked = !this.isAssignmentButtonClicked
   }

   handleSubmitButton = () => {
      const { getActiveWebinar } = this.getActiveWebinarsStore()
      const activeWebinarQuestionStore = getActiveWebinar(this.getSlug())

      if (activeWebinarQuestionStore?.questionStore) {
         const {
            submitQuestionAnswer,
            activeQuestion
         } = activeWebinarQuestionStore?.questionStore
         const { submitUserDetails } = this.getUserProfileStore()
         const username = this.getUserProfileStore().getUsername()
         const phoneNumber = this.getUserProfileStore().getMobileNumber()
         const randomNumber = Math.floor(Math.random() * 100)
         const questionId = `${activeQuestion!.questionId}_${randomNumber}`
         const requestObject = {
            question_id: questionId,
            phone_number: phoneNumber ?? getUserUUID(),
            option_id: activeQuestion!.selectedOption
         }
         if (getIsSyncedWithBackend() === NOT_SYNCED_WITH_BACKEND) {
            const submitUserDetailsRequest = {
               name: username,
               phone_number: phoneNumber ?? getUserUUID(),
               webinars_to_remind: this.getActiveWebinarsStore()
                  .remindMeWebinars
            }
            submitUserDetails(
               submitUserDetailsRequest as UserDetailsRequest,
               this.onSuccessEntry,
               this.onFailureEntry
            )
         }
         submitQuestionAnswer(this.onSuccess, this.onFailure, requestObject)
      }
   }

   closeModel = () => {
      const { history } = this.props
      const {
         isDynamicRouteWebinar,
         getDynamicWebinarPathName
      } = this.getActiveWebinarsStore()
      if (
         this.getValidationTypeBasedOnWebinar() ===
         validationTypes.studentAmbassadorWebinar
      ) {
         goToStudentAmbassadorDashboard(history)
      } else if (isDynamicRouteWebinar(this.getSlug())) {
         navigateToDynamicRouteDashboard(
            history,
            getDynamicWebinarPathName(this.getSlug())
         )
      } else {
         this.navigateToHomeScreen()
      }
   }

   getAssignmentUrl = () => {
      const assignmentUrl = this.getActiveWebinar()?.assignmentUrl
      const phoneNumber = this.getUserProfileStore()?.getMobileNumber()

      if (phoneNumber) {
         const url = assignmentUrl?.replace('PHONE-XXX', phoneNumber)
         return url
      }
   }

   setCtaModalStatus = (modalStatus = false) => {
      this.openCtaDetailsModel = modalStatus
   }

   handleCtaButtonClick = ctaDetails => {
      const { ctaType, ctaUrl } = ctaDetails
      const { internal, external, redirect } = ctaDetailsType
      this.ctaUrl = ctaUrl

      if (ctaType === internal) {
         this.setCtaModalStatus(true)
      } else if (ctaType === external) {
         openLinkInNewWindowWithQueryParams(this.ctaUrl)
      } else if (ctaType === redirect) {
         openLinkInSameWindowWithQueryParams(this.ctaUrl)
      }
   }
   renderSuccessUI = () => {
      const activeWebinarQuestionStore = this.getActiveWebinar()
      const feedbackUrl = this.getActiveWebinar()?.feedbackUrl
      const { getUserActiveWebinarId } = this.getActiveWebinarsStore()
      const phoneNumber = this.getUserProfileStore()?.getMobileNumber()
      const webinarId = getUserActiveWebinarId(this.getSlug())
      let typeFormFeedbackUrl = ''
      if (feedbackUrl) {
         const addPhoneNumberToFeedbackUrl = feedbackUrl.replace(
            'PHONE-XXX',
            `${phoneNumber}`
         )
         const addWebinarIdToFeedbackUrl = addPhoneNumberToFeedbackUrl.replace(
            'LRID-XXX',
            `${webinarId}`
         )
         typeFormFeedbackUrl = addWebinarIdToFeedbackUrl.replace(
            'LANGUAGE-XXX',
            'ENGLISH'
         )
      }

      const typeFormAssignmentUrl = this.getAssignmentUrl() ?? ''

      if (activeWebinarQuestionStore?.questionStore) {
         const {
            activeQuestion,
            getSubmitQuestionAnswerStatus,
            isSubmitted
         } = activeWebinarQuestionStore?.questionStore
         if (activeQuestion) {
            if (!isSubmitted) {
               return (
                  <QuestionCardWrapper isHidden={this.showVideo}>
                     <QuestionCard
                        question={activeQuestion}
                        isLoading={
                           getSubmitQuestionAnswerStatus === API_FETCHING
                        }
                        handleSave={this.handleSubmitButton}
                     />
                  </QuestionCardWrapper>
               )
            }
            return (
               <QuestionCardWrapper isHidden={this.showVideo}>
                  <AnswerSubmitSuccessView />
               </QuestionCardWrapper>
            )
         }
         return (
            <WelcomeCardWrapper isHidden={this.showVideo}>
               <WelcomeBoard />
               {this.isFeedbackButtonClicked ? (
                  <TypeFormModal
                     isEmbed={true}
                     url={typeFormFeedbackUrl}
                     closeTypeForm={this.onFeedbackButtonTriggered}
                  />
               ) : null}
               {this.isAssignmentButtonClicked ? (
                  <TypeFormModal
                     isEmbed={true}
                     url={typeFormAssignmentUrl}
                     closeTypeForm={this.onAssignmentButtonTriggered}
                  />
               ) : null}
               <BestViewCardContainer>
                  <BestViewCard />
               </BestViewCardContainer>
            </WelcomeCardWrapper>
         )
      }
      return null
   }

   renderCtaButtons = ctaDetails => {
      if (ctaDetails) {
         const ctaButtons = ctaDetails.map(eachCta => (
            <FeedbackButtonWrapper
               isHidden={this.showVideo}
               onClick={() => this.handleCtaButtonClick(eachCta)}
               key={eachCta.localUUID}
            >
               {eachCta.buttonStyle === ctaButtonStyleType.filled ? (
                  <CtaButton>
                     <CtaButtonText>{eachCta.ctaButtonText}</CtaButtonText>
                  </CtaButton>
               ) : (
                  <CtaOutlineButton textTypo={CtaOutlineButtonText}>
                     <CtaOutlineButtonText>
                        {eachCta.ctaButtonText}
                     </CtaOutlineButtonText>
                  </CtaOutlineButton>
               )}
            </FeedbackButtonWrapper>
         ))
         return ctaButtons
      }
      return null
   }

   getValidationTypeBasedOnWebinar = () => {
      const studentAmbassadorWebinar = this.getActiveWebinarsStore().getIsStudentAmbassadorWebinar(
         this.getActiveWebinar()?.webinarId
      )
      const isDynamicRouteAndNotSSOWebinar = !this.getActiveWebinarsStore().isDynamicRouteAndSSO(
         this.getSlug()
      )

      let validationType = validationTypes.defaultValidation
      if (studentAmbassadorWebinar) {
         validationType = validationTypes.studentAmbassadorWebinar
      } else if (isDynamicRouteAndNotSSOWebinar) {
         validationType = validationTypes.dynamicDefaultWebinar
      }

      return validationType
   }

   // TODO: define type for requestObject here
   onSubmitAttendeeForm = requestObject => {
      const preWebinarFormConfig = this.getActiveWebinar()?.preWebinarFormConfig

      const {
         webinarAttendeesAPI,
         userWebinarEventsAPI
      } = this.getActiveWebinarsStore()
      if (preWebinarFormConfig || this.isAttendeeModalRendering()) {
         webinarAttendeesAPI(
            requestObject,
            this.trackUserVisitedWebinarPage,
            this.trackUserVisitedWebinarPage
         )
      } else if (this.isPreWebinarFormTypeBranch()) {
         userWebinarEventsAPI(
            requestObject,
            this.trackUserVisitedWebinarPage,
            this.trackUserVisitedWebinarPage
         )
      }
   }

   isAttendeeModalRendering = () =>
      attendees.parentOrStudentForm === this.getActiveWebinar()?.preWebinarForm

   isPreWebinarFormTypeBranch = (): boolean =>
      attendees.branch === this.getActiveWebinar()?.preWebinarForm

   renderAttendeeModal = () => {
      const preWebinarFormConfig = this.getActiveWebinar()?.preWebinarFormConfig

      if (preWebinarFormConfig || this.isAttendeeModalRendering()) {
         return (
            <AttendeeModal
               onSubmitAttendeeForm={this.onSubmitAttendeeForm}
               webinarAttendeeFormId={webinarAttendeeFormId}
               webinar={this.getActiveWebinar()}
               preWebinarFormConfig={preWebinarFormConfig}
            />
         )
      } else if (this.isPreWebinarFormTypeBranch()) {
         return (
            <AttendeeBranchModal
               themeStore={this.getThemeStore()}
               webinar={this.getActiveWebinar()}
               onSubmitAttendeeForm={this.onSubmitAttendeeForm}
            />
         )
      }
   }

   isSSOEnabledButWebinarNotExistsInUrl = () => {
      const { isDynamicRouteAndSSO } = this.getActiveWebinarsStore()
      if (
         isDynamicRouteAndSSO(this.getSlug()) &&
         this.props.match.path !== WEBINAR_PATH
      ) {
         return true
      }
      return false
   }

   getVideoAnalyticsObject = (videoType, webinarId) => ({
      videoId: `${videoType}#${webinarId}`
   })

   renderDefaultVideoPlayer = () => {
      const {
         getActiveWebinarVideoUrl,
         getUserActiveWebinarId,
         getActiveWebinarTitle,
         getActiveWebinarSimulationMode,
         getActiveWebinarVideoStartDateTime,
         getActiveWebinarVideoDuration,
         fallBackUrls
      } = this.getActiveWebinarsStore()
      const webinarVideoUrl = getActiveWebinarVideoUrl(this.getSlug())
      const webinarTitle = getActiveWebinarTitle(this.getSlug())
      const webinarId = getUserActiveWebinarId(this.getSlug())
      const thumbnailUrl = this.getActiveWebinar()?.thumbnailTablet
      const simulationMode = getActiveWebinarSimulationMode(this.getSlug())
      const videoStartDateTime = getActiveWebinarVideoStartDateTime(
         this.getSlug()
      )
      const activeWebinarVideoDuration = getActiveWebinarVideoDuration(
         this.getSlug()
      )
      const defaultVideoStartPosition = this.getDefaultVideoStartPosition()
      const secondsFromQueryParams = this.getSecondsFromQueryParams()
      const ibVideoConfig = this.getActiveWebinar()?.ibVideoConfig
      const webinarLanguage = this.getActiveWebinar()?.language
      const enableVideoWatermark = this.getActiveWebinar()
         ?.shouldEnableVideoWatermark
      const userId = this.getUserProfileStore().userId

      return (
         <VideoWrapper isHidden={this.showVideo}>
            <VideoPlayerContainer
               fallbackURLs={fallBackUrls}
               id={`video-${webinarId}`}
               userId={userId ? userId : getUserUUID() ?? ''}
               sources={getMultimediaSources(webinarVideoUrl)}
               videoClassName={HIDE_BIG_PLAY_BUTTON_CLASSNAME}
               videoContainerClassName={''}
               videoMotomoTitle={`${webinarId}-${webinarTitle}`}
               width={640}
               height={360}
               poster={thumbnailUrl ?? ''} //TODO: DECISION regarding Default Thumbnail
               simulationMode={simulationMode ?? videoSimulationModes.recorded}
               videoStartDateTime={videoStartDateTime ?? ''}
               activeWebinarStore={this.getActiveWebinarsStore()}
               shouldPostAttendeeDetails={this.shouldPostAttendeeDetails}
               webinarId={webinarId ?? ''}
               analyticsObject={this.getVideoAnalyticsObject(
                  'default',
                  webinarId
               )}
               analyticsModel={this.googleAnalyticsModel}
               videoDuration={activeWebinarVideoDuration ?? 0}
               defaultVideoStartPosition={defaultVideoStartPosition}
               ibVideoConfig={ibVideoConfig as IbVideoConfigModel}
               webinarTitle={webinarTitle ?? ''}
               webinarLanguage={webinarLanguage ?? ''}
               secondsFromQueryParams={secondsFromQueryParams}
               enableVideoWatermark={enableVideoWatermark ?? false}
            />
         </VideoWrapper>
      )
   }

   renderYoutubePlayer = () => {
      const { getActiveWebinarYouTubeId } = this.getActiveWebinarsStore()
      const webinarYouTubeId =
         getActiveWebinarYouTubeId(this.getSlug()) ?? WEBINAR_YOUTUBE_ID
      const { getUserActiveWebinarId } = this.getActiveWebinarsStore()
      const webinarId = getUserActiveWebinarId(this.getSlug())
      const secondsFromQueryParams = this.getSecondsFromQueryParams()
      const defaultVideoStartPosition = this.getDefaultVideoStartPosition()
      return (
         <VideoWrapper isHidden={this.showVideo}>
            <WebinarYouTubeVideo
               youTubeId={webinarYouTubeId}
               analyticsObject={this.getVideoAnalyticsObject(
                  'youtube',
                  webinarId
               )}
               shouldPostAttendeeDetails={this.shouldPostAttendeeDetails}
               analyticsModel={this.googleAnalyticsModel}
               defaultVideoStartPosition={defaultVideoStartPosition}
               webinarId={webinarId ?? ''}
               secondsFromQueryParams={secondsFromQueryParams}
            />
         </VideoWrapper>
      )
   }

   renderVideoPlayer = () => {
      const { getActiveWebinarPlatform } = this.getActiveWebinarsStore()
      const activeWebinarPlatform = getActiveWebinarPlatform(this.getSlug())

      return activeWebinarPlatform === platformTypes.default
         ? this.renderDefaultVideoPlayer()
         : this.renderYoutubePlayer()
   }

   renderVideoTitleAndDescription = (): React.ReactNode => {
      const title = this.getActiveWebinar()?.title
      const description = this.getActiveWebinar()?.description

      return description || title ? (
         <DescriptionContainer>
            {title ? (
               <DescriptionHeadingText>{title}</DescriptionHeadingText>
            ) : null}
            {description ? (
               <DangerouslySetInnerHtmlContainer
                  dangerouslySetInnerHTML={{
                     __html: description
                  }}
               />
            ) : null}
         </DescriptionContainer>
      ) : null
   }

   renderWrappedComponent = () => {
      const { t, history } = this.props
      const {
         isDynamicRouteAndSSO,
         getActiveWebinarYouTubeId
      } = this.getActiveWebinarsStore()
      const webinarYouTubeId =
         getActiveWebinarYouTubeId(this.getSlug()) ?? WEBINAR_YOUTUBE_ID
      const webinarTitle = this.getActiveWebinar()?.webinarTitle
      const webinarThumbnailSrc = this.getActiveWebinar()?.thumbnailTablet
      const feedbackUrl = this.getActiveWebinar()?.feedbackUrl
      const assignmentUrl = this.getActiveWebinar()?.assignmentUrl
      const ctaDetails = this.getActiveWebinar()?.ctaDetails
      const { studentAmbassadorWebinar } = validationTypes
      return (
         <>
            {this.renderAttendeeModal()}
            {this.getValidationTypeBasedOnWebinar() ===
               studentAmbassadorWebinar ||
            isDynamicRouteAndSSO(this.getSlug()) ? null : (
               <LoginForm
                  history={history}
                  submitButtonName={t('Join Webinar')}
                  onSubmit={this.shouldPostUserActiveWebinarsPage}
                  handleLoginModal={this.handleLoginModal}
                  validationType={this.getValidationTypeBasedOnWebinar()}
                  headingText={t(
                     'Please confirm your details to join the webinar'
                  )}
                  hideBackButton={true}
                  showWhatsAppConsent={this.shouldShowWhatsAppConsent()}
               />
            )}
            <Aug16WebinarRouteWrapper isHidden={this.showLoginModal}>
               <WebinarSessionWrapper isHidden={this.showVideo}>
                  {webinarYouTubeId.length !== 0 ? (
                     <WebinarVideoWrapper isHidden={this.showVideo}>
                        {this.renderVideoPlayer()}
                        <VideoTitleBar
                           onClickShowHideVideo={this.handleHideVideoButton}
                           webinarTitle={webinarTitle}
                        />
                        <ButtonContainer>
                           {ctaDetails && ctaDetails?.length > 0
                              ? this.renderCtaButtons(ctaDetails)
                              : null}
                           {assignmentUrl ? (
                              <FeedbackButtonWrapper isHidden={this.showVideo}>
                                 <AssignmentButton
                                    onClick={this.onAssignmentButtonTriggered}
                                 >
                                    <AssignmentButtonText>
                                       {t('submit assignment')}
                                    </AssignmentButtonText>
                                 </AssignmentButton>
                              </FeedbackButtonWrapper>
                           ) : null}
                           {feedbackUrl ? (
                              ctaDetails && ctaDetails?.length > 0 ? (
                                 <FeedbackButtonWrapper
                                    isHidden={this.showVideo}
                                 >
                                    <FeedbackOutlineButton
                                       onClick={this.onFeedbackButtonTriggered}
                                    >
                                       <FeedbackOutlineButtonTextTypo>
                                          {t('submit feedback')}
                                       </FeedbackOutlineButtonTextTypo>
                                    </FeedbackOutlineButton>
                                 </FeedbackButtonWrapper>
                              ) : (
                                 <FeedbackButtonWrapper
                                    isHidden={this.showVideo}
                                 >
                                    <FeedbackButton
                                       onClick={this.onFeedbackButtonTriggered}
                                    >
                                       <FeedbackButtonText>
                                          {t('submit feedback')}
                                       </FeedbackButtonText>
                                    </FeedbackButton>
                                 </FeedbackButtonWrapper>
                              )
                           ) : null}
                        </ButtonContainer>
                        {this.renderVideoTitleAndDescription()}
                     </WebinarVideoWrapper>
                  ) : (
                     <WebinarVideoWrapper>
                        <WebinarThumbnail
                           thumbnailSrc={webinarThumbnailSrc}
                           altText={webinarTitle}
                        />
                     </WebinarVideoWrapper>
                  )}
                  {this.renderSuccessUI()}
                  {this.openCtaDetailsModel ? (
                     <OTGFormModal
                        url={this.ctaUrl}
                        showCloseButton={true}
                        closeForm={this.setCtaModalStatus}
                     />
                  ) : null}
               </WebinarSessionWrapper>
            </Aug16WebinarRouteWrapper>
         </>
      )
   }

   renderActiveWebinarWithProductAccessWrapper = () => {
      const {
         getAccessibleProductsBasedOnWebinarSlug,
         getActiveWebinarRegistrationLink,
         getActiveWebinarAccessConfiguration,
         getUserActiveWebinarId
      } = this.getActiveWebinarsStore()

      const slug = this.getSlug()
      const activeWebinarId = getUserActiveWebinarId(slug)
      const webinarAccessConfiguration = getActiveWebinarAccessConfiguration(
         slug
      )

      return activeWebinarId ? (
         <ActiveWebinarWithProductAccessWrapper
            activeWebinarsStore={this.getActiveWebinarsStore()}
            appsAndSubscriptionsStore={this.getAppsAndSubscriptionsStore()}
            webinarAccessConfiguration={webinarAccessConfiguration}
            webinarIdsList={[activeWebinarId]}
            accessibleProducts={getAccessibleProductsBasedOnWebinarSlug(slug)}
            renderWrappedComponent={this.renderWrappedComponent}
            theme={this.getThemeStore().selectedTheme}
            registrationLink={getActiveWebinarRegistrationLink(slug)}
         />
      ) : (
         <></>
      )
   }

   renderWhatsappIcon = (): React.ReactElement | null => {
      const dynamicWebinarsDetails = this.getDynamicWebinarsDetails()
      if (dynamicWebinarsDetails) {
         const { whatsappDetails } = dynamicWebinarsDetails
         return whatsappDetails && whatsappDetails.isWhatsappEnabled ? (
            <WhatsAppChatFloatButton
               message={whatsappDetails.message}
               phoneNumber={whatsappDetails.whatsappNumber}
            />
         ) : null
      }
      return null
   }

   render() {
      return (
         <DesktopLayout
            {...this.getMobileIconDimesnsion()}
            hideBackButton={false}
            backToList={this.closeModel}
            changeTheme={this.getThemeStore().setTheme}
            theme={this.getThemeStore().selectedTheme}
         >
            {this.isSSOEnabledButWebinarNotExistsInUrl() ? (
               <Redirect
                  to={{
                     pathname: `${WEBINAR}/${this.getSlug()}`
                  }}
               />
            ) : (
               <ActiveWebinarContainer>
                  <TrackAnalyticsDataWrapper
                     pageEventOptions={{ name: SINGLE_WEBINAR_PAGE_EVENT_NAME }}
                     analyticsConfiguration={
                        this.getActiveWebinar()?.analyticsConfiguration
                     }
                     renderComponent={
                        this.renderActiveWebinarWithProductAccessWrapper
                     }
                  />
               </ActiveWebinarContainer>
            )}
            {this.renderWhatsappIcon()}
         </DesktopLayout>
      )
   }
}

export default withTheme(
   withActiveWebinar(withTranslation()(Aug16WebinarRoute))
)
