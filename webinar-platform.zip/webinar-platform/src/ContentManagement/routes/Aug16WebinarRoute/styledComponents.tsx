import styled from 'styled-components'
import {
   tablet,
   mobile,
   minDeviceWidth,
   customDevice,
   desktop,
   maxDeviceWidth
} from '../../../Common/utils/MixinUtils'
import Colors from '../../../Common/themes/Colors'
import {
   Typo14AzulTwoHKGroteskMedium,
   Typo30paleGreyHKGroteskBold,
   Typo12SteelHKGroteskSemiBold,
   BaseHKGroteskMediumText,
   Typo12PinkishOrangeHKGrotesk
} from '../../../Common/styleGuide/Typos'
import TextInput from '../../../Common/components/TextInput'
import Button from '../../../Common/components/Button'
import BaseModalContainer from '../../../Common/components/BaseModalContainer'
import { DARK_THEME } from '../../../Common/constants/ThemeConstants'
import { TABLET_MAX_WIDTH } from '../../../Common/constants/ResponsiveConstants'
import KossipOutlineButton from '../../../Common/components/KossipOutlineButton'

export const Aug16WebinarRouteWrapper = styled.div`
   display: flex;
   flex-direction: column;
   background-color: ${Colors.paleGreyTwo};
   width: 100%;
   min-height: 87.6vh;
   padding-bottom: 50px;
   background-color: ${props => props.theme.primaryBackgroundColor};
   transition: all 0.25s linear;
   position: ${props => (props.isHidden ? 'fixed' : 'inherit')};
`
export const WebinarSessionWrapper = styled.div<{ isHidden: boolean }>`
   display: flex;
   flex-direction: ${props => (props.isHidden ? 'column' : 'row')};
   justify-content: ${props => (props.isHidden ? 'flex-start' : 'center')};
   width: 100%;
   height: 100%;
   ${desktop} {
      padding-top: 49px;
      align-items: ${props => (props.isHidden ? 'center' : 'flex-start')};
   }
   ${tablet} {
      flex-direction: column;
      justify-content: center;
      align-items: center;
      padding: 0px;
      width: 100%;
   }
   ${mobile} {
      flex-direction: column;
      align-items: center;
      padding: 0px;
      width: 100%;
   }
`

export const WebinarVideoWrapper = styled.div<{ isHidden: boolean }>`
   display: flex;
   flex-direction: column;
   height: auto;
   justify-content: space-between;
   width: ${props => (props.isHidden ? '81%' : '52.36%')};
   height: ${props => (props.isHidden ? 'auto' : '100%')};
   ${tablet} {
      width: 100%;
      margin-top: ${props => (props.isHidden ? '16px' : '0px')};
   }
   ${mobile} {
      width: 100%;
   }
`

export const VideoWrapper = styled.div<{ isHidden: boolean }>`
   display: ${props => (props.isHidden ? 'none' : 'flex')};
   flex-direction: column;
   width: 100%;
   height: 100%;
   -webkit-user-select: none;
   -moz-user-select: none;
   -ms-user-select: none;
   user-select: none;
`
export const QuestionCardWrapper = styled.div<{ isHidden: boolean }>`
   display: flex;
   height: 100%;
   justify-content: center;
   align-items: center;
   width: ${props => (props.isHidden ? '83%' : '25.13%')};
   margin-top: ${props => (props.isHidden ? '40px' : '0px')};
   ${desktop} {
      margin-left: 30px;
   }
   ${tablet} {
      margin-top: 66px;
      width: 92.6%;
   }
   ${mobile} {
      margin-top: 32px;
      width: 92.6%;
   }
`

export const WelcomeCardWrapper = styled.div<{ isHidden: boolean }>`
   width: ${props => (props.isHidden ? '100%' : '35%')};
   margin-top: ${props => (props.isHidden ? '40px' : '0px')};

   ${desktop} {
      width: ${props => (props.isHidden ? '83%' : '25.13%')};
      margin-left: 30px;
   }
   ${tablet} {
      margin-top: 32px;
      width: 92.6%;
   }
   ${mobile} {
      margin-top: ${props => (props.isHidden ? '64px' : '32px')};
      width: 92.6%;
   }
   ${customDevice(768, 1024)} {
      margin-top: 32px;
   }
`

export const BestViewCardContainer = styled.div`
   width: 100%;
   margin-top: 16px;
`

export const Container = styled.div``

export const LoginModalWrapper = styled.div`
   display: flex;
   flex-direction: column;
   margin-top: 80px;
   align-items: center;
   min-height: 392px;
   width: 620px;
   height: auto;
   ${tablet} {
      width: 420px;
      margin-top: 130px;
   }
   ${mobile} {
      width: 344px;
      margin-top: 40px;
   }
`
export const LoginHeader = styled.div`
   display: flex;
   justify-content: center;
   align-items: center;
   margin-top: 16px;
   margin-bottom: 48px;
   width: 100%;
   flex-wrap: wrap;
   text-align: center;
`
interface RegistrationModelProps {
   theme: string
}

export const LoginText = styled(BaseHKGroteskMediumText)`
   display: flex;
   width: 90%;
   justify-content: center;
   align-items: center;
   text-align: center;
   color: ${(props: RegistrationModelProps) =>
      props.theme === DARK_THEME
         ? Colors.lightBlueGrey
         : Colors.battleshipGrey};
`

export const LoginModalBody = styled.div`
   display: flex;
   width: auto;
   height: auto;
   flex-direction: column;
   justify-content: center;
   align-items: center;
`

export const FieldText = styled(Typo12SteelHKGroteskSemiBold)`
   display: flex;
   width: 100%;
   justify-content: flex-start;
   text-transform: uppercase;
`
export const UserTextInput = styled(TextInput)`
   -webkit-appearance: none;
   height: 40px;
   margin-top: 8px;
   background-color: transparent;
   color: ${props => props.theme.secondaryTextColor};
   border: 1px solid ${Colors.coolGrey};
   &:focus {
      border: solid 2px ${Colors.cerulean};
      outline: none;
      font-weight: bold;
   }
   ${minDeviceWidth(1024)} {
      width: 348px;
   }
   ${tablet} {
      width: 356px;
   }
   ${mobile} {
      width: 296px;
   }
`
export const UserTextInputWrapper = styled.div`
   margin-bottom: 24px;
`
export const ButtonWrapper = styled.div`
   display: flex;
   justify-content: center;
   align-items: center;
   width: 100%;
`
export const JoinWebinarButton = styled(Button)`
   height: 40px;
   width: 140px;
   background-color: ${Colors.cerulean};
`

export const WelcomeText = styled(Typo30paleGreyHKGroteskBold)`
   text-transform: uppercase;
   color: ${props => props.theme.primaryTextColor};
`

export const RegistrationModel = styled(BaseModalContainer)`
   min-height: 700px;
   width: 100%;
   display: flex;
   flex-direction: column;
   align-items: center;
   background-color: ${(props: RegistrationModelProps) =>
      props.theme === DARK_THEME ? Colors.darkBlur : Colors.whiteBlur};
   -webkit-backdrop-filter: blur(10px);
   backdrop-filter: blur(10px);
   transition: all 0.25s linear;
   outline: none;
   user-select: none;
   overflow: hidden;
`
export const ErrorMessage = styled(Typo12PinkishOrangeHKGrotesk)`
   display: flex;
   width: 100%;
   display: ${props => (props.isHidden ? 'block' : 'none')};
   margin-top: -10px;
`

//NOTE: Need to check this overflow case later in above statement

export const FeedbackButton = styled(Button)`
   border-radius: 5.4px;
   box-shadow: none !important;
   height: 40px;
   width: 175px;
   margin-left: 15px;
`
export const FeedbackOutlineButton = styled(KossipOutlineButton)`
   display: flex;
   border-radius: 5.4px;
   box-shadow: none !important;
   height: 40px;
   width: 175px;
   justify-content: center;
   align-items: center;
   margin-left: 15px;
   background-color: inherit;
`

export const FeedbackOutlineButtonTextTypo = styled(
   Typo14AzulTwoHKGroteskMedium
)`
   color: ${Colors.azulTwo};
   letter-spacing: 0.5px;
   text-transform: uppercase;
   ${maxDeviceWidth(TABLET_MAX_WIDTH - 1)} {
      font-size: 12px;
      letter-spacing: 0.3px;
   }
   font-weight: bold;
`

export const FeedbackButtonWrapper = styled.div`
   display: flex;
   justify-content: flex-end;
   margin-top: 20px;
`

export const FeedbackButtonText = styled(Typo14AzulTwoHKGroteskMedium)`
   letter-spacing: 0.5px;
   text-transform: uppercase;
   ${maxDeviceWidth(TABLET_MAX_WIDTH - 1)} {
      font-size: 12px;
      letter-spacing: 0.3px;
   }
   font-weight: bold;
   color: ${props => props.theme.secondarySvgIconColor};
`

export const ButtonContainer = styled.div`
   display: flex;
   flex-wrap: wrap;
   justify-content: flex-end;
   width: 100%;
   ${tablet} {
      width: 96%;
   }
   ${mobile} {
      flex-direction: column;
      width: 96%;
   }
`

export const AssignmentButton = styled(Button)`
   border-radius: 5.4px;
   box-shadow: none !important;
   height: 40px;
   width: 190px;
   margin-left: 15px;
`

export const AssignmentButtonText = styled(Typo14AzulTwoHKGroteskMedium)`
   letter-spacing: 0.5px;
   text-transform: uppercase;
   ${maxDeviceWidth(TABLET_MAX_WIDTH - 1)} {
      font-size: 12px;
      letter-spacing: 0.3px;
   }
   font-weight: bold;
   color: ${props => props.theme.secondarySvgIconColor};
`
export const CtaButton = styled(Button)`
   display: flex;
   border-radius: 5.4px;
   box-shadow: none !important;
   height: 40px;
   min-width: 190px;
   justify-content: center;
   align-items: center;
   margin-left: 15px;
`
export const CtaOutlineButton = styled(KossipOutlineButton)`
   display: flex;
   border-radius: 5.4px;
   box-shadow: none !important;
   height: 40px;
   min-width: 190px;
   justify-content: center;
   align-items: center;
   margin-left: 15px;
   background-color: inherit;
`
export const CtaButtonText = styled(Typo14AzulTwoHKGroteskMedium)`
   letter-spacing: 0.5px;
   ${maxDeviceWidth(TABLET_MAX_WIDTH - 1)} {
      font-size: 12px;
      letter-spacing: 0.3px;
   }
   font-weight: bold;
   color: ${props => props.theme.secondarySvgIconColor};
`
export const CtaOutlineButtonText = styled(Typo14AzulTwoHKGroteskMedium)`
   color: ${Colors.azulTwo};
   letter-spacing: 0.5px;
   ${maxDeviceWidth(TABLET_MAX_WIDTH - 1)} {
      font-size: 12px;
      letter-spacing: 0.3px;
   }
   font-weight: bold;
`

export const DescriptionContainer = styled.div`
   display: flex;
   flex-direction: column;
   margin: 30.6px 0px 0px;

   ${maxDeviceWidth(1024)} {
      width: 92.6%;
      align-self: center;
   }
`

export const DangerouslySetInnerHtmlContainer = styled.span`
   word-break: break-word;
   color: ${props => props.theme.tertiaryTextColorTwo};

   ${maxDeviceWidth(1024)} {
      font-size: 14px;
   }
`

export const DescriptionHeadingText = styled(Typo30paleGreyHKGroteskBold)`
   display: flex;
   color: ${props => props.theme.tertiaryTextColorTwo};
   user-select: none;
   flex-wrap: wrap;
   word-break: break-word;
   width: 100%;
   margin-bottom: 10px;

   ${maxDeviceWidth(1024)} {
      font-size: 24px;
   }
`

export const ActiveWebinarContainer = styled.div`
   height: calc(100vh - 72px);
   width: 100%;
   overflow-y: auto;
`
