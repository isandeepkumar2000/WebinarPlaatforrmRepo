export const platformTypes = {
   default: 'DEFAULT',
   youtube: 'YOUTUBE'
}

export const videoSimulationModes = {
   live: 'LIVE',
   recorded: 'RECORDED'
}

export const attendees = {
   parentOrStudentForm: 'PARENT_OR_STUDENT_FORM',
   branch: 'BRANCH'
}
