export const googleAnalyticsEvent = {
   videoScreenEntered: 'video_screen_entered',
   play: 'play',
   pause: 'pause',
   playBackRateChange: 'play_back_rate_change',
   end: 'end',
   progress: 'progress',
   videoScreenExit: 'video_screen_exit',
   forward: 'forward'
}

export const PLAYING = 1
