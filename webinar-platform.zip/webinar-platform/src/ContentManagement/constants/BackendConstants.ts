export const accessTypes = {
   appsAndSubscriptions: 'APPS_AND_SUBSCRIPTIONS',
   formsRegistration: 'FORMS_REGISTRATION'
}
