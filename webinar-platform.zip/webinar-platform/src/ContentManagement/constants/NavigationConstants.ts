export const AUG_16_WEBINAR_PATH = '/:webinar_slug'
export const AUG_16_WEBINAR_KEY = 'AUG_16_WEBINAR_ROUTE'
export const CCBP_REGISTRATION_URL =
   'https://www.onthegomodel.com/ccbp#pricing-ccbp'

export const STUDENT_AMBASSADOR_PATH = '/4.0-champion'
export const STUDENT_AMBASSADOR_KEY = 'STUDENT_AMBASSADOR'
