import {
   attendeeBranchConstants,
   intrestedInConstants
} from '../../Common/constants/BackendConstants'

export const GA_TRACKER_ID = 'UA-98386906-5'
export const WEBINAR_YOUTUBE_ID = 'XdkMdKw_33c'
export const TIMESTAMP_QUERY_PARAM = 't'

export const getIntrestedInQuestionOptions = () => [
   {
      optionId: intrestedInConstants.xpmOnly,
      optionContent: 'XPM 4.0 only'
   },
   {
      optionId: intrestedInConstants.xpmAndCcbp,
      optionContent: 'XPM 4.0  + CCBP'
   },
   {
      optionId: intrestedInConstants.xpmAndOtg,
      optionContent: 'XPM 4.0 + OTG'
   },
   {
      optionId: intrestedInConstants.jobInterviewOnly,
      optionContent: 'Job Interview only'
   },
   {
      optionId: intrestedInConstants.other,
      optionContent: 'Other'
   }
]

export const getAttendeeBranchOptions = () => [
   {
      optionId: attendeeBranchConstants.BTECH_BECSE_IT_AIML_DS_CYBERSECURITY,
      optionContent: 'B.Tech / BE - CSE / IT / AI/ML / DS / Cyber Security'
   },
   {
      optionId: attendeeBranchConstants.BTECH_BEECE_EEE,
      optionContent: 'B.Tech / BE - ECE / EEE'
   },
   {
      optionId: attendeeBranchConstants.BTECH_BEMECHANICAL_CIVIL_CHEMICAL,
      optionContent: 'B.Tech / BE - Mechanical / Civil / Chemical'
   },
   {
      optionId: attendeeBranchConstants.BCOM_BSC_BA,
      optionContent: 'B.Com / B.Sc / BA'
   },
   {
      optionId: attendeeBranchConstants.BBA_BBM,
      optionContent: 'BBA / BBM'
   },
   { optionId: attendeeBranchConstants.other, optionContent: 'Other' }
]
