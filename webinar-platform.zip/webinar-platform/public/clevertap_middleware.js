const cleverTapMiddleWare = function({ payload, integration, next }) {
   const newKeys = {
      email: 'Email',
      name: 'Name',
      phone: 'Phone',
      gender: 'Gender',
      avatar: 'Photo'
   }

   const {
      firstName,
      lastName,
      email,
      phone,
      gender,
      avatar
   } = payload.obj.traits

   payload.obj.traits[newKeys.name] = `${firstName} ${lastName}`
   payload.obj.traits[newKeys.email] = email
   payload.obj.traits[newKeys.phone] = payload.obj.traits['countryCode'] + phone

   let genderValue = ''
   switch (gender) {
      case 'male':
         genderValue = 'M'
         break
      case 'female':
         genderValue = 'F'
         break
      case 'other':
         genderValue = 'O'
         break
   }
   if (genderValue) {
      payload.obj.traits[newKeys.gender] = genderValue
   }
   payload.obj.traits[newKeys.avatar] = avatar

   delete payload.obj.traits.firstName
   delete payload.obj.traits.lastName
   delete payload.obj.traits.email
   delete payload.obj.traits.phone
   delete payload.obj.traits.gender
   delete payload.obj.traits.avatar
   delete payload.obj.traits.countryCode
   next(payload)
}
